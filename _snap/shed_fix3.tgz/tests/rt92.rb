# encoding: utf-8
# rt92 - A RAISED WALL STOPS WHERE ITS WALL STOPS (2026-08-26).
#
# WHAT THIS IS
# The poly edge a gable wall is built along comes from the EAVE polygon -
# the wall centrelines pushed out by the overhang - so at every corner it
# runs past the wall it belongs to, by the overhang. On a gable nobody
# ever saw it: the triangle has no height down at the corners, so the
# stub is a sliver at the eave. On a SHED the far end of a side wall is
# at FULL height, and the stub hangs in the air past the corner. The user
# photographed exactly that: a white board floating past the high corner
# with nothing underneath it (2026-08-26).
#
# THE CLAIMS PINNED HERE
# 1. EVERY RAISED WALL STAYS INSIDE ITS OWN WALL, in plan. This is the
#    photograph, turned into a number.
# 2. ...AND STILL REACHES BOTH ENDS of it - the fix must not eat the
#    corner it was meant to close.
# 3. THE HIGH WALL IS FULL HEIGHT and the two side walls rake, which is
#    what makes the stub visible on a shed in the first place.
# 4. wall_span_on_edge is PURE and clamps to the edge.
# 5. clip_profile keeps the middle, interpolates the two new ends, and
#    gives back nothing when the window is empty.
# 6. AN OVER-FRAMED ROOF IS NOT CLIPPED. There a gable wall is MEANT to
#    run past its own wall, out to where the wing roof meets the main one
#    (rt17, rt86). Guarded here so the shed fix can never creep into it.
ENV['REAL_ROOMS'] = '1'
require './sketchup_stub'

module Sketchup
  class Face
    attr_accessor :pts, :pulled, :material, :back_material
    def normal
      a, b, c = @pts[0], @pts[1], @pts[2]
      u = Geom::Vector3d.new(b.x - a.x, b.y - a.y, b.z - a.z)
      v = Geom::Vector3d.new(c.x - a.x, c.y - a.y, c.z - a.z)
      (u * v).normalize
    end
    def pushpull(d); @pulled = d; end
    def reverse!; @pts = @pts.reverse; self; end
  end
  class Entities
    def add_face(pts)
      f = Face.new
      f.pts = pts
      @list << f
      f
    end
  end
end

require './room_manager'
require './level_manager'
require './roof_manager'

$fails = 0
def ok(n, c, x = nil)
  puts((c ? 'PASS  ' : 'FAIL  ') + n + (c ? '' : "   << #{x.inspect}"))
  $fails += 1 unless c
end
def close(a, b, tol = 0.05)
  !a.nil? && !b.nil? && (a - b).abs < tol
end

RM = InteriorPro::RoofManager

# ---------------------------------------------- 4. wall_span_on_edge
# a 200-long wall on an edge that runs 24 longer (12 of overhang each end)
FAKE = Struct.new(:atts) do
  def valid?; true; end
  def transformation; Geom::Transformation.new; end
  def get_attribute(_d, k, dflt = nil); atts.fetch(k, dflt); end
end
w = FAKE.new({ 'start_x' => 0.0, 'start_y' => 0.0, 'end_x' => 200.0,
               'end_y' => 0.0, 'thickness' => 6.0, 'anchor' => 'bottom-center' })
lo, hi = RM.wall_span_on_edge(w, [-12.0, -12.0], [1.0, 0.0], 224.0, 6.0)
ok('the span starts at the wall, not at the eave corner', close(lo, 9.0), lo)
ok('...and ends at the far end of the wall, not 12 past it', close(hi, 215.0), hi)
ok('...leaving the overhang stub OUT at both ends',
   lo > 0.5 && hi < 223.5, [lo, hi])
ok('a wall that cannot be measured gives back the whole edge',
   RM.wall_span_on_edge(nil, [0.0, 0.0], [1.0, 0.0], 224.0, 6.0) == [0.0, 224.0])

# ------------------------------- 4b. the BOX wins over the centreline
# His walls are drawn along their OUTER face, not down the middle, so the
# centreline already reaches the corner and padding it by half a
# thickness pushed 2.5 in. past the building - the stub he photographed
# coming out through the soffit (2026-08-26). The wall's own bounding box
# carries no assumption about how it was drawn.
BB = Struct.new(:min, :max)
BOXED = Struct.new(:atts, :bb) do
  def valid?; true; end
  def bounds; bb; end
  def transformation; Geom::Transformation.new; end
  def get_attribute(_d, k, dflt = nil); atts.fetch(k, dflt); end
end
# straight from his report: the high wall, drawn corner to OUTER corner
outer = BOXED.new({ 'start_x' => 1185.32, 'start_y' => 154.32,
                    'end_x' => 1347.36, 'end_y' => 154.32,
                    'thickness' => 5.0, 'anchor' => 'bottom-center' },
                  BB.new(Geom::Point3d.new(1185.32, 151.82, 106.0),
                         Geom::Point3d.new(1347.36, 156.82, 208.0)))
A = [1173.32, 154.32] # the eave corner, 12 of overhang before the wall
lo2, hi2 = RM.wall_span_on_edge(outer, A, [1.0, 0.0], 186.04, 5.0)
ok('the box stops exactly at the wall, with no pad',
   close(lo2, 12.0, 0.01) && close(hi2, 174.04, 0.01), [lo2, hi2])
ok('...and the padded centreline would have overshot by 2.5 each way',
   close(RM.wall_centre_span(outer, A, [1.0, 0.0], 5.0)[0], 9.5, 0.01) &&
   close(RM.wall_centre_span(outer, A, [1.0, 0.0], 5.0)[1], 176.54, 0.01),
   RM.wall_centre_span(outer, A, [1.0, 0.0], 5.0))
ok('a wall with nothing to measure has no box span',
   RM.wall_bounds_span(w, [0.0, 0.0], [1.0, 0.0]).nil?)
ok('...so the padded centreline still answers for it',
   !RM.wall_centre_span(w, [0.0, 0.0], [1.0, 0.0], 6.0).nil?)

# ---------------------------------------------------- 5. clip_profile
prof = [[0.0, 100.0], [100.0, 200.0]]
c = RM.clip_profile(prof, 25.0, 75.0)
ok('clip_profile cuts to the window', c.length == 2, c)
ok('...and interpolates the new low end', close(c.first[1], 125.0), c.first)
ok('...and the new high end', close(c.last[1], 175.0), c.last)
ok('a window wider than the profile changes nothing',
   RM.clip_profile(prof, -50.0, 500.0) == prof)
ok('an empty window gives nothing back', RM.clip_profile(prof, 60.0, 60.2).empty?)
ok('a window past the end gives nothing back', RM.clip_profile(prof, 300.0, 400.0).empty?)
mid = [[0.0, 100.0], [50.0, 150.0], [100.0, 100.0]]
ok('...and a middle point inside the window survives',
   RM.clip_profile(mid, 10.0, 90.0).length == 3,
   RM.clip_profile(mid, 10.0, 90.0))

# ------------------------- 7. THE WALL STANDS BACK FROM THE ROOF EDGE
# The profile is read along the roof EDGE, but the prism is drawn at the
# WALL line, one overhang inward. On a shed's HIGH wall that step is
# straight downhill, so the roof is already lower where the wall really
# stands - and a profile carried across unchanged leaves the wall proud
# of the shingles. That is the grey bar along the high edge in the user's
# photo (2026-08-26). A gable end steps ALONG the ridge, square to the
# fall, and must not move at all.
SQ = [[0.0, 0.0], [400.0, 0.0], [400.0, 300.0], [0.0, 300.0]]
ONE = [{ pts: SQ, eave: 0 }]            # one plane, draining to edge 0
SLOPE = 4.0 / 12.0
ok('the far edge is downhill from its eave, so the wall drops',
   close(RM.edge_inward_drop(SQ, 2, ONE, SLOPE, 12.0), SLOPE * 12.0, 0.001),
   RM.edge_inward_drop(SQ, 2, ONE, SLOPE, 12.0))
ok('...by exactly slope times the overhang - 4 in. at 4:12 over 12',
   close(RM.edge_inward_drop(SQ, 2, ONE, SLOPE, 12.0), 4.0, 0.001))
ok('a rake steps square to the fall and does not move (edge 1)',
   close(RM.edge_inward_drop(SQ, 1, ONE, SLOPE, 12.0), 0.0, 0.001),
   RM.edge_inward_drop(SQ, 1, ONE, SLOPE, 12.0))
ok('...nor the other one (edge 3)',
   close(RM.edge_inward_drop(SQ, 3, ONE, SLOPE, 12.0), 0.0, 0.001),
   RM.edge_inward_drop(SQ, 3, ONE, SLOPE, 12.0))
ok('the eave edge itself steps UPHILL, so it would rise',
   RM.edge_inward_drop(SQ, 0, ONE, SLOPE, 12.0) < -3.9,
   RM.edge_inward_drop(SQ, 0, ONE, SLOPE, 12.0))
ok('no cells, no drop', close(RM.edge_inward_drop(SQ, 2, nil, SLOPE, 12.0), 0.0))
ok('no overhang, no drop', close(RM.edge_inward_drop(SQ, 2, ONE, SLOPE, 0.0), 0.0))
ok('point_in_ring? finds the middle', RM.point_in_ring?(SQ, 200.0, 150.0))
ok('...and refuses the outside', !RM.point_in_ring?(SQ, 900.0, 150.0))

# ================================================================
# 1/2/3. THE REAL BUILD - the user's own rectangle
def make_wall(m, id, s, e)
  w = m.entities.add_group
  { 'type' => 'wall', 'id' => id, 'start_x' => s[0], 'start_y' => s[1],
    'end_x' => e[0], 'end_y' => e[1], 'thickness' => 5.0,
    'anchor' => 'bottom-center', 'height' => 102.0, 'base_z' => 0.0,
    'level' => 1, 'wall_category' => 'exterior'
  }.each { |k, v| w.set_attribute('InteriorPro', k, v) }
  w
end

# centrelines straight off his model (shed_edge_report, 2026-08-26)
Sketchup.reset_model!
m = Sketchup.active_model
make_wall(m, 'D', [-218.5, 2.5], [-2.5, 2.5])       # south - the low eave
make_wall(m, 'A', [-2.5, 2.5], [-2.5, 208.7])       # east  - rakes
make_wall(m, 'B', [-2.5, 208.7], [-218.5, 208.7])   # north - the high wall
make_wall(m, 'C', [-218.5, 208.7], [-218.5, 2.5])   # west  - rakes
m.set_attribute('InteriorPro', 'roof_shed_wall_ids', ['D'])

roof = RM.build_roof!(style: 'shed', pitch: 4, overhang: 12, thickness: 0.5,
                      ridge_cap: true)
ok('the shed builds on his footprint', !roof.nil?)

tops = roof.entities.to_a.reject { |e| e.is_a?(Sketchup::Face) }
ok('three walls are raised to meet it - the two rakes and the high end',
   tops.length == 3, tops.length)

def box(g)
  p = g.entities.grep(Sketchup::Face).flat_map(&:pts)
  return nil if p.empty?
  { x: [p.map(&:x).min, p.map(&:x).max], y: [p.map(&:y).min, p.map(&:y).max],
    z: [p.map(&:z).min, p.map(&:z).max] }
end
boxes = tops.map { |g| box(g) }.compact
ok('...and every one of them has geometry', boxes.length == 3, boxes.length)

# the building itself, outer faces: x -221..0, y 0..211.2
XLO, XHI, YLO, YHI = -221.0, 0.0, 0.0, 211.2
TOL = 0.05
boxes.each_with_index do |bx, i|
  ok("raised wall #{i} stays inside the building in x",
     bx[:x][0] >= XLO - TOL && bx[:x][1] <= XHI + TOL, bx[:x])
  ok("raised wall #{i} stays inside the building in y",
     bx[:y][0] >= YLO - TOL && bx[:y][1] <= YHI + TOL, bx[:y])
  ok("raised wall #{i} starts at the wall top, not in the air",
     close(bx[:z][0], 102.0, 0.6), bx[:z])
end

# 2. it still REACHES both ends - a fix that ate the corner would pass
#    every test above and leave a hole.
side = boxes.select { |bx| (bx[:x][1] - bx[:x][0]).abs < 1.0 }  # the two rakes
high = boxes.reject { |bx| (bx[:x][1] - bx[:x][0]).abs < 1.0 }
ok('two of them are the rakes', side.length == 2, side.length)
ok('...and one is the high wall', high.length == 1, high.length)
side.each_with_index do |bx, i|
  ok("rake #{i} runs the whole depth of the building",
     close(bx[:y][0], YLO, 0.6) && close(bx[:y][1], YHI, 0.6), bx[:y])
end
hb = high.first
ok('the high wall runs the whole width of the building',
   hb && close(hb[:x][0], XLO, 0.6) && close(hb[:x][1], XHI, 0.6), hb && hb[:x])

# 3. the shape that made the stub visible: the high wall is a full-height
#    band, the rakes climb to just under it.
# on the real build: all three now top out on the SAME roof underside,
# because all three stand on the wall line. Before the drop the high one
# was a full slope*overhang above the other two - the bar.
ok('every raised wall tops out on the same roof underside',
   (hb[:z][1] - side.map { |bx| bx[:z][1] }.max).abs < 0.05,
   [hb[:z][1], side.map { |bx| bx[:z][1] }])
ok('...and none of them stands above where the roof deck starts',
   hb[:z][1] < 176.0, hb[:z][1])

ok('the high wall is at least as tall as the rakes',
   hb[:z][1] > side.map { |bx| bx[:z][1] }.max - 0.01,
   [hb[:z][1], side.map { |bx| bx[:z][1] }])
ok('...and it is a proper band, not a sliver',
   hb[:z][1] - hb[:z][0] > 60.0, hb[:z])

puts($fails.zero? ? 'ALL PASS' : "#{$fails} FAILED")
exit($fails.zero? ? 0 : 1)
