# encoding: utf-8
# Interior Pro - what actually happens at a corner between a CURVED wall and
# its straight neighbour. Prints the numbers weld_corner! works from, and
# which of its two branches ran, so a bad seam can be diagnosed instead of
# guessed at (2026-08-12).
#
# Ruby Console (one line):
#   load 'C:/Users/rordt/AppData/Roaming/SketchUp/SketchUp 2024/SketchUp/Plugins/interior_pro/debug_arc_corner.rb'

begin
  InteriorPro.reload!
rescue StandardError => e
  puts "[dbg] reload נכשל: #{e.message}"
end

D  = 'InteriorPro'.freeze unless defined?(D)
wt = InteriorPro::WallTool

def dbg_pts(c)
  return nil unless c.is_a?(Array) && c.length == 8
  c.each_slice(2).to_a.map { |p| [p[0].to_f, p[1].to_f] }
end

def dbg_r(p)
  "(#{p[0].round(2)}, #{p[1].round(2)})"
end

def dbg_d(a, b)
  Math.hypot(a[0] - b[0], a[1] - b[1])
end

model = Sketchup.active_model
walls = model.active_entities.grep(Sketchup::Group)
             .select { |g| g.valid? && g.get_attribute(D, 'type') == 'wall' }
curved = walls.select { |w| wt.curved_wall?(w) }

puts '=' * 68
puts "[dbg] קירות: #{walls.size}   מתוכם מעוגלים: #{curved.size}"
puts "[dbg] weld_corner! קיים: #{wt.instance_methods.include?(:weld_corner!)}"
puts '=' * 68

walls.each do |w|
  puts format('  wall %-14s sag=%-9s th=%-5s anchor=%-14s  %s -> %s',
              w.get_attribute(D, 'id').to_s[0, 14],
              wt.wall_sag(w).round(2),
              w.get_attribute(D, 'thickness').to_f.round(2),
              w.get_attribute(D, 'anchor').to_s,
              dbg_r([w.get_attribute(D, 'start_x').to_f, w.get_attribute(D, 'start_y').to_f]),
              dbg_r([w.get_attribute(D, 'end_x').to_f, w.get_attribute(D, 'end_y').to_f]))
end

curved.each do |cw|
  cid = cw.get_attribute(D, 'id').to_s[0, 14]
  [[:start, 'start_x', 'start_y', [0, 3]], [:end, 'end_x', 'end_y', [1, 2]]].each do |side, kx, ky, slots|
    px = cw.get_attribute(D, kx).to_f
    py = cw.get_attribute(D, ky).to_f

    nb = nil
    nb_side = nil
    walls.each do |o|
      next if o == cw || nb
      [[:start, 'start_x', 'start_y'], [:end, 'end_x', 'end_y']].each do |os, okx, oky|
        next if nb
        d = Math.hypot(o.get_attribute(D, okx).to_f - px, o.get_attribute(D, oky).to_f - py)
        if d < 1.0
          nb = o
          nb_side = os
        end
      end
    end

    puts '-' * 68
    puts "[dbg] קשת '#{cid}' צד #{side} בנקודה #{dbg_r([px, py])}"
    if nb.nil?
      puts '      אין שכן כאן.'
      next
    end
    nid = nb.get_attribute(D, 'id').to_s[0, 14]
    n_curved = wt.curved_wall?(nb)
    puts "      שכן: '#{nid}' צד #{nb_side}   מעוגל=#{n_curved}   " \
         "קטגוריה: #{cw.get_attribute(D, 'wall_category')} / #{nb.get_attribute(D, 'wall_category')}"

    cp = dbg_pts(cw.get_attribute(D, 'corners_xy'))
    np2 = dbg_pts(nb.get_attribute(D, 'corners_xy'))
    unless cp && np2
      puts '      ! אין corners_xy שמורים על אחד מהם'
      next
    end
    n_slots = nb_side == :start ? [0, 3] : [1, 2]
    g_cut = [cp[slots[0]], cp[slots[1]]]
    o_cut = [np2[n_slots[0]], np2[n_slots[1]]]
    puts "      חיתוך הקשת:  #{dbg_r(g_cut[0])}  #{dbg_r(g_cut[1])}"
    puts "      חיתוך השכן:  #{dbg_r(o_cut[0])}  #{dbg_r(o_cut[1])}"

    # nearest pairing, then the gap that decides same-side vs shoulder
    st = dbg_d(g_cut[0], o_cut[0]) + dbg_d(g_cut[1], o_cut[1])
    cr = dbg_d(g_cut[0], o_cut[1]) + dbg_d(g_cut[1], o_cut[0])
    pair = st <= cr ? [o_cut[0], o_cut[1]] : [o_cut[1], o_cut[0]]
    d0 = dbg_d(g_cut[0], pair[0])
    d1 = dbg_d(g_cut[1], pair[1])
    thr = [cw.get_attribute(D, 'thickness').to_f, nb.get_attribute(D, 'thickness').to_f].max * 1.2
    shared = g_cut.any? { |a| o_cut.any? { |b| dbg_d(a, b) < 0.1 } }
    puts format('      מרחקי התאמה: %.3f / %.3f    סף same-side: %.2f', d0, d1, thr)
    puts "      תפר משותף: #{shared ? 'כן' : 'לא ***'}"
    puts "      ענף שרץ: #{[d0, d1].max <= thr ? 'SNAP (תפר אחד)' : 'SHOULDER (כתף)'}"

    # how far the arc's own natural (unwelded) cut is from where it ended up
    nat = wt.curved_end_corners_xy(
      cw.get_attribute(D, 'start_x').to_f, cw.get_attribute(D, 'start_y').to_f,
      cw.get_attribute(D, 'end_x').to_f,   cw.get_attribute(D, 'end_y').to_f,
      cw.get_attribute(D, 'thickness').to_f,
      (cw.get_attribute(D, 'anchor') || 'bottom-center').to_s.split('-')[1] || 'center',
      wt.wall_sag(cw))
    if nat
      nc = [nat[slots[0]], nat[slots[1]]]
      puts "      חיתוך טבעי (בלי ריתוך): #{dbg_r(nc[0])}  #{dbg_r(nc[1])}"
      puts format('      זז מהטבעי ב: %.3f / %.3f',
                  dbg_d(g_cut[0], nc[0]), dbg_d(g_cut[1], nc[1]))
    end
  end
end
puts '=' * 68
puts '[dbg] סוף. תעתיק לי את כל הפלט.'
