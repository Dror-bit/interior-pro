# encoding: utf-8
# debug_sheet.rb - why is the sheet empty?
#
# Version 2: dumps the EXACT payload the sheet window is given, not a fresh
# build of my own - the two turned out not to be the same thing.
#
# Writes sheet_report.txt next to the plugin and prints one line. Nothing for
# the user to read.
#
#   load File.join(InteriorPro::PLUGIN_DIR, 'debug_sheet.rb')

require 'json'

module InteriorPro
  module DebugSheet
    def self.ft(v)
      return 'nil' if v.nil?
      format('%.1f', v.to_f / 12.0)
    end

    def self.shape_xy(s)
      xs = []
      ys = []
      case s[:type]
      when :line
        xs << s[:x1] << s[:x2]
        ys << s[:y1] << s[:y2]
      when :polyline, :polygon, :hatch
        (s[:points] || []).each { |p| xs << p[0]; ys << p[1] }
      when :table
        xs << s[:x]
        ys << s[:y]
      else
        xs << s[:x]
        ys << s[:y]
      end
      [xs.compact, ys.compact]
    end

    def self.dump_doc(out, doc, tag)
      out << "== #{tag} =="
      cv = doc.canvases.find { |c| c.name == 'MODEL' }
      b  = cv && cv.bounds
      out << "  canvas bounds (feet): #{b ? b.map { |v| ft(v) }.inspect : 'nil'}"
      out << "  size (feet): #{b ? "#{ft(b[2].to_f - b[0])} x #{ft(b[3].to_f - b[1])}" : 'nil'}"
      out << "  pages: #{doc.pages.length}"
      doc.pages.each_with_index do |p, i|
        out << format('  page %d %-12s %.1f x %.1f  views=%d layers=%s',
                      i + 1, p.name, p.width, p.height, p.views.length,
                      p.layers.map(&:name).inspect)
        p.views.each do |v|
          out << format('    view %-8s x=%.2f y=%.2f w=%.2f h=%.2f scale=%s origin=(%s, %s) canvas=%s',
                        v.name, v.x, v.y, v.w, v.h, v.scale.inspect,
                        ft(v.origin_x), ft(v.origin_y), v.canvas)
          out << "    fits? #{v.fits?(b)}   largest that fits: #{v.fit_scale(b).inspect}"
        end
      end
      return unless cv
      cv.layers.each do |l|
        xs = []
        ys = []
        types = Hash.new(0)
        l.shapes.each do |s|
          types[s[:type]] += 1
          a, c = shape_xy(s)
          xs.concat(a)
          ys.concat(c)
        end
        if xs.empty?
          out << "  layer #{l.name}: #{l.shapes.length} shapes #{types.inspect}, no coordinates"
        else
          out << format('  layer %-12s %4d %-40s x %s..%s  y %s..%s  visible=%s',
                        l.name, l.shapes.length, types.inspect,
                        ft(xs.min), ft(xs.max), ft(ys.min), ft(ys.max), l.visible)
        end
      end
    end

    def self.run!
      out = []
      model = Sketchup.active_model
      out << "SketchUp #{Sketchup.version}"
      out << "model path: #{model.path.to_s.inspect}"
      out << "entities in model: #{model.entities.length}"
      out << "saved sheet state: #{model.get_attribute('InteriorPro', 'sheet_state').inspect}"
      out << "PlanSheetDialog loaded from: #{InteriorPro::PLUGIN_DIR}"
      out << "has fitPlan in html: #{InteriorPro::PlanSheetDialog.html.include?('function fitPlan()')}"
      out << "has first-open fit: #{InteriorPro::PlanSheetDialog.html.include?('if(first){ fitPlan(); return; }')}"
      out << ''

      walls = model.entities.grep(Sketchup::Group).select do |g|
        g.valid? && g.get_attribute('InteriorPro', 'type') == 'wall'
      end
      out << "walls: #{walls.length}"
      walls.first(40).each do |w|
        out << format('  (%s,%s) -> (%s,%s) th=%s cat=%s xform_origin=(%s,%s)',
                      ft(w.get_attribute('InteriorPro', 'start_x')),
                      ft(w.get_attribute('InteriorPro', 'start_y')),
                      ft(w.get_attribute('InteriorPro', 'end_x')),
                      ft(w.get_attribute('InteriorPro', 'end_y')),
                      w.get_attribute('InteriorPro', 'thickness'),
                      w.get_attribute('InteriorPro', 'wall_category'),
                      ft(w.transformation.origin.x), ft(w.transformation.origin.y))
      end
      out << ''

      # 1. a clean build, the way the command line does it
      fresh = InteriorPro::PlanCanvas.build_document(model, size: 'ARCH D', scale: '1/4"')
      dump_doc(out, fresh, 'FRESH BUILD (no saved state)')
      out << ''

      # 2. THE ONE THE WINDOW USES
      InteriorPro::PlanSheetDialog.instance_variable_set(:@doc, nil)
      win = InteriorPro::PlanSheetDialog.document
      dump_doc(out, win, 'WHAT THE WINDOW BUILDS')
      out << ''

      # 3. the payload, exactly as it is handed over
      cv = win.canvases.find { |c| c.name == 'MODEL' }
      payload = {
        state: InteriorPro::PlanSheetDialog.load_state,
        page_sizes: InteriorPro::PlanDoc.page_size_names,
        scales: InteriorPro::PlanDoc.scale_labels,
        bounds: cv && cv.bounds
      }
      out << '== PAYLOAD (without the shapes) =='
      out << JSON.generate(payload)
      out << ''
      json = JSON.generate(doc: win.to_h)
      out << "payload shapes json size: #{json.bytesize} bytes"
      out << "json is valid: #{begin; JSON.parse(json); true; rescue StandardError => e; e.message; end}"

      path = File.join(InteriorPro::PLUGIN_DIR, 'sheet_report.txt')
      File.open(path, 'w') { |f| f.write(out.join("\n")) }
      "OK - wrote sheet_report.txt (#{out.length} lines). Nothing for you to read."
    rescue StandardError => e
      begin
        File.open(File.join(InteriorPro::PLUGIN_DIR, 'sheet_report.txt'), 'w') do |f|
          f.write("CRASH #{e.class}: #{e.message}\n#{e.backtrace.first(15).join("\n")}")
        end
      rescue StandardError
        nil
      end
      "FAIL: #{e.class} - #{e.message} (written to sheet_report.txt)"
    end
  end
end

puts InteriorPro::DebugSheet.run!
