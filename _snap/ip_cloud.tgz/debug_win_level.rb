# Interior Pro - measurement only, changes nothing.
# Answers: do level-2 walls carry x/y translation (or rotation) in their
# group transformation? If yes, the local-vs-world bug in window_tool.rb
# is real. Writes a report file; prints nothing useful to the console.
module InteriorPro
  module DebugWinLevel
    def self.run
      out = []
      m = Sketchup.active_model
      walls = m.entities.grep(Sketchup::Group).select { |g|
        g.get_attribute('InteriorPro', 'type') == 'wall'
      }
      out << "walls at top level: #{walls.size}"
      out << ""
      by_level = Hash.new { |h, k| h[k] = [] }
      walls.each { |w| by_level[(w.get_attribute('InteriorPro','level') || 1).to_i] << w }
      by_level.keys.sort.each do |lv|
        ws = by_level[lv]
        out << "== level #{lv} : #{ws.size} walls =="
        origins = ws.map { |w| w.transformation.origin.to_a.map { |v| v.round(3) } }
        out << "  distinct origins: #{origins.uniq.size}"
        origins.uniq.first(12).each { |o| out << "    #{o.inspect}" }
        nonzero_xy = ws.select { |w|
          o = w.transformation.origin
          o.x.abs > 0.001 || o.y.abs > 0.001
        }
        out << "  walls with NON-ZERO x or y in transformation: #{nonzero_xy.size}  <== THE ANSWER"
        nonzero_xy.first(10).each do |w|
          o = w.transformation.origin
          out << "    id=#{w.get_attribute('InteriorPro','id')} origin=(#{o.x.round(3)}, #{o.y.round(3)}, #{o.z.round(3)})"
        end
        rotated = ws.select { |w|
          xa = w.transformation.xaxis
          (xa.x - 1.0).abs > 0.0001 || xa.y.abs > 0.0001
        }
        out << "  walls with ROTATION/SCALE in transformation: #{rotated.size}"
        rotated.first(6).each do |w|
          xa = w.transformation.xaxis
          out << "    id=#{w.get_attribute('InteriorPro','id')} xaxis=(#{xa.x.round(4)}, #{xa.y.round(4)}, #{xa.z.round(4)})"
        end
        out << ""
      end
      out << "== windows already placed =="
      wins = m.entities.grep(Sketchup::ComponentInstance).select { |c|
        c.get_attribute('InteriorPro', 'type') == 'window'
      }
      out << "  count: #{wins.size}"
      wins.first(20).each do |c|
        out << "  win id=#{c.get_attribute('InteriorPro','id')} host=#{c.get_attribute('InteriorPro','host_wall_id')} pos=#{c.get_attribute('InteriorPro','position_along_wall_in')} bottom_z=#{c.get_attribute('InteriorPro','bottom_z')}"
      end
      path = File.join(File.dirname(__FILE__), 'win_level_report.txt')
      File.open(path, 'w') { |f| f.puts out.join("\n") }
      UI.messagebox("Done. Report written:\n#{path}")
      nil
    end
  end
end
InteriorPro::DebugWinLevel.run
