# encoding: utf-8
# debug_wall_ids.rb - READ ONLY. Why does moving a wall UPSTAIRS drag a wall
# DOWNSTAIRS with it?
#
# There are two completely different mechanisms that could do that, and they
# need opposite fixes, so this measures which one is actually present:
#
#   A. BY ID.  Copy/paste in SketchUp copies every attribute, id included.
#      Two walls answering to one id means find_wall can hand back the wrong
#      one. WallTool.ensure_unique_ids! is supposed to heal this - but it
#      SKIPS on purpose any id a door or window points at, so a hosted
#      duplicate survives. This report says whether that is your case.
#
#   B. BY POSITION. A neighbour search that matches endpoints in x/y only,
#      with no level test, will grab the wall directly below. The report
#      lists every cross-level endpoint that coincides, and how close.
#
# Nothing is changed. Ruby Console:
#   load 'C:/Users/rordt/AppData/Roaming/SketchUp/SketchUp 2024/SketchUp/Plugins/interior_pro/debug_wall_ids.rb'

module InteriorPro
  module WallIdProbe
    OUT = File.join(File.dirname(__FILE__), 'wall_ids_report.txt')
    NEAR = 1.0    # inches: close enough that a geometric search would bite

    def self.run
      model = Sketchup.active_model
      o = []
      o << '=' * 74
      o << "WALL ID / CROSS-LEVEL PROBE  (read only)   #{Time.now}"
      o << '=' * 74

      walls = model.entities.grep(Sketchup::Group).select do |g|
        g.valid? && g.get_attribute('InteriorPro', 'type') == 'wall'
      end
      o << "#{walls.length} wall(s) at top level of the model"

      # who is hosted by a door or a window
      hosted = Hash.new(0)
      model.entities.grep(Sketchup::Group).each do |g|
        next unless g.valid?
        h = g.get_attribute('InteriorPro', 'host_wall_id')
        hosted[h.to_s] += 1 unless h.nil?
      end
      model.entities.grep(Sketchup::ComponentInstance).each do |g|
        next unless g.valid?
        h = g.get_attribute('InteriorPro', 'host_wall_id')
        hosted[h.to_s] += 1 unless h.nil?
      end
      o << "#{hosted.length} distinct wall id(s) have a door or window on them"
      o << ''

      info = walls.map do |g|
        t = g.transformation
        sx = g.get_attribute('InteriorPro', 'start_x').to_f
        sy = g.get_attribute('InteriorPro', 'start_y').to_f
        ex = g.get_attribute('InteriorPro', 'end_x').to_f
        ey = g.get_attribute('InteriorPro', 'end_y').to_f
        s = Geom::Point3d.new(sx, sy, 0).transform(t)
        e = Geom::Point3d.new(ex, ey, 0).transform(t)
        { g: g,
          id: (g.get_attribute('InteriorPro', 'id') || '(none)').to_s,
          lvl: (g.get_attribute('InteriorPro', 'level') || 1).to_i,
          ident: t.identity?,
          s: [s.x.to_f, s.y.to_f], e: [e.x.to_f, e.y.to_f] }
      end

      by_lvl = Hash.new(0)
      info.each { |w| by_lvl[w[:lvl]] += 1 }
      o << "walls per level: #{by_lvl.sort.map { |k, v| "level #{k}: #{v}" }.join(', ')}"
      o << ''

      # ---------------------------------------------------------- A. BY ID
      o << 'A.  DUPLICATE IDS'
      o << '-' * 74
      groups = Hash.new { |h, k| h[k] = [] }
      info.each { |w| groups[w[:id]] << w }
      dups = groups.select { |k, v| v.length > 1 && k != '(none)' }
      if dups.empty?
        o << 'none. every wall has an id of its own.'
      else
        o << ">>> #{dups.length} id(s) used by more than one wall:"
        dups.each do |id, list|
          lv = list.map { |w| w[:lvl] }.uniq.sort
          hd = hosted[id] > 0
          o << format('  %s  used by %d walls, level(s) %s%s',
                      id[0, 12], list.length, lv.inspect,
                      hd ? "   <-- HAS A DOOR/WINDOW: ensure_unique_ids! SKIPS IT" : '')
          list.each do |w|
            o << format('      level %d  identity=%-5s  (%.1f,%.1f) -> (%.1f,%.1f)',
                        w[:lvl], w[:ident].to_s, w[:s][0], w[:s][1], w[:e][0], w[:e][1])
          end
          o << format('      >>> SPANS TWO LEVELS - this one can drag across floors.') if lv.length > 1
        end
      end
      o << ''

      # ------------------------------------------------------ B. BY POSITION
      o << 'B.  ENDPOINTS THAT COINCIDE ACROSS LEVELS'
      o << '-' * 74
      o << "(a neighbour search with no level test would grab these; < #{NEAR}\")"
      hits = 0
      info.each_with_index do |a, i|
        info.each_with_index do |b, j|
          next if j <= i
          next if a[:lvl] == b[:lvl]
          [[:s, :s], [:s, :e], [:e, :s], [:e, :e]].each do |ka, kb|
            pa = a[ka]
            pb = b[kb]
            d = Math.sqrt((pa[0] - pb[0])**2 + (pa[1] - pb[1])**2)
            next if d > NEAR
            hits += 1
            o << format('  %s L%d %s   <->   %s L%d %s   gap %.3f"',
                        a[:id][0, 8], a[:lvl], ka.to_s.upcase,
                        b[:id][0, 8], b[:lvl], kb.to_s.upcase, d) if hits <= 40
          end
        end
      end
      o << "  ... #{hits - 40} more" if hits > 40
      o << '  none.' if hits.zero?
      o << ''
      o << format('TOTAL: %d duplicate id(s), %d cross-level endpoint match(es)',
                  dups.length, hits)
      o << ''
      o << 'READ IT LIKE THIS:'
      o << '  duplicates spanning two levels  -> the cause is the ID (mechanism A)'
      o << '  no duplicates but many matches  -> the cause is POSITION (mechanism B)'
      o << '  both                            -> fix A first, then measure again'

      File.open(OUT, 'w') { |f| f.puts(o.join("\n")) }
      puts "[WallIdProbe] written: #{OUT}"
      OUT
    rescue StandardError => e
      File.open(OUT, 'w') { |f| f.puts("CRASHED: #{e.class}: #{e.message}\n" + e.backtrace.first(8).join("\n")) }
      puts "[WallIdProbe] crashed, details in #{OUT}"
      OUT
    end
  end
end

InteriorPro::WallIdProbe.run
