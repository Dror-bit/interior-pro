# encoding: utf-8
# Landscape Pro - trim a reference fence down to ONE bay and drop the middle
# bars (2026-08-17). Asked for by the user on his cable railing.
#
# What it does, inside one operation, in a scratch group at the origin:
#   1. loads landscape/reference/cable railing.skp
#   2. explodes it into a fresh group so every part is loose
#   3. throws away everything past the second post (keeps post 1 + bay 1 +
#      post 2), and everything that is a thin vertical bar standing between
#      the two posts
#   4. saves what is left as landscape/reference/cable railing.skp
#      (the original is first copied to 'cable railing - original.skp')
#   5. removes the scratch group again
#
# It writes landscape/reference/trim_report.txt saying what it kept and what
# it dropped. Nothing else in the model is touched.
#
#   Ruby Console:
#     load 'C:/Users/rordt/AppData/Roaming/SketchUp/SketchUp 2024/SketchUp/Plugins/interior_pro/debug_fence_trim.rb'

require 'fileutils'

module InteriorPro
  module Landscape
    module FenceTrim

      FILE = 'cable railing.skp' unless const_defined?(:FILE, false)

      def self.dir
        File.join(File.dirname(__FILE__), 'landscape', 'reference')
      end

      def self.run!(file = FILE)
        out = ["Landscape Pro - trim #{file} to one bay, drop middle bars", '']
        src = File.join(dir, file)
        unless File.exist?(src)
          out << "NOT FOUND: #{src}"
          return write(out)
        end
        backup = File.join(dir, File.basename(file, '.skp') + ' - original.skp')
        unless File.exist?(backup)
          FileUtils.cp(src, backup)
          out << "original copied to: #{File.basename(backup)}"
        else
          out << "backup already there: #{File.basename(backup)} (left alone)"
        end

        model = Sketchup.active_model
        model.start_operation('Trim reference fence', true)
        scratch = nil
        begin
          defn = model.definitions.load(src)
          raise 'could not load' unless defn

          scratch = model.entities.add_group
          scratch.name = 'LandscapePro_TRIM_SCRATCH'
          inst = scratch.entities.add_instance(defn, Geom::Transformation.new)
          inst.explode

          ents = scratch.entities
          bb = scratch.bounds
          run_axis = bb.width.to_f >= bb.height.to_f ? 0 : 1
          total_h  = bb.depth.to_f
          out << format('model: %.2f x %.2f x %.2f, runs along %s', bb.width.to_f, bb.height.to_f, total_h, run_axis == 0 ? 'X' : 'Y')

          # Boxes for every top-level thing (loose faces get their own).
          items = []
          ents.to_a.each do |e|
            b = box_of(e)
            next unless b
            items << [e, b]
          end

          # Posts: tall + narrow along the run.
          posts = items.select do |(e, b)|
            along = b[1][run_axis] - b[0][run_axis]
            tall  = b[1][2] - b[0][2]
            !e.is_a?(Sketchup::Face) && along < 12.0 && tall >= total_h * 0.5
          end.sort_by { |(_e, b)| b[0][run_axis] }
          out << "posts found (tall narrow solids): #{posts.length}"
          posts.each { |(_e, b)| out << format('   post at %.2f..%.2f  height %.2f..%.2f', b[0][run_axis], b[1][run_axis], b[0][2], b[1][2]) }

          # The two thick posts = the two widest of the tall things.
          thick = posts.select { |(_e, b)| (b[1][run_axis] - b[0][run_axis]) >= 1.5 }
          raise "need two thick posts, found #{thick.length}" if thick.length < 2
          p1 = thick[0]
          p2 = thick[1]
          c1 = (p1[1][0][run_axis] + p1[1][1][run_axis]) / 2.0
          c2 = (p2[1][0][run_axis] + p2[1][1][run_axis]) / 2.0
          keep_lo = p1[1][0][run_axis] - 0.01
          keep_hi = p2[1][1][run_axis] + 0.01
          out << format('keeping from %.2f to %.2f (post 1 through post 2, pitch %.3f)', keep_lo, keep_hi, c2 - c1)

          dropped_far = 0
          dropped_bar = 0
          kept = 0
          to_erase = []
          items.each do |(e, b)|
            lo = b[0][run_axis]
            hi = b[1][run_axis]
            cx = (lo + hi) / 2.0
            along = hi - lo
            tall  = b[1][2] - b[0][2]
            # Anything whose centre is past post 2 goes.
            if cx > keep_hi
              to_erase << e
              dropped_far += 1
              next
            end
            # A thin vertical bar strictly between the two thick posts goes.
            if along < 1.5 && tall >= total_h * 0.5 && cx > c1 + 1.0 && cx < c2 - 1.0
              to_erase << e
              dropped_bar += 1
              next
            end
            kept += 1
          end
          out << "dropped past post 2: #{dropped_far}   dropped middle bars: #{dropped_bar}   kept: #{kept}"

          # Long things that ran the whole length (top rail) still stick out
          # past post 2: they were kept because their CENTRE was inside. Cut
          # them at post 2's outer face.
          cut_plane_x = keep_hi
          long = items.reject { |(e, _b)| to_erase.include?(e) }
                      .select { |(_e, b)| b[1][run_axis] > cut_plane_x + 0.05 }
          out << "long pieces overhanging post 2 (will be cut): #{long.length}"

          ents.erase_entities(to_erase.select(&:valid?)) unless to_erase.empty?

          # Cut: a section through everything at the plane, drop the far side.
          # SketchUp cannot slice a group of loose geometry with one call, so
          # this is done the plain way - intersect, then delete faces beyond.
          if long.any?
            cut_faces = ents.grep(Sketchup::Face)
            plane_pt = run_axis == 0 ? Geom::Point3d.new(cut_plane_x, 0, 0) : Geom::Point3d.new(0, cut_plane_x, 0)
            plane_n  = run_axis == 0 ? Geom::Vector3d.new(1, 0, 0) : Geom::Vector3d.new(0, 1, 0)
            plane = [plane_pt, plane_n]
            # A big face on the cutting plane, to intersect with.
            big = 10_000.0
            corners = if run_axis == 0
                        [Geom::Point3d.new(cut_plane_x, -big, -big), Geom::Point3d.new(cut_plane_x, big, -big),
                         Geom::Point3d.new(cut_plane_x, big, big), Geom::Point3d.new(cut_plane_x, -big, big)]
                      else
                        [Geom::Point3d.new(-big, cut_plane_x, -big), Geom::Point3d.new(big, cut_plane_x, -big),
                         Geom::Point3d.new(big, cut_plane_x, big), Geom::Point3d.new(-big, cut_plane_x, big)]
                      end
            tmp = model.entities.add_group
            knife = tmp.entities.add_face(corners)
            # Explode long groups/components so the knife can reach their faces.
            long.each do |(e, _b)|
              next if e.is_a?(Sketchup::Face) || e.is_a?(Sketchup::Edge)
              e.explode if e.valid? && e.respond_to?(:explode)
            end
            ents.intersect_with(false, scratch.transformation, ents, scratch.transformation, true, tmp.entities.to_a)
            tmp.erase! if tmp.valid?
            # Everything beyond the plane goes.
            beyond = ents.to_a.select do |e|
              b = box_of(e)
              next false unless b
              b[0][run_axis] > cut_plane_x + 0.01
            end
            ents.erase_entities(beyond) unless beyond.empty?
            out << "cut at #{format('%.2f', cut_plane_x)}: removed #{beyond.length} pieces beyond it"
          end

          # Save what is left as the new reference.
          new_defn = scratch.definition
          new_defn.name = File.basename(file, '.skp')
          ok = new_defn.save_as(src)
          out << (ok ? "SAVED: #{src}" : 'save_as returned false')

          fb = scratch.bounds
          out << format('new model: %.2f x %.2f x %.2f', fb.width.to_f, fb.height.to_f, fb.depth.to_f)
        rescue StandardError => e
          out << "STOPPED: #{e.class}: #{e.message}"
          out.concat(Array(e.backtrace).first(6))
        ensure
          scratch.erase! if scratch && scratch.valid?
          begin
            model.definitions.purge_unused
          rescue StandardError
            nil
          end
          model.commit_operation
        end
        write(out)
      end

      def self.box_of(e)
        b = e.bounds
        return nil if b.nil? || !b.valid?
        [[b.min.x.to_f, b.min.y.to_f, b.min.z.to_f], [b.max.x.to_f, b.max.y.to_f, b.max.z.to_f]]
      rescue StandardError
        nil
      end

      def self.write(lines)
        p = File.join(dir, 'trim_report.txt')
        File.write(p, lines.join("\n"))
        puts "[FenceTrim] wrote #{p}"
      end

    end
  end
end

InteriorPro::Landscape::FenceTrim.run!
