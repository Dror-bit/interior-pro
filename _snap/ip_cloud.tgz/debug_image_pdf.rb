# encoding: utf-8
# debug_image_pdf.rb - see with your own eyes that a real picture reaches the PDF.
#
# There is no button for pictures yet (that is the next step). This just asks
# for a file, puts it on a sheet, writes image_test.pdf into the plugin folder
# and opens it.
#
# Ruby Console:
#   load File.join(InteriorPro::PLUGIN_DIR, 'debug_image_pdf.rb')

module InteriorPro
  module DebugImagePDF
    def self.run
      path = UI.openpanel('בחר תמונה (JPG או PNG)', '',
                          'Images|*.jpg;*.jpeg;*.png;*.JPG;*.JPEG;*.PNG||')
      return puts('בוטל.') unless path

      info = PlanPDF.load_image(path)
      unless info
        puts "לא הצלחתי לקרוא את הקובץ: #{path}"
        UI.messagebox("לא הצלחתי לקרוא את התמונה.\n#{File.basename(path)}")
        return
      end

      doc = PlanDoc::Document.new('image test')
      doc.job_address = File.basename(path)
      pg  = doc.add_page('A-101', 'LETTER')
      lay = pg.layer('PAPER')

      fx, fy, fw, fh = pg.frame
      # a big one on top, and a small one below it, so both sizes are checked
      big_h = fh * 0.55
      lay.image(path, fx + 0.25, fy + fh - big_h - 0.25, fw - 0.5, big_h)
      lay.image(path, fx + 0.25, fy + 1.4, 2.5, 2.0, frame: true)
      lay.text("#{info[:w]} x #{info[:h]} px", fx + 3.1, fy + 2.2, h: 0.14)
      PlanDoc.build_title_block!(pg, doc)

      out = File.join(PLUGIN_DIR, 'image_test.pdf')
      File.delete(out) if File.exist?(out)
      PlanPDF.forget_images!
      PlanPDF.export(doc, out)

      puts "OK: #{info[:w]}x#{info[:h]}px -> #{out} (#{File.size(out)} bytes)"
      UI.openURL('file:///' + out.tr('\\', '/'))
      nil
    rescue StandardError => e
      puts "[DebugImagePDF] #{e.class}: #{e.message}"
      puts e.backtrace.first(6).join("\n")
      nil
    end
  end
end

InteriorPro::DebugImagePDF.run
