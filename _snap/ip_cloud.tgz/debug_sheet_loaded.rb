# encoding: utf-8
# debug_sheet_loaded.rb - is the NEW sheet window code actually loaded?
#
# Run it from the Ruby Console with:
#   load 'C:/Users/rordt/AppData/Roaming/SketchUp/SketchUp 2024/SketchUp/Plugins/interior_pro/debug_sheet_loaded.rb'
#
# It answers two DIFFERENT questions that look like one:
#   1. is the new code on the disk?          (did the file get written)
#   2. is the new code in SketchUp's memory?  (did reload! actually take)
# A yes to 1 and a no to 2 is the commonest false bug in this project, and it
# looks exactly like a broken feature from where the user sits.
#
# Writes the answer to sheet_loaded_report.txt beside this file, and prints a
# one-line verdict.

module InteriorPro
  module SheetLoadedCheck
    DIR = File.dirname(File.expand_path(__FILE__))

    # marker => what it belongs to, in the order the features were built
    MARKS = [
      ['drop_site_line',   'מחיקת קו בודד'],
      ['id="tsDims"',      'גודל טקסט (4 קבוצות)'],
      ['id="textbar"',     'עיצוב כיתוב בודד (דאבל-קליק)'],
      ['set_text_mark',    'שמירת עיצוב כיתוב'],
      ["e.key===' '",      'מקש רווח = מצב בחירה']
    ].freeze

    def self.run
      out = []
      out << "Interior Pro - sheet window load check"
      out << "time: #{Time.now}"
      out << ''

      path = File.join(DIR, 'plan_sheet_dialog.rb')
      out << "file: #{path}"
      if File.file?(path)
        disk = File.read(path, encoding: 'UTF-8')
        out << "  exists, #{disk.bytesize} bytes, written #{File.mtime(path)}"
      else
        disk = ''
        out << '  *** NOT THERE ***'
      end
      out << ''

      loaded = begin
        InteriorPro::PlanSheetDialog.html
      rescue StandardError, NameError => e
        out << "cannot read the loaded window: #{e.class}: #{e.message}"
        nil
      end

      out << format('%-34s %-8s %-8s', 'feature', 'ON DISK', 'LOADED')
      out << ('-' * 54)
      stale = false
      MARKS.each do |mark, what|
        on_disk = disk.include?(mark)
        in_mem  = loaded ? loaded.include?(mark) : false
        stale ||= (on_disk && !in_mem)
        out << format('%-34s %-8s %-8s', what, on_disk ? 'yes' : 'NO', in_mem ? 'yes' : 'NO')
      end
      out << ''

      verdict =
        if loaded.nil?
          'לא הצלחתי לקרוא את החלון הטעון - שלח את הקובץ'
        elsif stale
          'הקוד החדש על הדיסק אבל לא בזיכרון - הרץ InteriorPro.reload! ואז סגור ופתח את חלון התוכניות'
        elsif MARKS.all? { |m, _| disk.include?(m) }
          'הכל טעון. אם משהו לא עובד - זה באג אמיתי, לא טעינה'
        else
          'הקוד החדש לא הגיע לדיסק בכלל'
        end
      out << "VERDICT: #{verdict}"

      report = File.join(DIR, 'sheet_loaded_report.txt')
      begin
        File.write(report, out.join("\n") + "\n")
      rescue StandardError => e
        puts "[SheetCheck] could not write the report: #{e.message}"
      end
      puts out.join("\n")
      puts "\n(report: #{report})"
      verdict
    end
  end
end

InteriorPro::SheetLoadedCheck.run
