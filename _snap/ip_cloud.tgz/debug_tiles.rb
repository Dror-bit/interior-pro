# encoding: utf-8
# debug_tiles.rb - READ ONLY. Why the tile courses came out as big bands
# running UP the slope instead of thin steps running ACROSS it.
#
# Reports, for the roof in the model:
#   A. every top-shell face: its normal, its area, and the u/v frame
#      RoofTileMath builds from it - u must be HORIZONTAL (u.z ~ 0).
#   B. every course strip actually built: how long, how wide, how tall.
#      A step should be ~3" wide up the slope and metres long across it.
#      If width and length are the other way round, the frame is rotated.
module InteriorPro
  module DebugTiles
    def self.run
      out = []
      m = Sketchup.active_model
      roofs = m.entities.grep(Sketchup::Group).select { |g|
        g.get_attribute('InteriorPro', 'type') == 'roof'
      }
      out << "roof groups: #{roofs.size}"
      roofs.each_with_index do |r, ri|
        out << ''
        out << "=========== roof #{ri} : #{r.get_attribute('InteriorPro', 'roof_material')} ==========="
        faces = r.entities.grep(Sketchup::Face)
        out << "top-level faces in the roof group: #{faces.size}"
        out << ''
        out << '--- A. the planes the courses are laid on ---'
        faces.each_with_index do |f, i|
          n = f.normal
          next if n.z.abs < 1e-6
          pts = f.vertices.map(&:position).map { |p| [p.x.to_f, p.y.to_f, p.z.to_f] }
          next if pts.length < 3
          pl = InteriorPro::RoofTileMath.plane_uv(pts, [n.x.to_f, n.y.to_f, n.z.to_f])
          if pl.nil?
            out << format('  face %-3d area=%-9.1f normal=(%.3f, %.3f, %.3f)  -> plane_uv NIL',
                          i, f.area, n.x, n.y, n.z)
            next
          end
          out << format('  face %-3d area=%-9.1f pitch=%-5.1f  u_span=%-8.1f v_span=%-8.1f  ' \
                        'u=(%.3f,%.3f,%.3f) v=(%.3f,%.3f,%.3f)',
                        i, f.area, pl[:pitch], pl[:u_span], pl[:v_span],
                        pl[:u][0], pl[:u][1], pl[:u][2], pl[:v][0], pl[:v][1], pl[:v][2])
          out << format('           u.z should be ~0 : %.4f   %s', pl[:u][2],
                        pl[:u][2].abs < 1e-6 ? 'OK' : '<<< u IS NOT HORIZONTAL')
          out << format('           poly points: %d, first four %s',
                        pl[:poly].length,
                        pl[:poly].first(4).map { |a| a.map { |q| q.round(1) } }.inspect)
          res = InteriorPro::RoofTileMath.courses(pl, r.get_attribute('InteriorPro', 'roof_material').to_s)
          out << format('           courses: %d%s', res[:courses].length,
                        res[:truncated] ? ' (TRUNCATED)' : '')
          res[:courses].first(3).each do |c|
            out << format('             course %-3d v=%-8.1f spans=%s', c[:index], c[:v],
                          c[:spans].map { |a, b| [a.round(1), b.round(1)] }.inspect)
          end
        end

        out << ''
        out << '--- B. the strips that were actually built ---'
        subs = r.entities.grep(Sketchup::Group).select { |g|
          g.get_attribute('InteriorPro', 'part') == 'tile_courses'
        }
        out << "tile_courses sub-groups: #{subs.size}"
        subs.each_with_index do |sg, si|
          fs = sg.entities.grep(Sketchup::Face)
          b = sg.bounds
          out << format('  group %-2d faces=%-6d  bbox %.1f x %.1f x %.1f',
                        si, fs.size, b.width, b.height, b.depth)
          # A handful of individual faces, so their real size is visible.
          fs.first(6).each_with_index do |f, k|
            ps = f.vertices.map(&:position)
            xs = ps.map(&:x); ys = ps.map(&:y); zs = ps.map(&:z)
            out << format('    face %-2d pts=%-2d  dx=%-8.2f dy=%-8.2f dz=%-8.2f  area=%.1f',
                          k, ps.length, xs.max - xs.min, ys.max - ys.min,
                          zs.max - zs.min, f.area)
          end
        end
      end
      out << ''
      out << '== WHAT TO LOOK FOR =='
      out << '  A step is THIN up the slope (about 3") and LONG across it.'
      out << '  If dx/dy are both huge on every face, the strips are being laid'
      out << '  along the slope instead of across it - u and v are swapped.'

      path = File.join(File.dirname(__FILE__), 'tiles_report.txt')
      File.open(path, 'w') { |f| f.puts out.join("\n") }
      UI.messagebox("Done. Report written:\n#{path}")
      nil
    end
  end
end
InteriorPro::DebugTiles.run
