# encoding: utf-8
# Landscape Pro - measure the reference fences (2026-08-16)
#
# The pictures show what the good fences LOOK like. This measures what they
# ARE. It loads every .skp sitting in landscape/reference, walks down to the
# individual solids, groups the identical ones together and writes the sizes
# to landscape/reference/fence_ref_report.txt.
#
# Nothing is drawn and nothing is placed. The definitions are loaded, measured
# and purged again, inside one operation, so a single Undo puts the model back
# exactly as it was even if something goes wrong half way.
#
#   Ruby Console:
#     load 'C:/Users/rordt/AppData/Roaming/SketchUp/SketchUp 2024/SketchUp/Plugins/interior_pro/debug_fence_ref.rb'

module InteriorPro
  module Landscape
    module FenceRef

      def self.dir
        File.join(File.dirname(__FILE__), 'landscape', 'reference')
      end

      def self.run!
        out = []
        out << 'Landscape Pro - reference fence measurements'
        out << "folder: #{dir}"
        out << ''

        unless Dir.exist?(dir)
          out << 'THE FOLDER IS NOT THERE.'
          write(out)
          return
        end

        files = Dir.glob(File.join(dir, '*.skp')).sort
        if files.empty?
          out << 'No .skp files in the folder.'
          write(out)
          return
        end
        out << "#{files.length} file(s) found."
        out << ''

        model = Sketchup.active_model
        model.start_operation('Measure reference fences', true)
        begin
          files.each do |path|
            out.concat(measure_file(model, path))
            out << ''
          end
        rescue StandardError => e
          out << "STOPPED: #{e.class}: #{e.message}"
          out.concat(Array(e.backtrace).first(6))
        ensure
          begin
            model.definitions.purge_unused
          rescue StandardError
            nil
          end
          model.commit_operation
        end

        write(out)
      end

      def self.write(lines)
        path = File.join(dir, 'fence_ref_report.txt')
        File.write(path, lines.join("\n"))
        puts "[FenceRef] wrote #{path}"
      rescue StandardError => e
        puts "[FenceRef] could not write the report: #{e.message}"
      end

      # --------------------------------------------------------------- one file

      def self.measure_file(model, path)
        lines = []
        lines << ('=' * 66)
        lines << "FILE: #{File.basename(path)}"
        defn = nil
        begin
          defn = model.definitions.load(path)
        rescue StandardError => e
          lines << "  could not load: #{e.class}: #{e.message}"
          return lines
        end
        return lines << '  loaded, but empty' if defn.nil?

        lines << "  definition name: #{defn.name}"
        bb = defn.bounds
        lines << format('  overall size (in): %.2f wide x %.2f deep x %.2f high',
                        bb.width.to_f, bb.height.to_f, bb.depth.to_f)
        lines << format('  overall size (ft): %.2f x %.2f x %.2f',
                        bb.width.to_f / 12.0, bb.height.to_f / 12.0, bb.depth.to_f / 12.0)

        parts = []
        loose = []
        walk(defn.entities, Geom::Transformation.new, parts, loose, 0)

        lines << "  nested parts found: #{parts.length}"
        lines << ''

        if parts.empty? && loose.empty?
          lines << '  NOTHING MEASURABLE - it may be one welded solid.'
          return lines
        end

        # Identical parts are the whole story: "14 of these" IS the fence.
        groups = Hash.new { |h, k| h[k] = [] }
        parts.each { |p| groups[[p[:dims], p[:material]]] << p }

        lines << '  parts, grouped by size (inches, sorted small to large):'
        groups.to_a.sort_by { |(k, v)| [-v.length, k[0]] }.each do |(key, list)|
          dims, mat = key
          xs = list.map { |p| p[:min][0].round(2) }.sort
          zs = list.map { |p| p[:min][2].round(2) }.sort
          lines << format('    %3d x  %8.3f x %8.3f x %8.3f   material=%s',
                          list.length, dims[0], dims[1], dims[2], mat)
          lines << format('           names: %s', list.map { |p| p[:name] }.uniq.first(4).join(', '))
          if list.length > 1
            lines << format('           spacing along X: %s', spacing_of(xs))
            lines << format('           bottoms at Z: %s', zs.uniq.first(8).map { |z| z.round(2) }.join(', '))
          else
            lines << format('           sits at x=%.2f y=%.2f z=%.2f',
                            list[0][:min][0], list[0][:min][1], list[0][:min][2])
          end
        end

        unless loose.empty?
          lines << ''
          lines << "  loose faces straight in the definition: #{loose.length}"
        end

        lines
      end

      # The gap from one repeated part to the next. A fence is spacing, so this
      # is the number worth reading first.
      def self.spacing_of(sorted)
        return '(one)' if sorted.length < 2
        gaps = []
        (1...sorted.length).each { |i| gaps << (sorted[i] - sorted[i - 1]).round(3) }
        uniq = gaps.uniq
        return format('%.3f (even)', uniq[0]) if uniq.length == 1
        gaps.first(10).map { |g| format('%.2f', g) }.join(', ')
      end

      # --------------------------------------------------------------- walking

      MAX_DEPTH = 8 unless const_defined?(:MAX_DEPTH, false)

      def self.walk(ents, tr, parts, loose, depth)
        kids = []
        ents.each do |e|
          kids << e if e.is_a?(Sketchup::Group) || e.is_a?(Sketchup::ComponentInstance)
        end

        ents.grep(Sketchup::Face).each { |f| loose << f }

        kids.each do |k|
          sub = sub_entities(k)
          next if sub.nil?
          deeper = sub.any? { |e| e.is_a?(Sketchup::Group) || e.is_a?(Sketchup::ComponentInstance) }
          t = tr * k.transformation
          if deeper && depth < MAX_DEPTH
            walk(sub, t, parts, loose, depth + 1)
          else
            p = part_of(k, sub, t)
            parts << p if p
          end
        end
      rescue StandardError => e
        puts "[FenceRef] walk: #{e.message}"
      end

      def self.sub_entities(k)
        if k.respond_to?(:definition) && k.definition
          k.definition.entities
        elsif k.respond_to?(:entities)
          k.entities
        end
      rescue StandardError
        nil
      end

      # One solid, measured in the coordinates of the whole fence - which is
      # what makes "spacing along X" mean anything.
      def self.part_of(entity, sub, tr)
        min = nil
        max = nil
        sub.grep(Sketchup::Face).each do |f|
          f.vertices.each do |v|
            p = v.position.transform(tr)
            a = [p.x.to_f, p.y.to_f, p.z.to_f]
            if min.nil?
              min = a.dup
              max = a.dup
            else
              3.times do |i|
                min[i] = a[i] if a[i] < min[i]
                max[i] = a[i] if a[i] > max[i]
              end
            end
          end
        end
        return nil if min.nil?

        size = [(max[0] - min[0]).round(3),
                (max[1] - min[1]).round(3),
                (max[2] - min[2]).round(3)]

        name = ''
        begin
          name = entity.respond_to?(:definition) && entity.definition ?
                 entity.definition.name.to_s : entity.name.to_s
        rescue StandardError
          name = ''
        end
        name = '(unnamed)' if name.strip.empty?

        { dims: size.sort, raw: size, min: min, max: max,
          name: name, material: material_of(entity, sub) }
      rescue StandardError
        nil
      end

      def self.material_of(entity, sub)
        m = entity.material
        return m.name.to_s if m
        f = sub.grep(Sketchup::Face).find { |x| x.material }
        f && f.material ? f.material.name.to_s : '(none)'
      rescue StandardError
        '(none)'
      end

    end
  end
end

InteriorPro::Landscape::FenceRef.run!
