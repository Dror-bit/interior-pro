# debug_axis.rb - is each wall parallel to X or Y? (2026-08-14)
#
# He sees 90 degrees at every corner and the walls still look tilted.
# 90 is the angle BETWEEN two walls, so a whole rectangle can be turned off
# the axes and still show four perfect corners. This measures the other
# thing: how far each wall sits from the red (X) and green (Y) axis.
#
# Ruby Console:
#   load 'C:/Users/rordt/AppData/Roaming/SketchUp/SketchUp 2024/SketchUp/Plugins/interior_pro/debug_axis.rb'
#
# Writes axis_report.txt next to this file. Reads nothing, changes nothing.

module InteriorPro
  module DebugAxis
    def self.run
      model = Sketchup.active_model
      out   = []
      out << "== wall angle to the axes =="
      out << "measured #{Time.now}"
      out << ""

      walls = []
      model.active_entities.grep(Sketchup::Group).each do |g|
        next unless g.get_attribute('InteriorPro', 'type') == 'wall'
        walls << g
      end
      model.active_entities.grep(Sketchup::ComponentInstance).each do |c|
        next unless c.get_attribute('InteriorPro', 'type') == 'wall'
        walls << c
      end

      if walls.empty?
        out << "no walls found in the active context."
        File.write(report_path, out.join("\n"))
        return
      end

      out << format("%-14s %-9s %-10s %-9s %-8s %s",
                    'id', 'length', 'bearing', 'off-axis', 'cat', 'drift over its length')
      out << "-" * 86

      worst = 0.0
      walls.each_with_index do |w, i|
        t  = w.transformation
        sx = w.get_attribute('InteriorPro', 'start_x').to_f
        sy = w.get_attribute('InteriorPro', 'start_y').to_f
        ex = w.get_attribute('InteriorPro', 'end_x').to_f
        ey = w.get_attribute('InteriorPro', 'end_y').to_f
        s  = Geom::Point3d.new(sx, sy, 0).transform(t)
        e  = Geom::Point3d.new(ex, ey, 0).transform(t)

        dx  = e.x - s.x
        dy  = e.y - s.y
        len = Math.sqrt(dx * dx + dy * dy)
        next if len < 0.5

        # bearing measured from the red axis, counter-clockwise, 0..180
        deg = Math.atan2(dy, dx) * 180.0 / Math::PI
        deg += 180.0 while deg < 0
        deg -= 180.0 while deg >= 180.0

        # how far it is from the NEAREST axis direction (0 / 90 / 180)
        off = [deg, (deg - 90.0).abs, (180.0 - deg)].min
        worst = off if off > worst

        # what that tilt costs at the far end of this very wall
        drift = len * Math.tan(off * Math::PI / 180.0)

        id  = (w.get_attribute('InteriorPro', 'id') || "##{i}").to_s
        cat = (w.get_attribute('InteriorPro', 'wall_category') || 'exterior').to_s
        out << format("%-14s %-9s %-10s %-9s %-8s %s",
                      id[0, 13],
                      format('%.2f"', len),
                      format('%.4f', deg),
                      format('%.4f', off),
                      cat[0, 7],
                      off < 0.0005 ? 'straight on the axis' : format('%.3f"', drift))
      end

      out << ""
      out << format("worst wall is %.4f degrees off its nearest axis.", worst)
      out << if worst < 0.0005
               "every wall is exactly on an axis - the tilt is NOT in the walls."
             elsif worst < 0.05
               "tiny - would not show on screen, but it is real."
             else
               "this is the tilt he can see. The corners can still read 90," \
               " because 90 is the angle BETWEEN two walls, not to the axis."
             end
      out << ""
      out << "corner-to-corner check (pairs sharing an end):"
      pairs = 0
      walls.each_with_index do |a, i|
        walls.each_with_index do |b, j|
          next unless j > i
          ta = a.transformation; tb = b.transformation
          apts = %w[start end].map do |k|
            Geom::Point3d.new(a.get_attribute('InteriorPro', "#{k}_x").to_f,
                              a.get_attribute('InteriorPro', "#{k}_y").to_f, 0).transform(ta)
          end
          bpts = %w[start end].map do |k|
            Geom::Point3d.new(b.get_attribute('InteriorPro', "#{k}_x").to_f,
                              b.get_attribute('InteriorPro', "#{k}_y").to_f, 0).transform(tb)
          end
          apts.each_with_index do |pa, m|
            bpts.each_with_index do |pb, n|
              next if pa.distance(pb) >= 1.0
              av = m == 0 ? [apts[1].x - apts[0].x, apts[1].y - apts[0].y]
                          : [apts[0].x - apts[1].x, apts[0].y - apts[1].y]
              bv = n == 0 ? [bpts[1].x - bpts[0].x, bpts[1].y - bpts[0].y]
                          : [bpts[0].x - bpts[1].x, bpts[0].y - bpts[1].y]
              la = Math.sqrt(av[0]**2 + av[1]**2)
              lb = Math.sqrt(bv[0]**2 + bv[1]**2)
              next if la < 0.5 || lb < 0.5
              dot = (av[0] * bv[0] + av[1] * bv[1]) / (la * lb)
              dot = 1.0 if dot > 1.0
              dot = -1.0 if dot < -1.0
              ang = Math.acos(dot) * 180.0 / Math::PI
              pairs += 1
              ida = (a.get_attribute('InteriorPro', 'id') || "##{i}").to_s[0, 10]
              idb = (b.get_attribute('InteriorPro', 'id') || "##{j}").to_s[0, 10]
              out << format("  %-10s + %-10s  corner = %.4f   (screen shows %.1f)",
                            ida, idb, ang, (ang * 10).round / 10.0)
            end
          end
        end
      end
      out << "  (no shared corners found)" if pairs.zero?

      File.write(report_path, out.join("\n"))
      UI.messagebox("done - axis_report.txt written")
    rescue => e
      File.write(report_path, "CRASHED: #{e.class}: #{e.message}\n" +
                              e.backtrace.first(6).join("\n"))
    end

    def self.report_path
      File.join(File.dirname(__FILE__), 'axis_report.txt')
    end
  end
end

InteriorPro::DebugAxis.run
