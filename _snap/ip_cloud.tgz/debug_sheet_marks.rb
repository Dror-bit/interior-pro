# encoding: utf-8
# debug_sheet_marks.rb - what is actually ON the sheet, and where.
#
# READ ONLY. Touches nothing, changes nothing. Writes sheet_marks_report.txt
# next to the plugin and says so.
#
# Written 2026-08-19 after three rounds of guessing why a dimension in the
# sheet window cannot be picked up. The window will not say; the state will.
#
# Answers, in order:
#   1. Is the code the user is running the code I think he is running?
#      (the settings that only exist since today either are there or are not)
#   2. What marks are on the sheet, and WHERE - in model inches
#   3. How big is one model inch on his screen right now? A grab radius of 10
#      SCREEN pixels is a different thing at 1/8" scale zoomed out than it is
#      zoomed in, and that is measurable rather than arguable.
#   4. How much else is on the sheet for the mouse to catch instead.

module InteriorPro
  module DebugSheetMarks
    def self.run
      out = []
      add = lambda { |s| out << s.to_s }

      add.call('SHEET MARKS REPORT')
      add.call(Time.now.to_s)
      add.call('')

      model = Sketchup.active_model
      raw = begin
        model.get_attribute('InteriorPro', 'sheet_state')
      rescue StandardError => e
        add.call("could not read sheet_state: #{e.class}: #{e.message}")
        nil
      end

      if raw.nil? || raw.to_s.empty?
        add.call('NO SHEET STATE ON THIS MODEL - the window has never saved here.')
        write!(out)
        return
      end

      require 'json'
      st = begin
        JSON.parse(raw.to_s)
      rescue StandardError => e
        add.call("sheet_state will not parse: #{e.class}: #{e.message}")
        nil
      end
      unless st
        write!(out)
        return
      end

      # ---- 1. which version of the code saved this ----------------------
      add.call('== is today\'s code actually running ==')
      %w[pdf_skip drop_plan dim_off text_marks marks].each do |k|
        add.call(format('  %-12s %s', k, st.key?(k) ? "yes  #{st[k].inspect[0, 60]}" : 'MISSING'))
      end
      add.call('')

      # ---- 2. the marks --------------------------------------------------
      marks = Array(st['marks'])
      add.call("== marks on the sheet: #{marks.length} ==")
      marks.each_with_index do |m, i|
        if m['t'] == 'dim'
          x1 = m['x1'].to_f; y1 = m['y1'].to_f
          x2 = m['x2'].to_f; y2 = m['y2'].to_f
          len = Math.hypot(x2 - x1, y2 - y1)
          add.call(format('  %2d dim  (%.1f, %.1f) -> (%.1f, %.1f)   len %.1f"  (%.2f ft)',
                          i, x1, y1, x2, y2, len, len / 12.0))
          add.call(format('        off=%s  oa=%s  oc=%s  h=%s',
                          m['off'].inspect, m['oa'].inspect,
                          m['oc'].inspect, m['h'].inspect))
        else
          add.call(format('  %2d %-5s (%.1f, %.1f)  %s',
                          i, m['t'], m['x'].to_f, m['y'].to_f,
                          m['text'].to_s[0, 30]))
        end
      end
      add.call('')

      # ---- 3. how big is a model inch on screen --------------------------
      add.call('== the view ==')
      add.call("  scale        #{st['scale'].inspect}")
      add.call("  page size    #{st['size'].inspect} #{st['orientation'].inspect}")
      add.call("  zoom         #{st['zoom'].inspect}")
      add.call("  origin       #{st['origin_x'].inspect}, #{st['origin_y'].inspect}")
      add.call("  active page  #{st['active'].inspect}")

      sf = scale_factor(st['scale'])
      add.call(format('  scale factor  %.6f  (1 model inch -> %.6f paper inches)', sf, sf))
      if sf > 0
        # The window fits the page to the panel and then multiplies by zoom.
        # k is paper inches -> screen pixels. Whatever it is, this is the
        # number that decides whether a 10 pixel grab can reach a dimension.
        [40.0, 60.0, 80.0, 120.0].each do |k|
          add.call(format('    if k = %-5.0f px/paper-inch : 1 model inch = %.3f px, ' \
                          'and 10 px of grab = %.1f model inches',
                          k, sf * k, 10.0 / (sf * k)))
        end
      end
      add.call('')

      # ---- 4. what else is there to catch --------------------------------
      add.call('== what else the mouse can land on ==')
      site = begin
        s = model.get_attribute('InteriorPro', 'sheet_site_lines')
        s ? (JSON.parse(s.to_s) rescue []) : []
      rescue StandardError
        []
      end
      add.call("  free SITE lines saved on the model: #{site.length}")
      add.call("  hidden layers: #{Array(st['hidden']).inspect}")
      add.call("  text overrides: #{(st['text_marks'] || {}).keys.length}")
      add.call('')

      # ---- 5. the plain reading ------------------------------------------
      add.call('== the plain reading ==')
      dims = marks.select { |m| m['t'] == 'dim' }
      if dims.empty?
        add.call('  There are NO dimensions in the sheet settings at all.')
        add.call('  Whatever is on the drawing is being drawn from the MODEL,')
        add.call('  not from a mark - and nothing in this window can pick that up.')
      else
        shortest = dims.map { |m| Math.hypot(m['x2'].to_f - m['x1'].to_f,
                                            m['y2'].to_f - m['y1'].to_f) }.min
        add.call(format('  %d dimensions, the shortest %.1f" long.', dims.length, shortest))
        offs = dims.map { |m| m['off'] }.uniq
        add.call("  their 'off' values: #{offs.inspect}")
        add.call('  (all nil or 0 means every one of them is drawn straight')
        add.call('   onto the wall - which is what he is complaining about.)')
      end

      write!(out)
    end

    # The window's own table, copied so this file needs nothing loaded.
    def self.scale_factor(label)
      t = label.to_s.strip
      map = { '1/16"' => 1.0 / 192.0, '3/32"' => 1.0 / 128.0, '1/8"' => 1.0 / 96.0,
              '3/16"' => 1.0 / 64.0, '1/4"' => 1.0 / 48.0, '3/8"' => 1.0 / 32.0,
              '1/2"' => 1.0 / 24.0, '3/4"' => 1.0 / 16.0, '1"' => 1.0 / 12.0 }
      map.each { |k, v| return v if t.start_with?(k) }
      1.0 / 96.0
    end

    def self.write!(lines)
      path = File.join(File.dirname(__FILE__), 'sheet_marks_report.txt')
      File.open(path, 'w') { |f| f.write(lines.join("\n") + "\n") }
      puts "[DebugSheetMarks] wrote #{path}"
      path
    rescue StandardError => e
      puts "[DebugSheetMarks] could not write the report: #{e.class}: #{e.message}"
      puts lines.join("\n")
      nil
    end
  end
end

InteriorPro::DebugSheetMarks.run
