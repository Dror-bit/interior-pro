# encoding: utf-8
# Interior Pro - why a door on a CURVED wall sits inside the house (2026-08-12B).
#
# A door remembers the point it was placed at ('face_x' / 'face_y') and that
# stored point WINS over anything the curve maths works out later
# (DoorManager.opening_context). So a door placed before the curve fix - or on a
# wall that was bowed afterwards - can keep pointing at the old straight-wall
# spot even though geo_at is right. This prints both numbers side by side so we
# can see which one is wrong before touching any code.
#
# Ruby Console (one line):
#   load 'C:/Users/rordt/AppData/Roaming/SketchUp/SketchUp 2024/SketchUp/Plugins/interior_pro/debug_curved_door.rb'

begin
  InteriorPro.reload!
rescue StandardError => e
  puts "[dbg] reload נכשל: #{e.message}"
end

DD = 'InteriorPro'.freeze unless defined?(DD)

def cd_r(x, y)
  "(#{x.to_f.round(2)}, #{y.to_f.round(2)})"
end

def cd_all(entities, out = [])
  entities.each do |e|
    next unless e.valid?
    if e.is_a?(Sketchup::Group) || e.is_a?(Sketchup::ComponentInstance)
      out << e
      begin
        cd_all(e.is_a?(Sketchup::Group) ? e.entities : e.definition.entities, out)
      rescue StandardError
        nil
      end
    end
  end
  out
end

wt = InteriorPro::WallTool
dm = InteriorPro::DoorManager
am = InteriorPro::ArcMath
model = Sketchup.active_model

ents   = cd_all(model.entities)
walls  = ents.select { |g| g.get_attribute(DD, 'type') == 'wall' }
doors  = ents.select { |g| g.get_attribute(DD, 'type') == 'door' }
curved = walls.select { |w| wt.curved_wall?(w) }

puts '=' * 72
puts "[dbg] קירות=#{walls.size}  מעוגלים=#{curved.size}  דלתות=#{doors.size}"
puts '=' * 72

curved.each do |w|
  wid = w.get_attribute(DD, 'id').to_s
  th  = w.get_attribute(DD, 'thickness').to_f
  sag = wt.wall_sag(w)
  anc = (w.get_attribute(DD, 'anchor') || 'bottom-center').to_s
  sx = w.get_attribute(DD, 'start_x').to_f
  sy = w.get_attribute(DD, 'start_y').to_f
  ex = w.get_attribute(DD, 'end_x').to_f
  ey = w.get_attribute(DD, 'end_y').to_f
  mine = doors.select { |d| d.get_attribute(DD, 'host_wall_id') == wid }
  opens = wt.read_door_openings(w)

  puts '-' * 72
  puts "קיר מעוגל '#{wid[0, 12]}'  sag=#{sag.round(2)}  עובי=#{th}  עוגן=#{anc}"
  puts "  #{cd_r(sx, sy)} -> #{cd_r(ex, ey)}   דלתות עליו=#{mine.size}  " \
       "פתחים רשומים=#{opens.size}"
  opens.each do |o|
    puts format('    opening  t=%.2f  w=%.2f  h=%.2f  floor=%.2f',
                o[:t].to_f, o[:width].to_f, o[:height].to_f, o[:floor_offset].to_f)
  end

  geo = dm.wall_geometry(w)
  unless geo
    puts '  ! wall_geometry החזיר nil'
    next
  end
  puts "  geo: curved=#{geo[:curved]}  אורך=#{geo[:wall_length].to_f.round(2)}  " \
       "center_offset=#{geo[:center_offset].to_f.round(3)}  n_side=#{geo[:n_side].to_f.round(3)}"

  arc = am.from_chord_and_sag(sx, sy, ex, ey, sag)

  mine.each do |d|
    t  = d.get_attribute(DD, 'position_along_wall_in').to_f
    wd = d.get_attribute(DD, 'width_in').to_f
    cs = d.get_attribute(DD, 'clicked_side').to_i
    cs = 1 if cs == 0
    sfx = d.get_attribute(DD, 'face_x')
    sfy = d.get_attribute(DD, 'face_y')

    g2 = dm.geo_at(geo, t, wd)
    cx = g2[:cline_start].x + g2[:unit].x * t + g2[:n].x * g2[:n_side]
    cy = g2[:cline_start].y + g2[:unit].y * t + g2[:n].y * g2[:n_side]
    nfx, nfy = dm.opening_face_xy_from_center(cx, cy, cs, g2)

    org = d.transformation.origin
    pk = wt.opening_pocket(sx, sy, ex, ey, sag, t, wd)

    puts "  דלת '#{d.get_attribute(DD, 'id').to_s[0, 12]}'  t=#{t.round(2)}  " \
         "רוחב=#{wd.round(2)}  side=#{cs}"
    puts "     face שמור   : #{sfx.nil? ? 'אין' : cd_r(sfx, sfy)}"
    puts "     face מחושב  : #{cd_r(nfx, nfy)}"
    if !sfx.nil?
      dd = Math.hypot(sfx.to_f - nfx, sfy.to_f - nfy)
      puts format('     הפרש בין השניים: %.3f"   %s', dd,
                  dd > 0.05 ? '<<< כאן הבעיה' : '(זהה)')
    end
    puts "     מרכז הפתח   : #{cd_r(cx, cy)}"
    puts "     מקור הדלת   : #{cd_r(org.x, org.y)}  z=#{org.z.round(2)}"
    if pk
      puts "     כיס על הקשת : מרכז #{cd_r(pk[:center][0], pk[:center][1])}  " \
           "כיוון (#{pk[:dir][0].round(3)}, #{pk[:dir][1].round(3)})"
    else
      puts '     כיס על הקשת : nil ***'
    end
    next unless arc
    [['face שמור', sfx.nil? ? nil : [sfx.to_f, sfy.to_f]],
     ['face מחושב', [nfx, nfy]],
     ['מקור הדלת', [org.x.to_f, org.y.to_f]]].each do |nm, p|
      next unless p
      rr = Math.hypot(p[0] - arc[:cx], p[1] - arc[:cy])
      puts format('     %-11s רדיוס מהמרכז=%9.3f   (קו השרטוט=%.3f, פנים/חוץ=%+.3f)',
                  nm, rr, arc[:r], rr - arc[:r])
    end
  end
end

puts '=' * 72
puts '[dbg] סוף. תעתיק לי את כל הפלט.'
