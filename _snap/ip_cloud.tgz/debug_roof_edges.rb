# diagnosis 2026-08-05B: why fascia band crosses gable ends (no rake)
RF = InteriorPro::RoofManager
s = RF.settings
walls = RF.top_walls
ep = RF.eave_polygon(walls, s[:overhang])
poly = ep[:pts]; wall_ids = ep[:wall_ids]
puts "[RoofDbg] style=#{s[:style]} overhang=#{s[:overhang]} fascia=#{s[:fascia]}"
poly.each_with_index { |p, i| puts format('[RoofDbg] poly[%d]=(%.2f, %.2f) wall=%s', i, p[0], p[1], wall_ids[i]) }
marked = RF.gable_wall_ids
puts "[RoofDbg] marked=#{marked.inspect}"
loop_ids = wall_ids.compact
marked = marked.select { |id| loop_ids.include?(id) }
plan = RF.framed_plan(poly, wall_ids, marked, s[:style])
if plan.nil?
  puts '[RoofDbg] framed_plan=NIL (fallback path!)'
else
  puts "[RoofDbg] main=#{plan[:main].map { |v| v.round(2) }.inspect} g=#{plan[:g].inspect}"
  plan[:wings].each_with_index { |w, i| puts "[RoofDbg] wing#{i}: rect=#{w[:rect].map { |v| v.round(2) }.inspect} mouth=#{w[:mouth]} gabled=#{w[:gabled]}" }
  puts "[RoofDbg] edges=#{plan[:edges].inspect}"
  ends = []
  plan[:g].each { |sd, on| ends << [sd, RF.framed_end_line(plan[:main], sd)] if on }
  plan[:wings].each { |w| ends << [w[:mouth], RF.framed_end_line(w[:rect], InteriorPro::RoofManager::OPP_SIDE[w[:mouth]])] if w[:gabled] }
  ends.each { |sd, e| puts "[RoofDbg] end_line #{sd}: #{e.map { |v| v.is_a?(Float) ? v.round(2) : v }.inspect}" }
end
