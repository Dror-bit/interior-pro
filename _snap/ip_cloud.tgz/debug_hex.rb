# debug_hex.rb - READ ONLY. Measures corner gaps + floor/room mismatch.
# Writes hex_report.txt next to this file. Changes nothing in the model.
# Run in Ruby Console:
#   load 'C:/Users/rordt/AppData/Roaming/SketchUp/SketchUp 2024/SketchUp/Plugins/interior_pro/debug_hex.rb'

module InteriorPro
  module DebugHex
    OUT = File.join(File.dirname(__FILE__), 'hex_report.txt')

    def self.f(v)
      v.to_f.round(3)
    end

    def self.groups(type)
      Sketchup.active_model.entities.grep(Sketchup::Group).select do |g|
        g.valid? && g.get_attribute('InteriorPro', 'type') == type
      end
    end

    def self.at(g, k)
      g.get_attribute('InteriorPro', k)
    end

    def self.wpt(g, x, y)
      Geom::Point3d.new(x.to_f, y.to_f, 0).transform(g.transformation)
    end

    def self.wall_rows
      groups('wall').each_with_index.map do |w, i|
        s = wpt(w, at(w, 'start_x'), at(w, 'start_y'))
        e = wpt(w, at(w, 'end_x'), at(w, 'end_y'))
        cx = at(w, 'corners_xy')
        {
          i: i, g: w,
          id: at(w, 'id').to_s,
          lvl: (at(w, 'level') || 1).to_i,
          s: s, e: e,
          th: at(w, 'thickness').to_f,
          anc: at(w, 'anchor').to_s,
          sag: at(w, 'arc_sag').to_f,
          corners: cx.is_a?(Array) ? cx.map { |v| v.to_f.round(3) } : nil,
          ident: w.transformation.identity?
        }
      end
    end

    def self.top_face_pts(grp)
      return nil unless grp && grp.valid?
      t = grp.transformation
      best = nil
      grp.entities.grep(Sketchup::Face).each do |fc|
        n = fc.normal.transform(t)
        next unless n.z > 0.5
        z = fc.vertices.first.position.transform(t).z
        best = [z, fc] if best.nil? || z > best[0]
      end
      return nil unless best
      best[1].outer_loop.vertices.map { |v| v.position.transform(t) }
    end

    def self.poly_max_dist(a, b)
      return nil if a.nil? || b.nil? || a.empty? || b.empty?
      worst = 0.0
      a.each do |p|
        d = b.map { |q| Math.sqrt((p.x.to_f - q.x.to_f)**2 + (p.y.to_f - q.y.to_f)**2) }.min
        worst = d if d > worst
      end
      worst.round(3)
    end

    def self.run
      lines = []
      lines << "InteriorPro debug_hex  #{Time.now}"
      lines << "model: #{Sketchup.active_model.title}"
      lines << ''

      # ---------- walls ----------
      ws = wall_rows
      lines << "== WALLS (#{ws.length}) =="
      by_lvl = ws.group_by { |w| w[:lvl] }
      by_lvl.keys.sort.each { |lv| lines << "  level #{lv}: #{by_lvl[lv].length} wall(s)" }
      lines << ''
      ws.each do |w|
        lines << format('w%-3d lvl=%d th=%-6s anc=%-13s sag=%-8s ident=%s',
                        w[:i], w[:lvl], f(w[:th]), w[:anc], f(w[:sag]), w[:ident])
        lines << format('      drawn  (%s,%s) -> (%s,%s)  len=%s',
                        f(w[:s].x), f(w[:s].y), f(w[:e].x), f(w[:e].y),
                        f(Math.sqrt((w[:e].x.to_f - w[:s].x.to_f)**2 + (w[:e].y.to_f - w[:s].y.to_f)**2)))
        lines << format('      corners_xy=%s  id=%s',
                        w[:corners] ? w[:corners].inspect : 'NONE', w[:id])
      end
      lines << ''

      # ---------- corner gaps ----------
      lines << '== CORNERS (endpoint pairs closer than 12") =='
      lines << '   gap = distance between the two DRAWN endpoints.'
      eps = []
      ws.each do |w|
        eps << { w: w, tag: 'S', p: w[:s] }
        eps << { w: w, tag: 'E', p: w[:e] }
      end
      pairs = []
      eps.each_with_index do |a, ia|
        eps.each_with_index do |b, ib|
          next if ib <= ia
          next if a[:w][:i] == b[:w][:i]
          d = Math.sqrt((a[:p].x.to_f - b[:p].x.to_f)**2 + (a[:p].y.to_f - b[:p].y.to_f)**2)
          next if d > 12.0
          pairs << [d, a, b]
        end
      end
      if pairs.empty?
        lines << '  (none found - walls do not share endpoints at all!)'
      else
        pairs.sort_by! { |p| -p[0] }
        pairs.each do |d, a, b|
          flag = d > 0.05 ? '  <<< GAP' : ''
          same = a[:w][:lvl] == b[:w][:lvl] ? '' : '  (DIFFERENT LEVELS)'
          lines << format('  w%d%s <-> w%d%s  gap=%s  th %s/%s  anc %s/%s  sag %s/%s%s%s',
                          a[:w][:i], a[:tag], b[:w][:i], b[:tag], f(d),
                          f(a[:w][:th]), f(b[:w][:th]), a[:w][:anc], b[:w][:anc],
                          f(a[:w][:sag]), f(b[:w][:sag]), flag, same)
        end
      end
      lines << ''

      # ---------- rooms stored ----------
      rooms = groups('room')
      lines << "== ROOMS stored in model (#{rooms.length}) =="
      rooms.each_with_index do |r, i|
        bx = at(r, 'boundary_xy')
        pts = bx.is_a?(Array) ? bx.each_slice(2).map { |x, y| Geom::Point3d.new(x.to_f, y.to_f, 0) } : []
        lines << format('  room%-2d name=%-12s lvl=%d area=%s pts=%d id=%s',
                        i, at(r, 'name').to_s, (at(r, 'level') || 1).to_i,
                        f(at(r, 'area_sqft')), pts.length, at(r, 'id').to_s)
        lines << ('    boundary: ' + pts.map { |p| "(#{f(p.x)},#{f(p.y)})" }.join(' '))
      end
      lines << ''

      # ---------- fresh detection ----------
      lines << '== ROOMS as detected RIGHT NOW from the live walls =='
      begin
        InteriorPro::RoomManager.wall_levels.each do |lv|
          det = InteriorPro::RoomManager.detect_rooms!(verbose: false, level: lv)
          lines << "  level #{lv}: #{det.length} room(s) detected"
          det.each_with_index do |d, i|
            lines << format('    det%-2d lvl=%d area=%s pts=%d', i, d[:level], f(d[:net_area_sqft]), d[:boundary].length)
            lines << ('      boundary: ' + d[:boundary].map { |p| "(#{f(p.x)},#{f(p.y)})" }.join(' '))
          end
        end
      rescue StandardError => e
        lines << "  detect failed: #{e.class}: #{e.message}"
        lines << ('  ' + e.backtrace.first(4).join("\n  ")) if e.backtrace
      end
      lines << ''

      # ---------- floors ----------
      floors = groups('floor')
      lines << "== FLOORS (#{floors.length}) =="
      floors.each_with_index do |fl, i|
        rid = at(fl, 'room_id')
        room = rooms.find { |r| at(r, 'id') == rid }
        fpts = top_face_pts(fl)
        bx = room ? at(room, 'boundary_xy') : nil
        rpts = bx.is_a?(Array) ? bx.each_slice(2).map { |x, y| Geom::Point3d.new(x.to_f, y.to_f, 0) } : nil
        lines << format('  floor%-2d lvl=%s floor_level=%s th=%s type=%s room_id=%s room_found=%s',
                        i, (at(fl, 'level') || 1).to_i, f(at(fl, 'floor_level')),
                        f(at(fl, 'thickness_in')), at(fl, 'floor_type').to_s, rid.to_s, !room.nil?)
        if fpts
          lines << format('    top face z=%s  pts=%d', f(fpts.first.z), fpts.length)
          lines << ('    outline: ' + fpts.map { |p| "(#{f(p.x)},#{f(p.y)})" }.join(' '))
        else
          lines << '    top face: NOT FOUND'
        end
        if rpts && fpts
          lines << format('    max distance floor-outline -> room-boundary = %s"', poly_max_dist(fpts, rpts))
          lines << format('    max distance room-boundary -> floor-outline = %s"', poly_max_dist(rpts, fpts))
        end
      end
      lines << ''

      # ---------- levels ----------
      lines << '== LEVELS =='
      begin
        if defined?(InteriorPro::LevelManager)
          InteriorPro::RoomManager.wall_levels.each do |lv|
            lines << "  level #{lv} base = #{f(InteriorPro::LevelManager.level_base(lv))}\""
          end
        else
          lines << '  LevelManager not loaded'
        end
      rescue StandardError => e
        lines << "  levels failed: #{e.message}"
      end

      File.open(OUT, 'w') { |fh| fh.puts(lines.join("\n")) }
      puts "[debug_hex] wrote #{OUT}  (#{lines.length} lines)"
      OUT
    rescue StandardError => e
      puts "[debug_hex] FAILED: #{e.class}: #{e.message}"
      puts e.backtrace.first(6)
      nil
    end
  end
end

InteriorPro::DebugHex.run
