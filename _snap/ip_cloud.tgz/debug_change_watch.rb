# encoding: utf-8
# debug_change_watch.rb - READ ONLY. Catches ANY wall changing that nobody
# asked to change.
#
# debug_move_watch.rb only watches the two ENDS of a wall, and on 2026-08-18
# it reported "nothing moved" while the user was still watching a downstairs
# wall follow an upstairs one. So the thing that leaks across floors is not a
# move - it is some other attribute. This watches all of them.
#
# HOW TO USE - the same line twice:
#   1. Ruby Console: load '.../debug_change_watch.rb'   -> SNAPSHOT TAKEN
#   2. Do the thing that breaks, in the 2D editor.
#   3. The SAME line again -> writes change_watch_report.txt
#
# It names the wall you clearly meant to change (most fields changed) and
# lists every OTHER wall that changed as COLLATERAL. Collateral on a
# DIFFERENT LEVEL is the bug.
#
# Nothing is ever written to the model. Delete change_watch_snapshot.txt to
# start over.
module InteriorPro
  module ChangeWatch
    DIR  = File.dirname(__FILE__)
    SNAP = File.join(DIR, 'change_watch_snapshot.txt')
    OUT  = File.join(DIR, 'change_watch_report.txt')

    # Every attribute the plugin stores on a wall that a human can change.
    FIELDS = %w[
      level thickness height anchor wall_type wall_category
      exterior_material interior_material side_a_color side_b_color
      arc_sag corner_board_width start_x start_y end_x end_y
    ].freeze

    def self.walls
      Sketchup.active_model.entities.grep(Sketchup::Group).select do |g|
        g.valid? && g.get_attribute('InteriorPro', 'type') == 'wall'
      end
    end

    def self.state
      walls.map do |g|
        t = g.transformation
        sx = g.get_attribute('InteriorPro', 'start_x').to_f
        sy = g.get_attribute('InteriorPro', 'start_y').to_f
        ex = g.get_attribute('InteriorPro', 'end_x').to_f
        ey = g.get_attribute('InteriorPro', 'end_y').to_f
        s = Geom::Point3d.new(sx, sy, 0).transform(t)
        e = Geom::Point3d.new(ex, ey, 0).transform(t)
        h = { 'ID'       => (g.get_attribute('InteriorPro', 'id') || '?').to_s,
              'ENT'      => g.entityID.to_s,
              'world_sx' => s.x.to_f.round(3).to_s,
              'world_sy' => s.y.to_f.round(3).to_s,
              'world_ex' => e.x.to_f.round(3).to_s,
              'world_ey' => e.y.to_f.round(3).to_s,
              'origin'   => t.origin.to_a.map { |v| v.round(3) }.join(','),
              'openings' => InteriorPro::WallTool.read_door_openings(g)
                              .map { |o| "#{o[:t].round(2)}/#{o[:width].round(2)}" }.join(' ') }
        FIELDS.each { |f| h[f] = g.get_attribute('InteriorPro', f).to_s }
        c = g.get_attribute('InteriorPro', 'corners_xy')
        h['corners'] = c.is_a?(Array) ? c.map { |v| v.to_f.round(2) }.join(',') : ''
        h
      end
    rescue StandardError => e
      puts "[ChangeWatch] state: #{e.message}"
      []
    end

    def self.save(st)
      File.open(SNAP, 'w') do |f|
        st.each { |w| f.puts w.map { |k, v| "#{k}=#{v}" }.join("\t") }
      end
    end

    def self.load_snap
      return nil unless File.exist?(SNAP)
      File.readlines(SNAP).map do |line|
        h = {}
        line.chomp.split("\t").each do |pair|
          k, v = pair.split('=', 2)
          h[k] = v.to_s
        end
        h
      end
    rescue StandardError
      nil
    end

    def self.run
      now = state
      before = load_snap
      if before.nil?
        save(now)
        UI.messagebox("SNAPSHOT TAKEN - #{now.size} wall(s).\n\n" \
                      "Now do the thing that breaks, then run this line again.")
        return
      end

      by_id = {}
      before.each { |w| by_id[w['ID']] = w }
      o = []
      o << '=' * 74
      o << "CHANGE WATCH   #{Time.now}"
      o << '=' * 74
      o << "#{before.size} wall(s) before, #{now.size} now"
      o << ''

      changed = []
      now.each do |w|
        old = by_id[w['ID']]
        if old.nil?
          changed << { w: w, diffs: [['(wall)', '-', 'NEW - was not in the snapshot']] }
          next
        end
        diffs = []
        w.each do |k, v|
          next if k == 'ID' || k == 'ENT'
          diffs << [k, old[k].to_s, v.to_s] if old[k].to_s != v.to_s
        end
        changed << { w: w, diffs: diffs } unless diffs.empty?
      end
      gone = before.reject { |b| now.any? { |w| w['ID'] == b['ID'] } }

      if changed.empty? && gone.empty?
        o << 'NOTHING CHANGED AT ALL. Either the edit was undone, or it never'
        o << 'reached a wall. Take a fresh snapshot and try again.'
      else
        # The wall you MEANT: the one with the most fields changed.
        intended = changed.max_by { |c| c[:diffs].size }
        o << "THE WALL YOU MEANT (most fields changed):"
        o << "  id=#{intended[:w]['ID']}  level=#{intended[:w]['level']}  entityID=#{intended[:w]['ENT']}"
        intended[:diffs].each { |k, a, b| o << "    #{k}: #{a}  ->  #{b}" }
        o << ''
        others = changed - [intended]
        cross = others.select { |c| c[:w]['level'].to_s != intended[:w]['level'].to_s }
        o << "COLLATERAL - walls that changed and you did not ask them to: #{others.size}"
        o << "  of those, on a DIFFERENT LEVEL: #{cross.size}   <== THE BUG"
        o << ''
        others.each do |c|
          flag = c[:w]['level'].to_s != intended[:w]['level'].to_s ? '  <== DIFFERENT LEVEL' : ''
          o << "  id=#{c[:w]['ID']}  level=#{c[:w]['level']}  entityID=#{c[:w]['ENT']}#{flag}"
          c[:diffs].each { |k, a, b| o << "      #{k}: #{a}  ->  #{b}" }
          o << ''
        end
        unless gone.empty?
          o << "WALLS THAT DISAPPEARED: #{gone.size}"
          gone.each { |b| o << "  id=#{b['ID']} level=#{b['level']}" }
        end
      end

      File.open(OUT, 'w') { |f| f.puts o.join("\n") }
      save(now)
      UI.messagebox("Compared. Report written:\n#{OUT}\n\n(new snapshot taken)")
      nil
    end
  end
end
InteriorPro::ChangeWatch.run
