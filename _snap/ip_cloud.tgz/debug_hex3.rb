# debug_hex3.rb - READ ONLY. Round 3: how did the walls get moved?
# Writes hex_report3.txt next to this file. Changes NOTHING.
# Every step is wrapped, and any error is written INTO the report.
# Ruby Console:
#   load 'C:/Users/rordt/AppData/Roaming/SketchUp/SketchUp 2024/SketchUp/Plugins/interior_pro/debug_hex3.rb'

module InteriorPro
  module DebugHex3
    OUT = File.join(File.dirname(__FILE__), 'hex_report3.txt')

    def self.n(v)
      return 'nil' if v.nil?
      v.to_f.round(3).to_s
    rescue StandardError
      v.inspect
    end

    def self.groups(type)
      Sketchup.active_model.entities.grep(Sketchup::Group).select do |g|
        g.valid? && g.get_attribute('InteriorPro', 'type') == type
      end
    rescue StandardError
      []
    end

    def self.at(g, k)
      g.get_attribute('InteriorPro', k)
    rescue StandardError
      nil
    end

    def self.run
      out = []
      out << "InteriorPro debug_hex3  #{Time.now}"

      begin
        out << ''
        out << '== WALL GROUP TRANSFORMATIONS =='
        out << '   A wall the plugin made and lifted should have translation'
        out << '   x=0 y=0 and z = its level base. Anything else means the'
        out << '   GROUP itself was moved (native SketchUp move / copy).'
        out << ''
        groups('wall').each_with_index do |w, i|
          begin
            t = w.transformation
            o = t.origin
            xa = t.xaxis
            ya = t.yaxis
            za = t.zaxis
            rot = ((xa.x - 1.0).abs > 1e-6) || (xa.y.abs > 1e-6) ||
                  ((ya.y - 1.0).abs > 1e-6) || (ya.x.abs > 1e-6) ||
                  ((za.z - 1.0).abs > 1e-6)
            out << format('w%-3d lvl=%s anc=%-13s th=%-6s base_z=%-9s T=(%s, %s, %s) rot_or_scale=%s',
                          i, (at(w, 'level') || 1).to_i.to_s, at(w, 'anchor').to_s,
                          n(at(w, 'thickness')), n(at(w, 'base_z')),
                          n(o.x), n(o.y), n(o.z), rot.to_s)
            out << format('      xaxis=(%s,%s,%s)  yaxis=(%s,%s,%s)  zaxis=(%s,%s,%s)',
                          n(xa.x), n(xa.y), n(xa.z), n(ya.x), n(ya.y), n(ya.z),
                          n(za.x), n(za.y), n(za.z))
            d = w.attribute_dictionary('InteriorPro', false)
            out << ('      attr keys: ' + (d ? d.keys.sort.join(', ') : 'NONE'))
          rescue StandardError => e
            out << "  w#{i}: ERROR #{e.class}: #{e.message}"
          end
        end
      rescue StandardError => e
        out << "WALL SECTION FAILED: #{e.class}: #{e.message}"
      end

      begin
        out << ''
        out << '== FLOORS =='
        groups('floor').each_with_index do |fl, i|
          d = fl.attribute_dictionary('InteriorPro', false)
          out << format('  floor%-2d drop_walls=%s floor_level=%s level=%s',
                        i, at(fl, 'drop_walls').inspect, n(at(fl, 'floor_level')),
                        at(fl, 'level').inspect)
          out << ('      attr keys: ' + (d ? d.keys.sort.join(', ') : 'NONE'))
        end
      rescue StandardError => e
        out << "FLOOR SECTION FAILED: #{e.class}: #{e.message}"
      end

      begin
        out << ''
        out << '== ROOMS =='
        groups('room').each_with_index do |r, i|
          out << format('  room%-2d name=%s level=%s id=%s', i, at(r, 'name').to_s,
                        at(r, 'level').inspect, at(r, 'id').to_s)
        end
      rescue StandardError => e
        out << "ROOM SECTION FAILED: #{e.class}: #{e.message}"
      end

      begin
        out << ''
        out << '== ALL InteriorPro GROUP TYPES IN THE MODEL =='
        seen = Hash.new(0)
        Sketchup.active_model.entities.grep(Sketchup::Group).each do |g|
          next unless g.valid?
          ty = g.get_attribute('InteriorPro', 'type')
          seen[ty.to_s] += 1 if ty
        end
        seen.sort.each { |k, v| out << "  #{k}: #{v}" }
      rescue StandardError => e
        out << "TYPES SECTION FAILED: #{e.class}: #{e.message}"
      end

      begin
        File.open(OUT, 'w') { |fh| fh.puts(out.join("\n")) }
        puts "[debug_hex3] wrote #{OUT}  (#{out.length} lines)"
      rescue StandardError => e
        puts "[debug_hex3] COULD NOT WRITE: #{e.class}: #{e.message}"
      end
      OUT
    end
  end
end

InteriorPro::DebugHex3.run
