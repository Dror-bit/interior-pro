# encoding: utf-8
# Interior Pro - which roof lines get a ridge cap and which do not (2026-08-12B).
#
# v2. The first version fed ridge_lines EVERY face in the roof group. With a
# thickened slab that is two shells, and ridge_lines keys an edge by x,y only -
# so each ridge showed up twice at two different heights, failed its own z test,
# and the script reported zero lines. Nothing to do with the real bug.
#
# This version rebuilds the roof as a BARE SHEET first (thickness 0, no caps),
# which is exactly the surface the caps are read off, then repeats ridge_lines'
# own tests one at a time and says which test each edge failed. The roof is put
# back the way it was at the end.
#
# Ruby Console (one line):
#   load 'C:/Users/rordt/AppData/Roaming/SketchUp/SketchUp 2024/SketchUp/Plugins/interior_pro/debug_ridge_caps.rb'

begin
  InteriorPro.reload!
rescue StandardError => e
  puts "[dbg] reload נכשל: #{e.message}"
end

def rc_p(p)
  "(#{p[0].to_f.round(1)}, #{p[1].to_f.round(1)})"
end

RM = InteriorPro::RoofManager
s0 = RM.settings.dup

puts '=' * 74
ep = RM.eave_polygon(RM.top_walls, s0[:overhang])
if ep.nil?
  puts '[dbg] eave_polygon החזיר nil - אין לולאת קירות סגורה'
else
  poly = ep[:pts]
  ids  = ep[:wall_ids]
  fan  = RM.facet_hip_points(poly, ids)
  soft = RM.respond_to?(:soft_hip_points) ? RM.soft_hip_points(poly, ids) : []
  puts "[dbg] eave: #{poly.length} נקודות   מעוגלים=#{ids.compact.tally.select { |_i, c| c > 1 }.values.inspect}"
  puts "[dbg] מניפה=#{fan.length}  חיבור-חלק=#{soft.length}  style=#{s0[:style]}  " \
       "ridge_cap=#{s0[:ridge_cap]}  עובי=#{s0[:thickness]}"

  # ---- one bare shell, exactly what the caps are read off ----------------
  sheet = RM.build_roof!(thickness: 0.0, ridge_cap: false)
  if sheet.nil?
    puts '[dbg] build_roof! (sheet) נכשל'
  else
    faces = sheet.entities.grep(Sketchup::Face)
    sloped = faces.select { |f| RM.face_gradient(f) }
    puts "[dbg] פאות בשכבה אחת=#{faces.length}   מתוכן משופעות=#{sloped.length}"

    edges = Hash.new { |h, k| h[k] = [] }
    sloped.each do |f|
      pts = RM.face_points(f)
      next if pts.nil? || pts.length < 3
      grad = RM.face_gradient(f)
      cen = [pts.map(&:x).inject(:+) / pts.length.to_f,
             pts.map(&:y).inject(:+) / pts.length.to_f]
      pts.each_index do |i|
        a = pts[i]
        b = pts[(i + 1) % pts.length]
        ka = [a.x.round(3), a.y.round(3)]
        kb = [b.x.round(3), b.y.round(3)]
        next if ka == kb
        if (ka <=> kb) <= 0
          edges[[ka, kb]] << [a.z, b.z, grad, cen]
        else
          edges[[kb, ka]] << [b.z, a.z, grad, cen]
        end
      end
    end

    # THE AUTHORITATIVE ANSWER - ask the real code, never a copy of it.
    # v2 of this script re-implemented ridge_lines' tests inline and then kept
    # reporting the OLD rule after the code had already been fixed. Never again:
    # the pass/fail list below comes from RoofManager itself, and the inline
    # tests are only used to EXPLAIN why an edge it rejected was rejected.
    real = RM.ridge_lines(sloped)
    real_keys = real.map { |l| [l[0], l[2]].sort }

    rows = []
    edges.each do |(ka, kb), recs|
      len = Math.hypot(kb[0] - ka[0], kb[1] - ka[1])
      next if len < 12.0                       # ignore crumbs
      why = nil
      if recs.length < 2
        why = "רק #{recs.length} פאה על הקו (צריך 2)"
      else
        za = recs[0][0]
        zb = recs[0][1]
        unless recs.all? { |r| (r[0] - za).abs < 0.05 && (r[1] - zb).abs < 0.05 }
          why = 'הגבהים לא זהים בין הפאות'
        end
      end
      if why.nil?
        d = [kb[0] - ka[0], kb[1] - ka[1]]
        dl = Math.hypot(d[0], d[1])
        u = [-d[1] / dl, d[0] / dl]
        mid = [(ka[0] + kb[0]) / 2.0, (ka[1] + kb[1]) / 2.0]
        sides = recs.map do |(_za, _zb, grad, cen)|
          sgn = ((u[0] * (cen[0] - mid[0])) + (u[1] * (cen[1] - mid[1]))) >= 0.0 ? 1.0 : -1.0
          [sgn, (grad[0] * u[0] + grad[1] * u[1]) * sgn]
        end
        if sides.all? { |(_s, dz)| dz > -1.0e-6 }
          why = format('מרזב - שום צד לא יורד (dz=%s)', sides.map { |x| x[1].round(3) }.inspect)
        elsif sides.map(&:first).uniq.length < 2
          why = 'שתי הפאות באותו צד של הקו'
        end
      end
      rows << [ka, kb, len, recs.length, why, recs[0][0], recs[0][1]]
    end

    # split by what the REAL ridge_lines decided, not by the inline copy
    good = rows.select { |r| real_keys.include?([r[0], r[1]].sort) }
    bad  = rows.reject { |r| real_keys.include?([r[0], r[1]].sort) }
    kept = RM.drop_facet_hips(real, poly, ids)
    tossed = real.length - kept.length
    puts "[dbg] ridge_lines האמיתי מצא #{real.length} קווים"

    puts '-' * 74
    puts "[dbg] קווים שעברו את כל המבחנים: #{good.length}   " \
         "מתוכם נזרקו ע\"י drop_facet_hips: #{tossed}   מקבלים קאפ: #{kept.length}"
    good.each do |r|
      on = kept.any? { |l| [l[0], l[2]].sort == [r[0], r[1]].sort }
      puts format('   %-20s -> %-20s  אורך=%7.1f  z=%6.1f..%6.1f  %s',
                  rc_p(r[0]), rc_p(r[1]), r[2], r[5], r[6], on ? 'קאפ' : '<< נזרק')
    end
    puts '-' * 74
    puts "[dbg] קווים שנפסלו (#{bad.length}) - זו הרשימה שמעניינת אותנו:"
    bad.sort_by { |r| -r[2] }.first(25).each do |r|
      puts format('   %-20s -> %-20s  אורך=%7.1f  פאות=%d   %s',
                  rc_p(r[0]), rc_p(r[1]), r[2], r[3], r[4])
    end

    arcs = RM.straight_skeleton(poly)
    if arcs
      puts '-' * 74
      puts "[dbg] קווי השלד (#{arcs.length}) שאין להם קו-רכס שעבר:"
      arcs.each do |a|
        hit = real.any? do |l|
          (Math.hypot(l[0][0] - a[0][0], l[0][1] - a[0][1]) < 1.0 &&
           Math.hypot(l[2][0] - a[1][0], l[2][1] - a[1][1]) < 1.0) ||
            (Math.hypot(l[0][0] - a[1][0], l[0][1] - a[1][1]) < 1.0 &&
             Math.hypot(l[2][0] - a[0][0], l[2][1] - a[0][1]) < 1.0)
        end
        next if hit
        puts format('   חסר: %-20s -> %-20s  אורך=%7.1f',
                    rc_p(a[0]), rc_p(a[1]),
                    Math.hypot(a[1][0] - a[0][0], a[1][1] - a[0][1]))
      end
    end
  end

  # ---- put the real roof back -------------------------------------------
  RM.build_roof!(thickness: s0[:thickness], ridge_cap: s0[:ridge_cap])
  puts '[dbg] הגג האמיתי נבנה מחדש כמו שהיה.'
end

puts '=' * 74
puts '[dbg] סוף. תעתיק לי את כל הפלט.'
