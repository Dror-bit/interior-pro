# encoding: utf-8
# debug_layout_spike.rb — does the LayOut road actually work on this machine?
#
# Proves the whole pipeline in one go, with nothing built yet:
#   save the model -> new LayOut document -> put the model on the page ->
#   top view, orthographic, 1/4" = 1'-0" -> render -> export a PDF.
#
# Prints ONE line. If it says OK and a PDF lands on the Desktop, the plan
# sheets can be built this way. If it fails, the line says where.
#
#   load File.join(InteriorPro::PLUGIN_DIR, 'debug_layout_spike.rb')

module InteriorPro
  module LayoutSpike
    SCALE_QUARTER_INCH = 1.0 / 48.0   # 1/4" on paper = 1'-0" in the model

    def self.desktop
      home = ENV['USERPROFILE'] || ENV['HOME'] || '.'
      d = File.join(home.tr('\\', '/'), 'Desktop')
      File.directory?(d) ? d : home.tr('\\', '/')
    end

    def self.run!
      model = Sketchup.active_model

      unless defined?(Layout::Document)
        return 'FAIL: no LayOut API in this SketchUp — option 1 is out.'
      end

      path = model.path.to_s
      if path.empty?
        return 'FAIL: save the SketchUp model to a file first (File > Save), then run this again.'
      end
      model.save(path)   # make sure LayOut reads what is on screen right now

      doc = Layout::Document.new
      page = doc.pages.first
      layer = doc.layers.first
      return 'FAIL: the new LayOut document has no page or layer.' unless page && layer

      # A window on the sheet, in inches of paper.
      bounds = Geom::Bounds2d.new(0.5, 0.5, 10.0, 7.5)
      view = Layout::SketchUpModel.new(path, bounds)
      doc.add_entity(view, layer, page)

      # Scale only works on an orthographic view, so switch it off perspective
      # BEFORE asking for a scale.
      view.perspective = false if view.respond_to?(:perspective=)
      view.view = Layout::SketchUpModel::TOP_VIEW if view.respond_to?(:view=)
      scale_ok = begin
        view.scale = SCALE_QUARTER_INCH
        true
      rescue StandardError => e
        "scale refused (#{e.message})"
      end
      view.render if view.respond_to?(:render)

      pdf = File.join(desktop, 'InteriorPro_layout_test.pdf')
      lay = File.join(desktop, 'InteriorPro_layout_test.layout')
      doc.save(lay) if doc.respond_to?(:save)
      doc.export(pdf)

      if File.exist?(pdf) && File.size(pdf) > 1000
        "OK: PDF on your Desktop (#{File.size(pdf) / 1024} KB). scale=#{scale_ok}"
      else
        'FAIL: export ran but no PDF appeared on the Desktop.'
      end
    rescue StandardError => e
      "FAIL: #{e.class} — #{e.message}"
    end
  end
end

puts InteriorPro::LayoutSpike.run!
