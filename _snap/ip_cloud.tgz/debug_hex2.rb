# debug_hex2.rb - READ ONLY. Round 2: world-space corners + floor_level truth.
# Writes hex_report2.txt next to this file. Changes NOTHING in the model.
# Ruby Console:
#   load 'C:/Users/rordt/AppData/Roaming/SketchUp/SketchUp 2024/SketchUp/Plugins/interior_pro/debug_hex2.rb'

module InteriorPro
  module DebugHex2
    OUT = File.join(File.dirname(__FILE__), 'hex_report2.txt')

    def self.f(v)
      v.nil? ? 'nil' : v.to_f.round(3)
    end

    def self.groups(type)
      Sketchup.active_model.entities.grep(Sketchup::Group).select do |g|
        g.valid? && g.get_attribute('InteriorPro', 'type') == type
      end
    end

    def self.at(g, k)
      g.get_attribute('InteriorPro', k)
    end

    def self.wp(g, x, y)
      Geom::Point3d.new(x.to_f, y.to_f, 0).transform(g.transformation)
    end

    def self.d2(a, b)
      Math.sqrt((a.x.to_f - b.x.to_f)**2 + (a.y.to_f - b.y.to_f)**2)
    end

    def self.ps(p)
      "(#{p.x.to_f.round(2)},#{p.y.to_f.round(2)})"
    end

    def self.run
      out = []
      out << "InteriorPro debug_hex2  #{Time.now}"
      out << ''

      wt = InteriorPro::WallTool.new
      walls = groups('wall')

      # ---------- per wall: world corners + is corners_xy stale? ----------
      out << '== WALLS: stored footprint (WORLD) vs the plain square footprint =='
      out << '   stale = the wall was moved/stretched but corners_xy was not redone.'
      info = []
      walls.each_with_index do |w, i|
        sx = at(w, 'start_x'); sy = at(w, 'start_y')
        ex = at(w, 'end_x');   ey = at(w, 'end_y')
        s = wp(w, sx, sy); e = wp(w, ex, ey)
        flat = at(w, 'corners_xy')
        cw = flat.is_a?(Array) ? flat.each_slice(2).map { |x, y| wp(w, x, y) } : nil
        exp = nil
        begin
          data = wt.wall_data(w)
          if data
            pc = wt.perpendicular_corners_xy(Geom::Point3d.new(sx.to_f, sy.to_f, 0),
                                             Geom::Point3d.new(ex.to_f, ey.to_f, 0),
                                             data[:thickness], data[:h_anchor])
            exp = pc.map { |p| p.transform(w.transformation) } if pc
          end
        rescue StandardError => err
          out << "    (wall_data failed on w#{i}: #{err.message})"
        end
        stale = nil
        if cw && exp && cw.length == exp.length
          stale = 0.0
          cw.each_with_index { |p, k| dd = d2(p, exp[k]); stale = dd if dd > stale }
        end
        info << { i: i, g: w, s: s, e: e, cw: cw, lvl: (at(w, 'level') || 1).to_i,
                  th: at(w, 'thickness').to_f, anc: at(w, 'anchor').to_s,
                  ident: w.transformation.identity?, stale: stale, id: at(w, 'id').to_s }
        out << format('w%-3d lvl=%d anc=%-13s ident=%-5s  drawn %s -> %s',
                    i, (at(w, 'level') || 1).to_i, at(w, 'anchor').to_s,
                    w.transformation.identity?.to_s, ps(s), ps(e))
        out << ('      world corners: ' + (cw ? cw.map { |p| ps(p) }.join(' ') : 'NONE'))
        out << format('      corners_xy off the plain square by up to %s"%s',
                    stale.nil? ? '?' : stale.round(3),
                    (stale && stale > 0.05) ? '   <<< STALE' : '')
      end
      out << ''

      # duplicate ids
      out << '== DUPLICATE WALL IDS =='
      byid = {}
      info.each { |x| (byid[x[:id]] ||= []) << x[:i] }
      dups = byid.select { |_k, v| v.length > 1 }
      if dups.empty?
        out << '  none'
      else
        dups.each { |k, v| out << "  id #{k} used by walls #{v.inspect}" }
      end
      out << ''

      # ---------- real geometric gaps between neighbours ----------
      out << '== NEIGHBOUR GAPS (same level, drawn ends within 12") =='
      out << '   gap = closest distance between the two stored WORLD footprints.'
      info.each_with_index do |a, ia|
        info.each_with_index do |b, ib|
          next if ib <= ia
          next unless a[:lvl] == b[:lvl]
          ends_a = [a[:s], a[:e]]
          ends_b = [b[:s], b[:e]]
          near = ends_a.product(ends_b).map { |p, q| d2(p, q) }.min
          next if near > 12.0
          gap = nil
          if a[:cw] && b[:cw]
            gap = a[:cw].product(b[:cw]).map { |p, q| d2(p, q) }.min
          end
          out << format('  w%-3d <-> w%-3d lvl=%d  drawn-end gap=%s"  footprint gap=%s"%s',
                      a[:i], b[:i], a[:lvl], near.round(3),
                      gap.nil? ? '?' : gap.round(3),
                      (gap && gap > 0.05) ? '   <<< OPEN CORNER' : '')
        end
      end
      out << ''

      # ---------- floors: the truth about floor_level ----------
      out << '== FLOORS: is floor_level actually stored? =='
      rooms = groups('room')
      groups('floor').each_with_index do |fl, i|
        rid = at(fl, 'room_id')
        room = rooms.find { |r| at(r, 'id') == rid }
        raw = fl.attribute_dictionary('InteriorPro', false)
        has = raw ? raw.keys.include?('floor_level') : false
        z = nil
        fl.entities.grep(Sketchup::Face).each do |fc|
          n = fc.normal.transform(fl.transformation)
          next unless n.z > 0.5
          zz = fc.vertices.first.position.transform(fl.transformation).z
          z = zz if z.nil? || zz > z
        end
        out << format('  floor%-2d room_lvl=%s  floor_level KEY PRESENT=%s  value=%s  top z=%s  group origin z=%s',
                    i, room ? ((at(room, 'level') || 1).to_i).to_s : '?',
                    has, f(at(fl, 'floor_level')), f(z), f(fl.transformation.origin.z))
      end
      out << ''
      out << '== what the code WOULD put there for a level-2 room =='
      begin
        out << "  LevelManager.level_base(2) = #{f(InteriorPro::LevelManager.level_base(2))}\""
      rescue StandardError => e
        out << "  level_base failed: #{e.message}"
      end

      File.open(OUT, 'w') { |fh| fh.puts(out.join("\n")) }
      puts "[debug_hex2] wrote #{OUT}"
      OUT
    rescue StandardError => e
      puts "[debug_hex2] FAILED: #{e.class}: #{e.message}"
      puts e.backtrace.first(6)
      nil
    end
  end
end

InteriorPro::DebugHex2.run
