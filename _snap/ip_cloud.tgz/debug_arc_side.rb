# Interior Pro - trace: which way does a positive bow (sag) actually go?
# Read-only. Changes nothing in the model.
#
# Ruby Console:
#   load 'C:/Users/rordt/AppData/Roaming/SketchUp/SketchUp 2024/SketchUp/Plugins/interior_pro/debug_arc_side.rb'

module InteriorPro
  module DebugArcSide
    D = 'InteriorPro'.freeze

    def self.all_walls
      Sketchup.active_model.active_entities.grep(Sketchup::Group)
              .select { |g| g.get_attribute(D, 'type') == 'wall' }
    end

    def self.run
      all = all_walls
      if all.empty?
        puts '[trace] no walls in this model'
        return nil
      end

      # Middle of the house = average of all wall midpoints.
      cx = 0.0
      cy = 0.0
      all.each do |g|
        cx += (g.get_attribute(D, 'start_x').to_f + g.get_attribute(D, 'end_x').to_f) / 2.0
        cy += (g.get_attribute(D, 'start_y').to_f + g.get_attribute(D, 'end_y').to_f) / 2.0
      end
      cx /= all.size
      cy /= all.size
      puts "[trace] walls=#{all.size}  house centre ~ (#{cx.round(2)}, #{cy.round(2)})"

      sel = Sketchup.active_model.selection.grep(Sketchup::Group)
                    .select { |g| g.get_attribute(D, 'type') == 'wall' }
      sel = all if sel.empty?
      puts "[trace] reporting #{sel.size} wall(s)#{sel.equal?(all) ? ' (nothing selected -> all)' : ''}"

      sel.each do |g|
        sx = g.get_attribute(D, 'start_x').to_f
        sy = g.get_attribute(D, 'start_y').to_f
        ex = g.get_attribute(D, 'end_x').to_f
        ey = g.get_attribute(D, 'end_y').to_f
        sag = g.get_attribute(D, 'arc_sag').to_f
        len = Math.hypot(ex - sx, ey - sy)
        next if len < 1e-6

        ux = (ex - sx) / len
        uy = (ey - sy) / len
        lx = -uy                       # LEFT of start->end  = positive sag
        ly = ux
        rx = uy                        # RIGHT of start->end = plugin's exterior side
        ry = -ux

        mx = (sx + ex) / 2.0
        my = (sy + ey) / 2.0
        out_dot = (mx - cx) * rx + (my - cy) * ry
        away = out_dot >= 0 ? 'RIGHT' : 'LEFT'
        pos_means = (away == 'LEFT') ? 'OUTWARD (out of the house)' : 'INWARD (into the house)'

        bow = if sag.abs < 0.0625
                'straight'
              elsif sag > 0
                'LEFT'
              else
                'RIGHT'
              end
        now = if bow == 'straight'
                '-'
              elsif bow == away
                'OUTWARD'
              else
                'INWARD'
              end

        puts '--------------------------------------------------'
        puts "id=#{g.get_attribute(D, 'id')}  anchor=#{g.get_attribute(D, 'anchor')}  th=#{g.get_attribute(D, 'thickness')}"
        puts "  start=(#{sx.round(2)}, #{sy.round(2)})   end=(#{ex.round(2)}, #{ey.round(2)})"
        puts "  left  normal = (#{lx.round(3)}, #{ly.round(3)})"
        puts "  right normal = (#{rx.round(3)}, #{ry.round(3)})   <- plugin calls this the exterior side"
        puts "  side pointing AWAY from the house = #{away}   (dot=#{out_dot.round(2)})"
        puts "  arc_sag = #{sag.round(3)}  -> bulges #{bow}  -> that is #{now}"
        puts "  ==> typing a POSITIVE number bows this wall #{pos_means}"
      end
      nil
    end
  end
end

InteriorPro::DebugArcSide.run
