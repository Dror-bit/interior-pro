# encoding: utf-8
# debug_roof_loop.rb - READ ONLY. Why does the roof say
# "No closed loop of exterior walls to roof yet"?
#
# It runs the EXACT chain build_roof! runs - top_walls -> centerline ->
# build_graph -> trace_faces - and stops at the first step that comes back
# empty, so the answer is the real one and not a guess.
#
# The decisive number is the NODE DEGREE. In a closed ring every corner has
# exactly 2 walls meeting at it. A node with only 1 is a loose end: that is
# the hole, and its coordinates are printed.
#
# Ruby Console:
#   load 'C:/Users/rordt/AppData/Roaming/SketchUp/SketchUp 2024/SketchUp/Plugins/interior_pro/debug_roof_loop.rb'
# Report: roof_loop_report.txt next to the plugin. Nothing is changed.

module InteriorPro
  module RoofLoopProbe
    OUT = File.join(File.dirname(__FILE__), 'roof_loop_report.txt')

    def self.run
      rm  = InteriorPro::RoomManager
      rf  = InteriorPro::RoofManager
      lm  = InteriorPro::LevelManager
      out = []
      out << '=' * 70
      out << "ROOF LOOP PROBE  (read only)   #{Time.now}"
      out << '=' * 70

      lvl = rf.top_level
      out << "top_level = #{lvl.inspect}"

      all = lm.walls_of_level(lvl)
      out << "walls on that level: #{all.length}"
      ext = all.select do |w|
        (w.get_attribute('InteriorPro', 'wall_category') || 'exterior') == 'exterior'
      end
      out << "of them EXTERIOR: #{ext.length}"
      out << (ext.empty? ? '  -> none exterior, so it falls back to ALL of them' : '')

      walls = rf.top_walls
      out << "top_walls hands the roof #{walls.length} wall(s)"
      out << ''
      out << 'WALL                                     cat        length   centreline'
      out << '-' * 100
      segs = []
      walls.each do |w|
        id  = (w.get_attribute('InteriorPro', 'id') || '?').to_s
        cat = (w.get_attribute('InteriorPro', 'wall_category') || 'exterior').to_s
        cl  = rm.centerline(w)
        if cl.nil?
          out << format('  %-38s %-10s   %s', id[0, 38], cat, 'NO CENTRELINE - skipped!')
          next
        end
        segs << cl
        len = Math.sqrt((cl[:e].x - cl[:s].x)**2 + (cl[:e].y - cl[:s].y)**2)
        out << format('  %-38s %-10s %7.2f   (%.2f,%.2f) -> (%.2f,%.2f)',
                      id[0, 38], cat, len, cl[:s].x, cl[:s].y, cl[:e].x, cl[:e].y)
      end
      out << ''
      out << "centrelines that survived: #{segs.length}  (needs 3 or more)"

      if segs.length < 3
        out << '>>> STOPS HERE: fewer than 3 centrelines.'
        return write(out)
      end

      nodes, edges = rm.build_graph(segs)
      out << "graph: #{nodes.length} node(s), #{edges.length} edge(s)"
      out << ''

      deg = Hash.new(0)
      edges.each { |e| deg[e[:a]] += 1; deg[e[:b]] += 1 }
      loose = deg.select { |_, d| d < 2 }
      tee   = deg.select { |_, d| d > 2 }

      out << 'THE ANSWER IS HERE'
      out << '-' * 70
      if loose.empty?
        out << 'every corner has 2 or more walls - no loose ends.'
      else
        out << ">>> #{loose.length} LOOSE END(S) - this is the hole in the ring:"
        loose.each do |i, d|
          p = nodes[i]
          near = edges.select { |e| e[:a] == i || e[:b] == i }
                      .map { |e| (e[:wall].get_attribute('InteriorPro', 'id') || '?').to_s[0, 8] }
          out << format('    node %-3d degree %d at (%.3f, %.3f)   wall(s): %s',
                        i, d, p.x, p.y, near.join(', '))
          # what is the nearest OTHER node? that distance is the size of the gap
          best = nil
          nodes.each_with_index do |q, j|
            next if j == i
            dd = Math.sqrt((q.x - p.x)**2 + (q.y - p.y)**2)
            best = [dd, j] if best.nil? || dd < best[0]
          end
          out << format('        nearest other corner is %.3f" away (node %d)', best[0], best[1]) if best
        end
      end
      out << ''
      out << (tee.empty? ? 'no T junctions in the ring.' :
              "#{tee.length} node(s) with 3+ walls (T junctions): #{tee.keys.inspect}")

      faces = rm.trace_faces(nodes, edges)
      out << ''
      out << "trace_faces found #{faces.length} closed face(s)"
      big = 0.0
      faces.each_with_index do |f, i|
        poly = f[:node_ids].map { |n| nodes[n] }
        a = rm.signed_area(poly)
        big = a if a > big
        out << format('  face %-3d %d corner(s)  signed area %12.1f sq in  (%.1f sq ft)',
                      i, poly.length, a, a / 144.0)
      end
      out << ''
      if faces.empty?
        out << '>>> STOPS HERE: no closed face at all. The ring is open.'
      elsif big <= 144.0
        out << format('>>> STOPS HERE: the biggest face is only %.1f sq in;', big)
        out << '    eave_polygon ignores anything under 144 sq in (1 sq ft).'
      else
        out << format('the biggest face is %.1f sq ft, which is accepted.', big / 144.0)
        ep = rf.eave_polygon(walls, rf.settings[:overhang])
        out << (ep.nil? ? '>>> but eave_polygon STILL returned nil - the failure is in outer_offset.'
                        : "eave_polygon succeeded: #{ep[:pts].length} corners. The roof should build.")
      end

      write(out)
    rescue StandardError => e
      write(["PROBE CRASHED: #{e.class}: #{e.message}"] + e.backtrace.first(8))
    end

    def self.write(lines)
      File.open(OUT, 'w') { |f| f.puts(lines.join("\n")) }
      puts "[RoofLoopProbe] written: #{OUT}"
      OUT
    end
  end
end

InteriorPro::RoofLoopProbe.run
