# encoding: utf-8
# Landscape Pro - measure what the reference fence tool ACTUALLY placed
# (2026-08-17). Writes landscape/reference/placed_report.txt.
#
#   Ruby Console:
#     load 'C:/Users/rordt/AppData/Roaming/SketchUp/SketchUp 2024/SketchUp/Plugins/interior_pro/debug_fence_placed.rb'

module InteriorPro
  module Landscape
    module PlacedDebug
      def self.run!
        out = []
        m = Sketchup.active_model
        fences = m.entities.grep(Sketchup::Group).select { |g| g.get_attribute('LandscapePro', 'type') == 'fence' }
        out << "fences in model: #{fences.length}"
        fences.each_with_index do |g, gi|
          out << ''
          out << "== fence #{gi} (#{g.get_attribute('LandscapePro', 'reference')}) =="
          bb = g.bounds
          out << format('  group bounds: %.3f x %.3f x %.3f   (w x d x h)', bb.width.to_f, bb.height.to_f, bb.depth.to_f)
          out << format('  attrs: units=%s stretch=%s unit_along=%s height=%s',
                        g.get_attribute('LandscapePro', 'units'), g.get_attribute('LandscapePro', 'stretch'),
                        g.get_attribute('LandscapePro', 'unit_along'), g.get_attribute('LandscapePro', 'height'))
          out << format('  group transformation: %s', fmt_t(g.transformation))
          g.entities.each do |e|
            next unless e.is_a?(Sketchup::ComponentInstance) || e.is_a?(Sketchup::Group)
            nm = e.respond_to?(:definition) ? e.definition.name : '(group)'
            b = e.bounds
            db = e.respond_to?(:definition) ? e.definition.bounds : nil
            out << format('  - %-10s [%s]  placed bounds %.3f x %.3f x %.3f   defn bounds %s',
                          e.name.to_s, nm, b.width.to_f, b.height.to_f, b.depth.to_f,
                          db ? format('%.3f x %.3f x %.3f', db.width.to_f, db.height.to_f, db.depth.to_f) : '-')
            out << format('       t: %s', fmt_t(e.transformation))
          end
        end
        # And what the tool would READ out of each reference file right now -
        # so the split is on paper before anything is drawn (2026-08-17).
        out << ''
        out << '== what the tool reads out of each reference file =='
        begin
          InteriorPro::Landscape::FenceRefTool.references.each do |r|
            tool = InteriorPro::Landscape::FenceRefTool.new(r[:path])
            m.start_operation('read ref', true)
            sh = tool.send(:read_shape!)
            m.commit_operation
            out << "  #{r[:name]}:"
            if sh.nil?
              out << '     could not read a fence out of it'
              next
            end
            out << format('     mode=%s  runs along %s  height=%.2f  pitch=%.3f  units in model=%d  loose faces=%s  posts seen=%s',
                          sh[:mode], sh[:run_axis] == 0 ? 'X' : 'Y', sh[:height], sh[:unit_along], sh[:unit_count_in_model],
                          sh[:loose_faces].inspect, sh[:post_count].inspect)
            out << format('     unit box: %.2f along x %.2f across x %.2f tall',
                          sh[:unit_along], sh[:unit_across], sh[:unit_max][2] - sh[:unit_min][2])
            out << "     unit pieces (#{sh[:pieces].length}): " +
                   sh[:pieces].map { |(d, _t)| d.name }.tally.map { |n, c| "#{c} x #{n}" }.join(', ')
            out << "     closer: " + (sh[:closer_pieces].empty? ? 'none' : sh[:closer_pieces].map { |(d, _t)| d.name }.join(', '))
          end
        rescue StandardError => e
          out << "  read failed: #{e.class}: #{e.message}"
          out.concat(Array(e.backtrace).first(4))
        end

        p = File.join(File.dirname(__FILE__), 'landscape', 'reference', 'placed_report.txt')
        File.write(p, out.join("\n"))
        puts "[PlacedDebug] wrote #{p}"
      end

      def self.fmt_t(t)
        a = t.to_a
        rows = (0..3).map { |c| (0..3).map { |r| format('%7.3f', a[r * 4 + c]) }.join(' ') }
        "\n         " + rows.join("\n         ")
      end
    end
  end
end
InteriorPro::Landscape::PlacedDebug.run!
