# Interior Pro - trace: corners where a curved wall meets a straight one.
# Read-only. Changes nothing in the model.
#
# Ruby Console:
#   load 'C:/Users/rordt/AppData/Roaming/SketchUp/SketchUp 2024/SketchUp/Plugins/interior_pro/debug_corners_2d.rb'

module InteriorPro
  module DebugCorners2D
    D = 'InteriorPro'.freeze

    def self.walls
      Sketchup.active_model.active_entities.grep(Sketchup::Group)
              .select { |g| g.get_attribute(D, 'type') == 'wall' }
    end

    def self.f(v)
      format('%.2f', v.to_f)
    end

    def self.pt(a)
      a.nil? ? 'nil' : "(#{f(a[0])}, #{f(a[1])})"
    end

    def self.run
      ws = walls
      if ws.empty?
        puts '[corners] no walls'
        return nil
      end

      puts "[corners] USE_CURVED_WALLS=#{InteriorPro::WallTool::USE_CURVED_WALLS rescue '?'}"
      puts "[corners] walls=#{ws.size}"

      info = []
      ws.each_with_index do |g, i|
        sx = g.get_attribute(D, 'start_x').to_f
        sy = g.get_attribute(D, 'start_y').to_f
        ex = g.get_attribute(D, 'end_x').to_f
        ey = g.get_attribute(D, 'end_y').to_f
        sag = g.get_attribute(D, 'arc_sag').to_f
        th  = g.get_attribute(D, 'thickness').to_f
        anc = g.get_attribute(D, 'anchor').to_s
        cat = g.get_attribute(D, 'wall_category').to_s
        flat = g.get_attribute(D, 'corners_xy')
        tr = g.transformation
        ident = tr.identity? rescue false

        d0 = InteriorPro::WallTool.corner_direction_xy(sx, sy, ex, ey, sag, :start) rescue nil
        d1 = InteriorPro::WallTool.corner_direction_xy(sx, sy, ex, ey, sag, :end) rescue nil

        info << { g: g, i: i, sx: sx, sy: sy, ex: ex, ey: ey, sag: sag, th: th }

        puts '=================================================='
        puts "wall#{i}  id=#{g.get_attribute(D, 'id')}  cat=#{cat}  anchor=#{anc}  th=#{f(th)}"
        puts "  drawn start=#{pt([sx, sy])}  end=#{pt([ex, ey])}  len=#{f(Math.hypot(ex - sx, ey - sy))}"
        puts "  arc_sag=#{f(sag)}   curved?=#{InteriorPro::WallTool.curved_wall?(g) rescue '?'}"
        puts "  transformation identity? #{ident}   origin=#{f(tr.origin.x)},#{f(tr.origin.y)}"
        puts "  tangent at start=#{pt(d0)}   at end=#{pt(d1)}"
        if flat.is_a?(Array) && flat.length == 8
          puts "  corners_xy  s_pos=#{pt([flat[0], flat[1]])}  e_pos=#{pt([flat[2], flat[3]])}"
          puts "              e_neg=#{pt([flat[4], flat[5]])}  s_neg=#{pt([flat[6], flat[7]])}"
          sp = Math.hypot(flat[0] - sx, flat[1] - sy)
          sn = Math.hypot(flat[6] - sx, flat[7] - sy)
          ep = Math.hypot(flat[2] - ex, flat[3] - ey)
          en = Math.hypot(flat[4] - ex, flat[5] - ey)
          puts "  corner reach from the drawn ends: start #{f(sp)}/#{f(sn)}   end #{f(ep)}/#{f(en)}   (wall is #{f(th)} thick)"
          bad = [sp, sn, ep, en].select { |v| v > th * 3.0 + 1.0 }
          puts "  ** SPIKE: a corner runs #{f(bad.max)} away from its own end **" unless bad.empty?
        else
          puts '  corners_xy MISSING or malformed -> the wall is drawn with its plain square ends'
        end

        # what the footprint really is right now
        begin
          data = InteriorPro::WallTool.new.wall_data(g)
          fp = InteriorPro::WallTool.curved_footprint_for(g, data)
          puts "  footprint points=#{fp ? fp.length : 'nil (straight path)'}"
        rescue StandardError => e
          puts "  footprint: ERROR #{e.message}"
        end
      end

      # which drawn ends actually sit on top of each other
      puts '=================================================='
      puts '[corners] drawn endpoints that touch (tol 1.0"):'
      info.each do |a|
        [[:start, a[:sx], a[:sy]], [:end, a[:ex], a[:ey]]].each do |sa, ax, ay|
          info.each do |b|
            next if b[:i] == a[:i]
            [[:start, b[:sx], b[:sy]], [:end, b[:ex], b[:ey]]].each do |sb, bx, by|
              dd = Math.hypot(bx - ax, by - ay)
              next if dd > 1.0
              next if b[:i] < a[:i]
              puts "  wall#{a[:i]}.#{sa}  <->  wall#{b[:i]}.#{sb}   gap=#{f(dd)}"
            end
          end
        end
      end
      nil
    end
  end
end

InteriorPro::DebugCorners2D.run
