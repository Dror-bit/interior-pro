# encoding: utf-8
# Landscape Pro - read one reference fence, then REBUILD it from its own parts
# (2026-08-16)
#
# Two things, in this order, because the user asked for it in this order:
#
#   1. READ. Load landscape/reference/cable railing.skp, walk down to every
#      solid, work out which ones are the POSTS and which ones make up the
#      PANEL between two posts. Write it all to a report.
#
#   2. SHOW. Place, in the model, at the origin: his post, his panel, his post
#      again - one bay of his fence, made of his own geometry, nothing drawn by
#      this file. If that bay looks exactly like his fence, the reading was
#      right and the fence tool can be taught the same split. If it does not,
#      the mistake is visible here, on one bay, before any code is touched.
#
# The placed bay is a group named 'LandscapePro_REF_CHECK'. Delete it when
# done, or run InteriorPro::Landscape::FenceParts.clear! from the console.
#
#   Ruby Console:
#     load 'C:/Users/rordt/AppData/Roaming/SketchUp/SketchUp 2024/SketchUp/Plugins/interior_pro/debug_fence_parts.rb'

module InteriorPro
  module Landscape
    module FenceParts

      FILE       = 'cable railing.skp' unless const_defined?(:FILE, false)
      CHECK_NAME = 'LandscapePro_REF_CHECK' unless const_defined?(:CHECK_NAME, false)

      def self.dir
        File.join(File.dirname(__FILE__), 'landscape', 'reference')
      end

      def self.run!(file = FILE)
        out = []
        path = File.join(dir, file)
        out << "Landscape Pro - #{file}: read it, then rebuild one bay from its own parts"
        out << ''
        unless File.exist?(path)
          out << "NOT FOUND: #{path}"
          return write(out, file)
        end

        model = Sketchup.active_model
        clear!
        model.start_operation('Reference fence check', true)
        begin
          defn = model.definitions.load(path)
          if defn.nil?
            out << 'could not load'
          else
            info = read(defn)
            out.concat(info[:lines])
            out << ''
            out.concat(show!(model, defn, info))
          end
        rescue StandardError => e
          out << "STOPPED: #{e.class}: #{e.message}"
          out.concat(Array(e.backtrace).first(8))
        ensure
          model.commit_operation
        end
        write(out, file)
      end

      def self.clear!
        m = Sketchup.active_model
        old = m.entities.grep(Sketchup::Group).select { |g| g.name == CHECK_NAME }
        return if old.empty?
        m.start_operation('Remove reference check', true)
        old.each { |g| g.erase! if g.valid? }
        m.commit_operation
      end

      def self.write(lines, file)
        p = File.join(dir, File.basename(file, '.skp').tr(' ', '_') + '_parts.txt')
        File.write(p, lines.join("\n"))
        puts "[FenceParts] wrote #{p}"
      end

      # ================================================================ READ

      def self.read(defn)
        lines = []
        bb = defn.bounds
        run   = bb.width.to_f
        tall  = bb.depth.to_f
        lines << "definition: #{defn.name}"
        lines << format('overall: %.3f along (x) x %.3f across (y) x %.3f tall (z)',
                        run, bb.height.to_f, tall)
        lines << format('bounds: min=(%.3f, %.3f, %.3f) max=(%.3f, %.3f, %.3f)',
                        bb.min.x.to_f, bb.min.y.to_f, bb.min.z.to_f,
                        bb.max.x.to_f, bb.max.y.to_f, bb.max.z.to_f)
        lines << ''

        lines << 'STRUCTURE (what is inside what):'
        tree(defn.entities, 1, lines)
        lines << ''

        # Every top-level child of the fence, with its own world box. These are
        # the things that get placed - a post is one child, a cable is one
        # child. If the user's fence has one big group per bay, that shows up
        # here as few, wide children, and the split below adapts.
        kids = children(defn.entities, Geom::Transformation.new)
        lines << "TOP-LEVEL PIECES: #{kids.length}"

        groups = Hash.new { |h, k| h[k] = [] }
        kids.each do |k|
          key = [k[:size].map { |v| (v * 64).round / 64.0 }, k[:label]]
          groups[key] << k
        end
        lines << 'BY KIND (count x  along x across x tall):'
        groups.to_a.sort_by { |(k, v)| [-v.length, k[0]] }.each do |(key, list)|
          size, label = key
          lines << format('  %3d x  %8.3f x %7.3f x %8.3f   %s',
                          list.length, size[0], size[1], size[2], label)
          xs = list.map { |p| p[:min][0] }.sort
          if list.length > 1
            lines << format('        x starts: %s', fmt(xs))
            lines << format('        step:     %s', steps(xs))
            lines << format('        z bottom: %s', fmt(list.map { |p| p[:min][2] }.uniq.sort))
          else
            p = list.first
            lines << format('        at x=%.3f..%.3f  y=%.3f..%.3f  z=%.3f..%.3f',
                            p[:min][0], p[:max][0], p[:min][1], p[:max][1], p[:min][2], p[:max][2])
          end
        end
        lines << ''

        # ---- the split: which pieces are posts -------------------------------
        #
        # A post is a piece that (a) is at least 60% as tall as the fence,
        # (b) is narrow along the run (under 12"), and (c) has at least one
        # twin at the same size. Everything else is panel.
        posts = kids.select do |k|
          k[:size][2] >= tall * 0.6 && k[:size][0] < 12.0
        end
        post_key = ->(k) { k[:size].map { |v| (v * 16).round / 16.0 } }
        by_size = Hash.new { |h, k| h[k] = [] }
        posts.each { |k| by_size[post_key.call(k)] << k }
        # The most numerous tall-narrow shape IS the post.
        best = by_size.values.max_by(&:length) || []
        posts = best
        panel = kids - posts

        lines << 'THE SPLIT:'
        lines << "  posts:  #{posts.length} pieces"
        posts.sort_by { |p| p[:min][0] }.each do |p|
          lines << format('     post at x=%.3f..%.3f (centre %.3f)  z=%.3f..%.3f  %s',
                          p[:min][0], p[:max][0], (p[:min][0] + p[:max][0]) / 2.0,
                          p[:min][2], p[:max][2], p[:label])
        end
        centres = posts.map { |p| (p[:min][0] + p[:max][0]) / 2.0 }.sort
        lines << format('  post spacing: %s', steps(centres))
        lines << "  panel:  #{panel.length} pieces (everything that is not a post)"
        panel.group_by { |p| p[:label] }.each do |lbl, list|
          lines << format('     %3d x %s', list.length, lbl)
        end
        lines << ''

        # One bay = from the first post centre to the second. The panel pieces
        # that live in that bay are the ones whose x-centre falls between.
        bay = nil
        if centres.length >= 2
          c0 = centres[0]
          c1 = centres[1]
          in_bay = panel.select do |p|
            cx = (p[:min][0] + p[:max][0]) / 2.0
            cx >= c0 - 0.01 && cx <= c1 + 0.01
          end
          bay = { c0: c0, c1: c1, span: c1 - c0, pieces: in_bay }
          lines << format('ONE BAY: post centre %.3f to %.3f = %.3f" span, %d panel pieces in it',
                          c0, c1, c1 - c0, in_bay.length)
          in_bay.group_by { |p| p[:label] }.each do |lbl, list|
            lines << format('     %3d x %s   (along %.2f, tall %.2f)',
                            list.length, lbl, list[0][:size][0], list[0][:size][2])
          end
        else
          lines << 'ONE BAY: could not find two posts - the split guessed wrong.'
        end

        { lines: lines, kids: kids, posts: posts, panel: panel, bay: bay,
          run: run, tall: tall }
      end

      # The direct children of the fence, each with a WORLD box.
      def self.children(ents, tr)
        out = []
        ents.each do |e|
          next unless e.is_a?(Sketchup::Group) || e.is_a?(Sketchup::ComponentInstance)
          t = tr * e.transformation
          box = box_of(e, t)
          next unless box
          out << { entity: e, label: label(e), min: box[0], max: box[1],
                   size: [box[1][0] - box[0][0], box[1][1] - box[0][1], box[1][2] - box[0][2]] }
        end
        out
      end

      def self.box_of(e, tr)
        min = nil
        max = nil
        each_vertex(e, tr) do |p|
          a = [p.x.to_f, p.y.to_f, p.z.to_f]
          if min.nil?
            min = a.dup
            max = a.dup
          else
            3.times do |i|
              min[i] = a[i] if a[i] < min[i]
              max[i] = a[i] if a[i] > max[i]
            end
          end
        end
        min ? [min, max] : nil
      end

      def self.each_vertex(e, tr, depth = 0, &blk)
        return if depth > 8
        sub = sub_entities(e)
        return unless sub
        sub.grep(Sketchup::Face).each { |f| f.vertices.each { |v| blk.call(v.position.transform(tr)) } }
        sub.each do |k|
          next unless k.is_a?(Sketchup::Group) || k.is_a?(Sketchup::ComponentInstance)
          each_vertex(k, tr * k.transformation, depth + 1, &blk)
        end
      end

      # ================================================================ SHOW
      #
      # Copy his post, his panel pieces, his post again into a fresh group at
      # the origin. Pure copying: definitions are reused, transformations are
      # kept, only the whole thing is slid so the first post centre sits at 0.
      def self.show!(model, defn, info)
        lines = ['PLACED ONE BAY AT THE ORIGIN:']
        posts = info[:posts]
        bay   = info[:bay]
        if posts.empty? || bay.nil?
          lines << '  nothing placed - no bay found.'
          return lines
        end

        host = model.active_entities.add_group
        host.name = CHECK_NAME
        ents = host.entities

        # Slide everything so the first post centre lands on x=0, and the
        # fence's own y-centre on y=0.
        p0 = posts.min_by { |p| p[:min][0] }
        ycen = (defn.bounds.min.y.to_f + defn.bounds.max.y.to_f) / 2.0
        shift = Geom::Transformation.translation(
          Geom::Vector3d.new(-(p0[:min][0] + p0[:max][0]) / 2.0, -ycen, 0))

        placed = 0
        copy = lambda do |piece, tag|
          e = piece[:entity]
          d = e.respond_to?(:definition) ? e.definition : nil
          if d
            inst = ents.add_instance(d, shift * e.transformation)
            inst.name = tag
            inst.material = e.material if e.material
          else
            # A plain group has no definition to share; copy it as one.
            g = ents.add_group
            g.name = tag
            g.entities.add_instance(e.entities.parent, Geom::Transformation.new) rescue nil
            g.transform!(shift * e.transformation)
          end
          placed += 1
        end

        # Post 1, the panel pieces of bay 1, post 2.
        two = posts.sort_by { |p| p[:min][0] }.first(2)
        copy.call(two[0], 'REF post 1')
        bay[:pieces].each { |pc| copy.call(pc, "REF panel #{pc[:label]}") }
        copy.call(two[1], 'REF post 2')

        lines << "  #{placed} pieces placed in group '#{CHECK_NAME}'"
        lines << format('  first post centre at x=0, second at x=%.3f', bay[:span])
        lines << '  Look at it. If it is his fence, the split is right.'
        lines
      end

      # ================================================================ tree

      def self.tree(ents, depth, lines)
        return if depth > 6
        kids = ents.select { |e| e.is_a?(Sketchup::Group) || e.is_a?(Sketchup::ComponentInstance) }
        faces = ents.grep(Sketchup::Face).length
        by = Hash.new(0)
        kids.each { |k| by[label(k)] += 1 }
        by.each { |nm, n| lines << ('  ' * depth) + "#{n} x #{nm}" }
        lines << ('  ' * depth) + "(#{faces} loose faces here)" if faces > 0
        seen = {}
        kids.each do |k|
          nm = label(k)
          next if seen[nm]
          seen[nm] = true
          sub = sub_entities(k)
          next unless sub
          next unless sub.any? { |e| e.is_a?(Sketchup::Group) || e.is_a?(Sketchup::ComponentInstance) }
          lines << ('  ' * depth) + "  inside #{nm}:"
          tree(sub, depth + 2, lines)
        end
      end

      def self.label(k)
        if k.respond_to?(:definition) && k.definition
          "[#{k.definition.name}]"
        else
          n = k.name.to_s
          n.empty? ? '(group)' : "(#{n})"
        end
      rescue StandardError
        '?'
      end

      def self.sub_entities(k)
        if k.respond_to?(:definition) && k.definition
          k.definition.entities
        elsif k.respond_to?(:entities)
          k.entities
        end
      rescue StandardError
        nil
      end

      def self.fmt(a)
        a.first(12).map { |v| format('%.2f', v) }.join(', ') + (a.length > 12 ? ' ...' : '')
      end

      def self.steps(sorted)
        return '-' if sorted.length < 2
        d = (1...sorted.length).map { |i| (sorted[i] - sorted[i - 1]).round(3) }
        u = d.uniq
        return format('%.3f (even)', u[0]) if u.length == 1
        d.first(10).map { |g| format('%.2f', g) }.join(', ')
      end

    end
  end
end

InteriorPro::Landscape::FenceParts.run!
