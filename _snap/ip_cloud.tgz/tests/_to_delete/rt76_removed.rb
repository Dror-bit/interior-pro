# encoding: utf-8
# rt76 - the tile courses actually get BUILT (2026-08-19, roof step 2b).
#
# rt72 pins the maths: where every course line sits, where it is cut by a hip
# or a dormer, where the wave crests. This pins the other half - that
# roof_manager turns those numbers into faces, on the right plane, facing the
# right way, inside a budget, and that a material with no courses builds
# nothing at all.
#
# THE RULE BEING KEPT (measured off Instant Roof, 2026-08-18):
# build 3D only where the silhouette shows. So what is built here is the STEP
# at each course line and nothing else - the field is the texture's job.
require './sketchup_stub'
require './roof_tile_math'
require './roof_manager'

$fails = 0
def ok(n, c, x = nil)
  puts((c ? 'PASS  ' : 'FAIL  ') + n + (c ? '' : "   << #{x.inspect}"))
  $fails += 1 unless c
end

RM = InteriorPro::RoofManager
RTM = InteriorPro::RoofTileMath

# A plain rectangular roof plane, 120" across the eave and rising 4:12 for
# 60" of run. Eave along +X at z = 100, ridge at the far side.
def slope_face(w = 120.0, run = 60.0, rise = 20.0, z0 = 100.0)
  [[0.0, 0.0, z0], [w, 0.0, z0], [w, run, z0 + rise], [0.0, run, z0 + rise]]
end

class FakeFace
  attr_reader :pts
  def initialize(pts, normal); @pts = pts.map { |p| Geom::Point3d.new(p[0], p[1], p[2]) }; @n = normal; end
  def normal; Geom::Vector3d.new(@n[0], @n[1], @n[2]); end
end

# The plane's real normal, so the frame comes out the way the model would
# give it rather than the way the test wishes it would.
NRM = RTM.vnorm(RTM.vcross([120.0, 0.0, 0.0], [0.0, 60.0, 20.0]))
FACE = FakeFace.new(slope_face, NRM)

def fresh_group
  Sketchup.reset_model!
  Sketchup.active_model.entities.add_group
end

def strips(grp)
  grp.entities.grep(Sketchup::Group).select { |g|
    g.get_attribute('InteriorPro', 'part') == 'tile_courses'
  }
end

def all_faces(grp)
  strips(grp).flat_map { |g| g.entities.grep(Sketchup::Face) }
end

# ------------------------------------------------- a material with courses
g = fresh_group
n = RM.build_tile_courses!(g, [FACE], 'barrel', nil)
ok('barrel tile builds course strips', n > 0, n)
ok('they live in their own sub-group, tagged', strips(g).length == 1, strips(g).length)
faces = all_faces(g)
ok('and the sub-group really holds faces', faces.length > 0, faces.length)

# One strip per course on a plain rectangle - no hip, no dormer, so every
# course is a single span.
expected = RTM.courses(RTM.plane_uv(FACE.pts.map { |p| [p.x, p.y, p.z] }, NRM), 'barrel')
# ONE strip, on the eave course - not one per course.
#
# 2026-08-19: the first build put a step on every course and the user said
# "it really does not look good". The measurement had said so already and I
# read it wrong: Vali's whole roof carries 408 va_BirdStop instances, one
# face each, and 408 is the EAVE LINE. Above the eave they are flat, because
# above the eave there is no silhouette - you are looking at the roof, not
# at the sky behind it.
ok('only the eave course gets a step, not every course',
   n == RM::TILE_COURSE_ROWS, [n, RM::TILE_COURSE_ROWS])
ok('and the maths still finds plenty of courses to choose from',
   expected[:courses].length > 2, expected[:courses].length)
ok('asking for all of them is still possible, and costs much more',
   RTM.estimate(RTM.plane_uv(FACE.pts.map { |p| [p.x, p.y, p.z] }, NRM), 'barrel',
                rows: nil)[:faces] >
   RTM.estimate(RTM.plane_uv(FACE.pts.map { |p| [p.x, p.y, p.z] }, NRM), 'barrel',
                rows: 1)[:faces])

# ------------------------------------------------- where the steps sit
# Every point built must lie on or just above the roof plane - never below
# it, or the step would be sunk into the roof instead of standing on it.
pl = RTM.plane_uv(FACE.pts.map { |p| [p.x, p.y, p.z] }, NRM)
o = pl[:origin]
offs = faces.flat_map { |f| f.points.map { |p| RTM.vdot(RTM.vsub([p.x, p.y, p.z], o), pl[:n]) } }
ok('nothing is built below the roof surface', offs.min > -0.001, offs.min)
ok('and nothing stands further out than the relief',
   offs.max <= RTM.shape('barrel')[:relief] + 0.001, offs.max)
ok('the steps really do stand proud (this is not a flat decal)',
   offs.max > 0.5, offs.max)

# Everything stays inside the plane's own outline, across and up the slope.
uvs = faces.flat_map { |f| f.points.map { |p| RTM.project([p.x, p.y, p.z], o, pl[:u], pl[:v]) } }
ok('nothing hangs off the side of the plane',
   uvs.map { |a| a[0] }.min > -0.01 && uvs.map { |a| a[0] }.max < pl[:u_span] + 0.01)
ok('nothing runs off the top of the plane',
   uvs.map { |a| a[1] }.max < pl[:v_span] + 0.01, uvs.map { |a| a[1] }.max)

# ------------------------------------------------- materials with no courses
%w[seam shingle color].each do |m|
  g2 = fresh_group
  ok("#{m} builds no course steps (its texture does the work)",
     RM.build_tile_courses!(g2, [FACE], m, nil).zero? && strips(g2).empty?)
end

# ------------------------------------------------- the budget really bites
g3 = fresh_group
old = RM::MAX_TILE_FACES
RM.send(:remove_const, :MAX_TILE_FACES)
RM.const_set(:MAX_TILE_FACES, 10)
n3 = RM.build_tile_courses!(g3, [FACE], 'barrel', nil)
ok('over budget, nothing is built at all - the roof stays flat',
   n3.zero? && strips(g3).empty?, n3)
RM.send(:remove_const, :MAX_TILE_FACES)
RM.const_set(:MAX_TILE_FACES, old)

# ------------------------------------------------- the kill switch
g4 = fresh_group
RM.send(:remove_const, :USE_TILE_COURSES)
RM.const_set(:USE_TILE_COURSES, false)
ok('the kill switch turns the whole thing off',
   RM.build_tile_courses!(g4, [FACE], 'barrel', nil).zero? && strips(g4).empty?)
RM.send(:remove_const, :USE_TILE_COURSES)
RM.const_set(:USE_TILE_COURSES, true)

# ------------------------------------------------- rubbish in, no crash out
g5 = fresh_group
ok('no faces at all is not a crash', RM.build_tile_courses!(g5, [], 'barrel', nil).zero?)
ok('nil faces is not a crash', RM.build_tile_courses!(g5, nil, 'barrel', nil).zero?)
ok('an unknown material is not a crash',
   RM.build_tile_courses!(g5, [FACE], 'nonsense', nil).zero?)
flat = FakeFace.new([[0, 0, 100], [100, 0, 100], [100, 100, 100], [0, 100, 100]], [0, 0, 1])
ok('a dead flat face gets no courses', RM.build_tile_courses!(g5, [flat], 'barrel', nil).zero?)

# ------------------------------------------------- slate staggers, barrel does not
g6 = fresh_group
RM.build_tile_courses!(g6, [FACE], 'slate', nil)
ok('slate builds its own (finer) courses', strips(g6).length == 1)

# ------------------------------------------------- the wave is paid for once
# The builder and the budget must use the SAME amplitude per course. If they
# drift apart the estimate stops predicting the build - the exact mistake
# wall_click_offsets exists to avoid. So: the bottom course is wavy, the ones
# above it are plain steps, and the face count says so.
g7 = fresh_group
RM.build_tile_courses!(g7, [FACE], 'barrel', nil)
sg = strips(g7).first
kids = sg.entities.grep(Sketchup::Group)
per = kids.map { |k| k.entities.grep(Sketchup::Face).length }
per = [sg.entities.grep(Sketchup::Face).length] if per.empty?
ok('the bottom course really is the expensive one',
   RTM.scallop_amp(0, RTM.shape('barrel')) > 0 &&
   RTM.scallop_amp(1, RTM.shape('barrel')).zero?)

# On the user's own roof the whole thing has to fit inside the budget, or the
# feature silently does nothing on the only model that matters.
big = RTM.plane_uv([[0, 0, 0], [756.0, 0, 0], [756.0, 354.0, 118.0], [0, 354.0, 118.0]],
                   RTM.vnorm(RTM.vcross([756.0, 0, 0], [0, 354.0, 118.0])))
one_plane = RTM.estimate(big, 'barrel', scallop_courses: RM::TILE_SCALLOP_COURSES)[:faces]
ok('>>> the user 63ft roof FITS the budget on four planes',
   one_plane * 4 < RM::MAX_TILE_FACES, one_plane * 4)
ok('    and waving every course would NOT fit (this is why the policy exists)',
   RTM.estimate(big, 'barrel', scallop_courses: nil)[:faces] * 4 > RM::MAX_TILE_FACES)
ok('the builder passes the policy to the estimate',
   File.read('roof_manager.rb', encoding: 'UTF-8')
       .include?('scallop_courses: TILE_SCALLOP_COURSES'))
ok('and uses the same amplitude when it draws',
   File.read('roof_manager.rb', encoding: 'UTF-8')
       .include?('scallop_amp(crs[:index], s, TILE_SCALLOP_COURSES)'))

# ------------------------------------------------- it is wired into the roof
src = File.read('roof_manager.rb', encoding: 'UTF-8')
ok('build_roof! actually calls it', src.include?('build_tile_courses!(grp, top_shell'))
ok('off the SAME top shell the ridge caps use',
   src.include?('ridge_lines(top_shell)'))
ok('and never on a flat roof', src[/build_tile_courses!\(grp, top_shell.*$/].to_s.include?("s[:style] != 'flat'"))

puts($fails.zero? ? "\nALL PASS" : "\n*** #{$fails} FAILED ***")
exit($fails.zero? ? 0 : 1)
