# Interior Pro - measurement only, changes nothing.
#
# THE SYMPTOM (user, 2026-08-18): he copy-pastes floor-1 walls up to floor 2
# because most of them line up. Then editing the UPPER wall also changes the
# LOWER one - "like a component".
#
# There are two different mechanisms that produce exactly that, and the fix is
# completely different for each. This tells us WHICH:
#
#   A. SHARED DEFINITION. SketchUp's copy of a Group keeps the SAME
#      ComponentDefinition. The geometry is literally one object shown twice,
#      so SketchUp itself mirrors every edit. Fix = make_unique.
#   B. DUPLICATE ID. The InteriorPro 'id' attribute got copied too, so OUR
#      code looks the wall up by id and finds two. Fix = re-id on copy.
#
# Both can be true at once.
module InteriorPro
  module DebugCopyWalls
    def self.run
      out = []
      m = Sketchup.active_model
      walls = m.entities.grep(Sketchup::Group).select { |g|
        g.get_attribute('InteriorPro', 'type') == 'wall'
      }
      out << "walls at top level: #{walls.size}"
      out << ""

      # ---------------------------------------------------------- A. definitions
      out << "== A. SHARED DEFINITION (SketchUp mirrors the edit itself) =="
      by_def = Hash.new { |h, k| h[k] = [] }
      walls.each do |w|
        d = (w.respond_to?(:definition) ? w.definition : nil)
        by_def[d ? d.entityID : :none] << w
      end
      shared = by_def.select { |_k, v| v.size > 1 }
      out << "  distinct definitions: #{by_def.size} for #{walls.size} walls"
      out << "  definitions used by MORE THAN ONE wall: #{shared.size}   <== A"
      shared.each do |did, ws|
        levels = ws.map { |w| (w.get_attribute('InteriorPro', 'level') || 1).to_i }
        out << "    def #{did}: #{ws.size} walls, levels #{levels.inspect}"
        ws.each do |w|
          o = w.transformation.origin
          out << "      id=#{w.get_attribute('InteriorPro','id')} lvl=#{(w.get_attribute('InteriorPro','level')||1)} origin=(#{o.x.round(2)}, #{o.y.round(2)}, #{o.z.round(2)}) start=(#{w.get_attribute('InteriorPro','start_x')}, #{w.get_attribute('InteriorPro','start_y')})"
        end
      end
      out << ""

      # ------------------------------------------------------------- B. ids
      out << "== B. DUPLICATE InteriorPro id (our own lookups find two) =="
      by_id = Hash.new { |h, k| h[k] = [] }
      walls.each { |w| by_id[w.get_attribute('InteriorPro', 'id')] << w }
      dup = by_id.select { |k, v| v.size > 1 && !k.nil? }
      nil_id = by_id[nil] || []
      out << "  distinct ids: #{by_id.size}"
      out << "  ids held by MORE THAN ONE wall: #{dup.size}   <== B"
      out << "  walls with NO id at all: #{nil_id.size}"
      dup.each do |id, ws|
        levels = ws.map { |w| (w.get_attribute('InteriorPro', 'level') || 1).to_i }
        out << "    id=#{id}: #{ws.size} walls, levels #{levels.inspect}"
      end
      out << ""

      # --------------------------------------- C. same footprint, different level
      # Even with unique ids and unique definitions, two walls drawn on the
      # same x/y on different levels can be confused by anything that matches
      # on POSITION instead of identity - which is what the 2D editor does when
      # it maps a drawn line back onto a built wall.
      out << "== C. same drawn line on two different levels (position lookups) =="
      key = lambda { |w|
        o = w.transformation.origin
        [ (w.get_attribute('InteriorPro','start_x').to_f + o.x).round(2),
          (w.get_attribute('InteriorPro','start_y').to_f + o.y).round(2),
          (w.get_attribute('InteriorPro','end_x').to_f   + o.x).round(2),
          (w.get_attribute('InteriorPro','end_y').to_f   + o.y).round(2) ]
      }
      by_xy = Hash.new { |h, k| h[k] = [] }
      walls.each { |w| by_xy[key.call(w)] << w }
      overlap = by_xy.select { |_k, v|
        v.size > 1 && v.map { |w| (w.get_attribute('InteriorPro','level') || 1).to_i }.uniq.size > 1
      }
      out << "  wall lines that exist on more than one level: #{overlap.size}   <== C"
      overlap.first(15).each do |k, ws|
        out << "    #{k.inspect} : levels #{ws.map { |w| (w.get_attribute('InteriorPro','level')||1).to_i }.inspect} ids #{ws.map { |w| (w.get_attribute('InteriorPro','id')||'-')[0,8] }.inspect}"
      end
      out << ""

      # ------------------------------------------------- D. what else got copied
      out << "== D. other attributes that must be unique per wall =="
      %w[openings doors].each do |att|
        holders = walls.select { |w| w.get_attribute('InteriorPro', att) }
        out << "  walls carrying '#{att}': #{holders.size}"
      end
      out << ""
      out << "== VERDICT HINT =="
      out << "  A>0  -> SketchUp shares the geometry. make_unique on copy."
      out << "  B>0  -> our id lookups find two walls. re-id on copy."
      out << "  C>0 with A=0,B=0 -> something matches by POSITION, not identity."

      path = File.join(File.dirname(__FILE__), 'copy_walls_report.txt')
      File.open(path, 'w') { |f| f.puts out.join("\n") }
      UI.messagebox("Done. Report written:\n#{path}")
      nil
    end
  end
end
InteriorPro::DebugCopyWalls.run
