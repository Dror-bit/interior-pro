# encoding: utf-8
# Interior Pro - gable diagnosis for the SELECTED wall (2026-08-09).
# Select the problem wall (and optionally the roof), then:
#   load 'C:/Users/rordt/AppData/Roaming/SketchUp/SketchUp 2024/SketchUp/Plugins/interior_pro/debug_gable_sel.rb'
# Prints the wall, its polygon edge, the roof plan, and the EXACT profile
# that the fascia (rake) and the gable wall are built from. Builds nothing
# permanent - the temporary geometry is aborted.

module InteriorPro
  module GableSel
    RFm = InteriorPro::RoofManager

    def self.pr(s)
      puts "[GS] #{s}"
    end

    def self.run
      model = Sketchup.active_model
      sel = model.selection.to_a
      s = RFm.settings
      pr format('style=%s pitch=%s overhang=%s fascia=%s gable_walls=%s',
                s[:style], s[:pitch], s[:overhang], s[:fascia], s[:gable_walls])

      walls = RFm.top_walls
      pr "top_walls=#{walls.length}"
      ep = RFm.eave_polygon(walls, s[:overhang])
      if ep.nil?
        pr 'eave_polygon = nil (no closed exterior loop) - stopping'
        return
      end
      poly = ep[:pts]
      wall_ids = ep[:wall_ids]

      # ---- what is selected ----
      sel_ids = []
      sel.each do |e|
        next unless e.respond_to?(:get_attribute)
        t = e.get_attribute('InteriorPro', 'type')
        id = e.get_attribute('InteriorPro', 'id')
        if t == 'wall'
          sel_ids << id
          pr format('SELECTED WALL %s  (%.2f,%.2f)->(%.2f,%.2f) th=%s h=%s base=%s lvl=%s cat=%s',
                    id,
                    e.get_attribute('InteriorPro', 'start_x').to_f,
                    e.get_attribute('InteriorPro', 'start_y').to_f,
                    e.get_attribute('InteriorPro', 'end_x').to_f,
                    e.get_attribute('InteriorPro', 'end_y').to_f,
                    e.get_attribute('InteriorPro', 'thickness'),
                    e.get_attribute('InteriorPro', 'height'),
                    e.get_attribute('InteriorPro', 'base_z'),
                    e.get_attribute('InteriorPro', 'level'),
                    e.get_attribute('InteriorPro', 'wall_category'))
          pr "   materials=#{InteriorPro::WallTool.wall_side_material_names(e).inspect}"
        elsif t == 'roof'
          pr format('SELECTED ROOF %s  gable_edges=%s eave_z=%s ridge_z=%s',
                    id, e.get_attribute('InteriorPro', 'gable_edges').inspect,
                    e.get_attribute('InteriorPro', 'eave_z'),
                    e.get_attribute('InteriorPro', 'ridge_z'))
        else
          pr "SELECTED #{t.inspect} #{e.class}"
        end
      end
      pr 'nothing selected' if sel.empty?

      marked = RFm.gable_wall_ids
      pr "marked=#{marked.inspect}"
      sel_ids.each do |id|
        pr "   selected wall marked as GABLE? #{marked.include?(id)}"
      end

      poly.each_index do |i|
        star = sel_ids.include?(wall_ids[i]) ? ' <== SELECTED' : ''
        pr format('poly[%d]=(%.2f, %.2f) -> (%.2f, %.2f) wall=%s%s',
                  i, poly[i][0], poly[i][1],
                  poly[(i + 1) % poly.length][0], poly[(i + 1) % poly.length][1],
                  wall_ids[i], star)
      end

      framed = RFm.framed_plan(poly, wall_ids, marked, s[:style])
      if framed
        pr "main=#{framed[:main].inspect} g=#{framed[:g].inspect}"
        framed[:wings].each_with_index do |w, k|
          pr "wing#{k}: rect=#{w[:rect].inspect} mouth=#{w[:mouth]} gabled=#{w[:gabled]}"
        end
        pr "gable poly edges=#{framed[:edges].inspect}"
      else
        pr 'framed_plan = nil (strip-gable fallback path)'
      end

      # ---- rebuild the height map in a throw-away group ----
      z0 = RFm.eave_z(walls)
      slope = s[:pitch] / 12.0
      model.start_operation('IP GableSel probe', true)
      tmp = model.entities.add_group
      zmap = nil
      begin
        if framed
          _r, zmap = RFm.build_framed_geometry!(tmp, framed, z0, slope, s[:overhang], nil, nil)
        else
          speeds = Array.new(poly.length, 1.0)
          (framed ? framed[:edges] : []).each { |i| speeds[i] = 0.0 }
          arcs = RFm.straight_skeleton(poly, speeds)
          cells = arcs && RFm.roof_cells(poly, arcs, speeds)
          _r, zmap = RFm.build_hip_geometry!(tmp, poly, cells, z0, slope, s[:overhang], nil, nil) if cells
        end
      rescue StandardError => e
        pr "probe build failed: #{e.message}"
      end

      if zmap
        band_top = z0 - slope * s[:overhang]
        pr format('z0=%.2f band_top=%.2f slope=%.4f', z0, band_top, slope)
        edges = framed ? framed[:edges] : []
        interesting = edges.dup
        poly.each_index { |i| interesting << i if sel_ids.include?(wall_ids[i]) }
        interesting.uniq.sort.each do |i|
          a = poly[i]
          b = poly[(i + 1) % poly.length]
          d = RFm.vnorm(RFm.vsub(b, a))
          len = RFm.vlen(RFm.vsub(b, a))
          pr format('--- edge %d  wall=%s  len=%.2f  gabled=%s%s',
                    i, wall_ids[i], len, edges.include?(i),
                    sel_ids.include?(wall_ids[i]) ? '  <== SELECTED' : '')
          raw = []
          zmap.each do |(x, y), z|
            p = [x, y]
            next if RFm.vcross(d, RFm.vsub(p, a)).abs > 0.75
            raw << [RFm.vdot(RFm.vsub(p, a), d), x, y, z]
          end
          raw.sort_by!(&:first)
          pr "    zmap points ON this line (t, x, y, z):"
          raw.each { |t, x, y, z| pr format('      t=%9.2f  (%9.2f, %9.2f)  z=%8.2f', t, x, y, z) }
          ch_full = RFm.edge_profile_chain(poly, i, zmap, full: true)
          ch_clip = RFm.edge_profile_chain(poly, i, zmap)
          pr "    FULL-LINE profile : #{ch_full ? ch_full.map { |t, _p, z| [t.round(1), z.round(1)] }.inspect : 'nil'}"
          pr "    CLIPPED profile   : #{ch_clip ? ch_clip.map { |t, _p, z| [t.round(1), z.round(1)] }.inspect : 'nil'}"
          if framed
            owners = RFm.framed_line_owners(framed)
            key = RFm.line_key(poly, i)
            pr "    line key=#{key.inspect} owner=#{owners[key].inspect}"
            if ch_clip
              samples = (0..8).map do |k|
                t = len * k / 8.0
                cz = RFm.framed_cover_z(framed, band_top, slope,
                                        a[0] + d[0] * t, a[1] + d[1] * t, owners[key])
                [t.round(1), cz ? cz.round(1) : nil]
              end
              pr "    cover z along the edge: #{samples.inspect}"
            end
          end
        end
      else
        pr 'no zmap - could not probe the profile'
      end
      model.abort_operation

      # ---- what the LIVE roof actually contains ----
      roof = RFm.roofs.first
      if roof
        tops = roof.entities.grep(Sketchup::Group).select do |g|
          g.get_attribute('InteriorPro', 'part') == 'gable_wall_top'
        end
        pr "live roof: #{tops.length} gable wall top prism(s)"
        tops.each_with_index do |g, k|
          pts = g.entities.grep(Sketchup::Face).flat_map { |f| f.vertices.map(&:position) }
          next if pts.empty?
          pr format('   prism%d  x %.1f..%.1f  y %.1f..%.1f  z %.1f..%.1f  faces=%d',
                    k, pts.map(&:x).min, pts.map(&:x).max,
                    pts.map(&:y).min, pts.map(&:y).max,
                    pts.map(&:z).min, pts.map(&:z).max,
                    g.entities.grep(Sketchup::Face).length)
        end
        sloped = roof.entities.grep(Sketchup::Face).select do |f|
          zs = f.vertices.map { |v| v.position.z }
          zs.max - zs.min > 2.0
        end
        pr "live roof: #{roof.entities.grep(Sketchup::Face).length} faces, #{sloped.length} sloped"
      else
        pr 'no roof group in the model'
      end
      nil
    rescue StandardError => e
      begin
        Sketchup.active_model.abort_operation
      rescue StandardError
        nil
      end
      pr "ERROR #{e.message}"
      pr e.backtrace.first(5).join("\n")
    end
  end
end

InteriorPro::GableSel.run
