# Interior Pro - Door Types Library
# Built-in types per category; custom type names persisted per category.

require 'json'

module InteriorPro
  module DoorLibrary

    %i[
      EXTERIOR_TYPES INTERIOR_TYPES BUILT_IN_BY_CATEGORY
      EXTERIOR_CASING_STYLES INTERIOR_CASING_STYLES CASING_LEGACY_MAP CATEGORY_DEFAULTS
      FOUR_PANEL_PANEL_IN FOUR_PANEL_WIDTH_IN PANEL_WIDTH_IN JAMB_TOTAL_IN
      TYPE_SETTING_OVERRIDES
    ].each { |c| remove_const(c) if const_defined?(c, false) }

    LIBRARY_FILE = File.join(ENV['APPDATA'] || ENV['HOME'], 'InteriorPro', 'door_types.json')

    EXTERIOR_TYPES = [
      'Front Door', 'Garage Door', 'Arched',
      'French Hinged', 'Sliding',
      '4-Panel Center Hinged', '4-Panel Sliding', '6-Panel Sliding',
      '3-Panel Folding', '4-Panel Folding', '6-Panel Folding'
    ].freeze
    # Interior types = opening mechanisms. The leaf DESIGN (Flush/Shaker/Caiman...)
    # is a separate 'leaf_style' setting - see DoorLeafStyles.
    # 'Cased Opening' (2026-08-03) is a doorway with no door in it: jamb and
    # casing only. Common in interiors - kitchen to living room, study entry -
    # and it needs no leaf, no swing and no handle.
    INTERIOR_TYPES = ['Single', 'Double', 'Pocket', 'Folding', 'Closet', 'Cased Opening'].freeze

    BUILT_IN_BY_CATEGORY = {
      'exterior' => EXTERIOR_TYPES,
      'interior' => INTERIOR_TYPES
    }.freeze

    # Only the flat (square) built-in remains; user .skp profiles
    # (assets/MOLDING PROFILES/CASING-*.skp) are added dynamically.
    EXTERIOR_CASING_STYLES = %w[none flat].freeze
    INTERIOR_CASING_STYLES = %w[none flat].freeze

    CASING_LEGACY_MAP = {
      'brick_mold' => 'flat',
      'flat'       => 'flat'
    }.freeze

    def self.casing_styles(side)
      base = side.to_s == 'exterior' ? EXTERIOR_CASING_STYLES : INTERIOR_CASING_STYLES
      skp = defined?(InteriorPro::MoldingLibrary) ?
              InteriorPro::MoldingLibrary.skp_names('CASING') : []
      base + skp
    end

    CATEGORY_DEFAULTS = {
      'exterior' => {
        'door_category'          => 'exterior',
        'door_type'              => 'French Hinged',
        'width'                  => 60.0,
        'height'                 => 80.0,
        'frame_width'            => 1.5,
        'glass_frame_width'      => 5.0,
        'interior_depth'         => 1.0,
        'floor_offset'           => 0.0,
        'swing_direction'        => 'left',
        'swing_side'             => 'auto',
        'slide_direction'        => 'left',
        'glass_grid_style'       => '2x2',
        'exterior_casing_style'  => 'none',
        'interior_casing_style'  => 'none',
        'exterior_threshold'     => true,
        'front_config'           => 'single',
        'front_leaf_style'       => 'Craftsman 3-Lite',
        'front_glass_ratio'      => 50.0,
        'sidelite_width'         => 14.0,
        'transom'                => false,
        'transom_height'         => 14.0,
        'garage_style'           => 'Raised Short',
        'garage_top_windows'     => false,
        'garage_window_style'    => 'Plain',
        'garage_window_count'    => 0,
        'garage_ext_frame'       => false
      },
      'interior' => {
        'door_category'          => 'interior',
        'door_type'              => 'Single',
        'leaf_style'             => 'Flush',
        'closet_leaf_count'      => 2,
        'handle_style'           => 'none',
        'width'                  => 32.0,
        'height'                 => 80.0,
        'frame_width'            => 1.5,
        'glass_frame_width'      => 3.0,
        'interior_depth'         => 1.0,
        'floor_offset'           => 0.0,
        'swing_direction'        => 'left',
        'swing_side'             => 'auto',
        'slide_direction'        => 'left',
        'glass_grid_style'       => 'none',
        'exterior_casing_style'  => 'none',
        'interior_casing_style'  => 'none',
        'exterior_threshold'     => false
      }
    }.freeze

    # Multi-panel doors (3+): each panel 3 ft (36") min. Width = panels × 36" + jambs.
    PANEL_WIDTH_IN = 36.0
    JAMB_TOTAL_IN = 3.0
    FOUR_PANEL_PANEL_IN = PANEL_WIDTH_IN
    FOUR_PANEL_WIDTH_IN = (4 * PANEL_WIDTH_IN) + JAMB_TOTAL_IN

    MULTI_PANEL_GLASS = {
      'glass_frame_width' => 2.5,
      'glass_grid_style'  => 'none'
    }.freeze

    def self.width_for_panel_count(count)
      (count.to_i * PANEL_WIDTH_IN) + JAMB_TOTAL_IN
    end

    # Per-type defaults. Applied when the user picks a type in the dialog.
    TYPE_SETTING_OVERRIDES = {
      'interior' => {
        'Double'  => { 'width' => 60.0 },
        'Folding' => { 'width' => 48.0 },
        'Closet'  => { 'width' => 72.0, 'closet_leaf_count' => 2 },
        'Cased Opening' => { 'width' => 48.0, 'height' => 84.0 }
      },
      'exterior' => {
        'Front Door'              => { 'width' => 36.0, 'glass_frame_width' => 5.0, 'glass_grid_style' => 'none' },
        # Arched: full-glass door with a smooth arched top. Rise auto = semicircle
        # (blank arch_rise) unless set. Tall + narrow reads best.
        'Arched'                  => { 'width' => 36.0, 'height' => 96.0, 'frame_width' => 2.0,
                                       'glass_grid_style' => '2x3', 'arch_rise' => 0.0,
                                       'exterior_threshold' => false, 'exterior_casing_style' => 'none' },
        # Garage: standard 16ft x 7ft default; 18ft / 8ft picked via width/height.
        'Garage Door'             => { 'width' => 192.0, 'height' => 84.0,
                                       'exterior_threshold' => false,
                                       'exterior_casing_style' => 'none' },
        'Sliding'                 => { 'glass_frame_width' => 2.0, 'glass_grid_style' => 'none' },
        'French Hinged'           => { 'glass_frame_width' => 5.0, 'glass_grid_style' => '2x2' },
        '4-Panel Center Hinged'   => MULTI_PANEL_GLASS.merge('width' => width_for_panel_count(4)),
        '4-Panel Sliding'         => MULTI_PANEL_GLASS.merge('width' => width_for_panel_count(4)),
        '6-Panel Sliding'         => MULTI_PANEL_GLASS.merge('width' => width_for_panel_count(6)),
        '3-Panel Folding'         => MULTI_PANEL_GLASS.merge('width' => width_for_panel_count(3)),
        '4-Panel Folding'         => MULTI_PANEL_GLASS.merge('width' => width_for_panel_count(4)),
        '6-Panel Folding'         => MULTI_PANEL_GLASS.merge('width' => width_for_panel_count(6))
      }
    }.freeze

    def self.type_setting_overrides(category, door_type)
      cat = normalize_category(category)
      (TYPE_SETTING_OVERRIDES[cat] || {})[door_type.to_s] || {}
    end

    def self.defaults_for_type(category, door_type)
      defaults_for(category).merge(type_setting_overrides(category, door_type))
    end

    def self.ensure_dir
      dir = File.dirname(LIBRARY_FILE)
      Dir.mkdir(dir) unless Dir.exist?(dir)
    end

    def self.normalize_category(category)
      category.to_s == 'interior' ? 'interior' : 'exterior'
    end

    def self.normalize_casing_style(settings, side)
      key = "#{side}_casing_style"
      legacy = "#{side}_casing"
      styles = casing_styles(side)

      if settings[key] && !settings[key].to_s.empty?
        style = settings[key].to_s
        mapped = CASING_LEGACY_MAP[style] || style
        return mapped if styles.include?(mapped)
      end

      settings[legacy] ? 'flat' : 'none'
    end

    def self.defaults_for(category)
      CATEGORY_DEFAULTS[normalize_category(category)]
    end

    def self.built_in_types(category)
      BUILT_IN_BY_CATEGORY[normalize_category(category)] || EXTERIOR_TYPES
    end

    def self.load_custom_by_category
      return { 'exterior' => [], 'interior' => [] } unless File.exist?(LIBRARY_FILE)
      data = JSON.parse(File.read(LIBRARY_FILE))
      if data.is_a?(Array)
        { 'exterior' => data, 'interior' => [] }
      elsif data.is_a?(Hash)
        {
          'exterior' => (data['exterior'] || []).dup,
          'interior' => (data['interior'] || []).dup
        }
      else
        { 'exterior' => [], 'interior' => [] }
      end
    rescue
      { 'exterior' => [], 'interior' => [] }
    end

    def self.save_custom_by_category(custom)
      ensure_dir
      File.write(LIBRARY_FILE, JSON.pretty_generate(custom))
    end

    def self.all_types(category = 'exterior')
      cat = normalize_category(category)
      built_in_types(cat) + load_custom_by_category[cat]
    end

    def self.add_custom(name, category = 'exterior')
      cat = normalize_category(category)
      name = name.to_s.strip
      return all_types(cat) if name.empty?

      custom = load_custom_by_category
      return all_types(cat) if custom[cat].include?(name)

      custom[cat] << name
      save_custom_by_category(custom)
      all_types(cat)
    end

    # Backward compatibility for any code calling all_types without category.
    def self.all_types_legacy
      all_types('exterior')
    end

  end
end
