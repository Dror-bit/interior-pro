# encoding: utf-8
# debug_images.rb - why is the render not showing in the sheet window?
#
# Writes image_report.txt into the plugin folder. Nobody has to read it in the
# console; the file says everything.
#
# It answers three questions:
#   1. Are the pictures actually on the pages, and under which paths?
#   2. Can SketchUp make a small copy of one (ImageRep#resize / #save_as)?
#   3. Will the window show a picture straight off the disk (file:///),
#      or only as a data: URL?
#
# Ruby Console:
#   load File.join(InteriorPro::PLUGIN_DIR, 'debug_images.rb')

module InteriorPro
  module DebugImages
    REPORT = File.join(PLUGIN_DIR, 'image_report.txt') unless const_defined?(:REPORT)

    def self.run
      @lines = []
      say "Interior Pro - image report - #{Time.now}"
      say "SketchUp #{Sketchup.version}"
      say ''

      st = PlanSheetDialog.load_state
      paths = Array(st['images'])
      say "-- state ------------------------------------------------------"
      say "images in the settings: #{paths.length}"
      paths.first(3).each { |p| say "  #{p}" }
      say "  ... (#{paths.length - 3} more)" if paths.length > 3
      say "every file exists on disk: #{paths.all? { |p| File.file?(p) }}"
      missing = paths.reject { |p| File.file?(p) }
      missing.first(3).each { |p| say "  MISSING #{p}" }
      say ''

      say "-- the document ------------------------------------------------"
      doc = PlanSheetDialog.document
      say "pages: #{doc.pages.length}"
      doc.pages.each do |pg|
        imgs = pg.layer?(PlanDoc::IMAGE_LAYER) ? pg.layer(PlanDoc::IMAGE_LAYER).shapes : []
        say "  #{pg.name} | views #{pg.views.length} | image shapes #{imgs.length}" \
            "#{imgs.empty? ? '' : " | #{imgs[0][:path]}"}"
      end
      say "shape path == settings path: " \
          "#{doc.pages.flat_map { |p| p.layer?(PlanDoc::IMAGE_LAYER) ? p.layer(PlanDoc::IMAGE_LAYER).shapes : [] }
                      .map { |s| s[:path] }.all? { |p| paths.include?(p) }}"
      say ''

      sample = paths.find { |p| File.file?(p) }
      say "-- can SketchUp shrink a picture? -------------------------------"
      if sample.nil?
        say 'no readable file to try'
      else
        say "trying: #{File.basename(sample)}"
        say "Sketchup::ImageRep defined: #{defined?(Sketchup::ImageRep) ? 'yes' : 'NO'}"
        begin
          rep = Sketchup::ImageRep.new
          rep.load_file(sample)
          say "loaded: #{rep.width} x #{rep.height}, #{rep.bits_per_pixel} bits"
          say "responds to resize: #{rep.respond_to?(:resize)}"
          say "responds to save_as: #{rep.respond_to?(:save_as)}"
          if rep.respond_to?(:resize)
            small = rep.resize(260, (260.0 * rep.height / rep.width).round)
            say "resize gave: #{small.class} #{small.width rescue '?'} x #{small.height rescue '?'}"
            tmp = File.join(PLUGIN_DIR, '_probe.png')
            small.save_as(tmp)
            say "save_as wrote: #{File.exist?(tmp) ? File.size(tmp) : 'NOTHING'} bytes"
            @thumb_bytes = File.exist?(tmp) ? File.size(tmp) : 0
            File.delete(tmp) if File.exist?(tmp)
          end
        rescue StandardError => e
          say "ImageRep FAILED: #{e.class}: #{e.message}"
        end
        say "what the window builds now: " \
            "#{(PlanSheetDialog.send(:build_thumb, sample) || 'nil').to_s[0, 40]}"
      end
      say ''

      @sample = sample
      probe_window
      nil
    rescue StandardError => e
      say "REPORT FAILED: #{e.class}: #{e.message}"
      say e.backtrace.first(6).join("\n")
      finish
    end

    # Ask the window itself what it can load. Only the window knows.
    def self.probe_window
      unless @sample
        say '-- the window: skipped, no file to try --'
        return finish
      end
      url = 'file:///' + @sample.tr('\\', '/').sub(%r{\A/+}, '')
      dlg = UI::HtmlDialog.new(dialog_title: 'probe', width: 320, height: 120)
      dlg.add_action_callback('probe_result') do |_, json|
        r = JSON.parse(json.to_s) rescue {}
        say '-- the window ---------------------------------------------------'
        say "file:/// loaded:  #{r['file']}"
        say "data: URL loaded: #{r['data']}"
        say "url tried: #{url}"
        finish
        begin; dlg.close; rescue StandardError; end
      end
      dlg.set_html(probe_html(url))
      dlg.show
    end

    def self.probe_html(url)
      esc = url.gsub('"', '%22')
      <<~HTML
        <html><body style="font:12px sans-serif;background:#222;color:#ddd">
        בודק...
        <script>
        var out={file:'no answer',data:'no answer'};
        function done(){ sketchup.probe_result(JSON.stringify(out)); }
        var a=new Image();
        a.onload=function(){ out.file='YES '+a.naturalWidth+'x'+a.naturalHeight; step2(); };
        a.onerror=function(){ out.file='NO'; step2(); };
        a.src="#{esc}";
        function step2(){
          var b=new Image();
          // a 1x1 red gif, just to prove data: urls work at all
          b.onload=function(){ out.data='YES'; done(); };
          b.onerror=function(){ out.data='NO'; done(); };
          b.src='data:image/gif;base64,R0lGODlhAQABAIAAAP8AAAAAACH5BAAAAAAALAAAAAABAAEAAAICRAEAOw==';
        }
        setTimeout(function(){ done(); }, 4000);
        </script></body></html>
      HTML
    end

    def self.say(line)
      (@lines ||= []) << line.to_s
    end

    def self.finish
      File.write(REPORT, @lines.join("\n"))
      puts "written: #{REPORT}"
      nil
    end
  end
end

require 'json'
InteriorPro::DebugImages.run
