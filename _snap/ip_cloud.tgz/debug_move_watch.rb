# encoding: utf-8
# debug_move_watch.rb - READ ONLY. Catches a wall moving that nobody asked to
# move.
#
# The probe on 2026-08-18 proved there are NO duplicate ids left, and that
# find_neighbor_at, weld_drifted_end! and wall_stretch_tool all DO filter by
# level. So something else is reaching across floors, and guessing which tool
# would just be another wrong answer. This watches instead.
#
# HOW TO USE - the same line twice:
#
#   1. Ruby Console:
#        load 'C:/.../interior_pro/debug_move_watch.rb'
#      It says SNAPSHOT TAKEN.
#
#   2. Now move ONE wall upstairs, however you normally do it.
#
#   3. Run the SAME line again.
#      It says what moved, and writes move_watch_report.txt.
#
# It knows which wall you meant to move (the one that moved most) and calls
# everything else COLLATERAL - that is the list that matters.
#
# Nothing is ever changed. The snapshot lives next to the plugin as
# move_watch_snapshot.txt; delete it to start over.

module InteriorPro
  module MoveWatch
    DIR  = File.dirname(__FILE__)
    SNAP = File.join(DIR, 'move_watch_snapshot.txt')
    OUT  = File.join(DIR, 'move_watch_report.txt')

    def self.walls
      Sketchup.active_model.entities.grep(Sketchup::Group).select do |g|
        g.valid? && g.get_attribute('InteriorPro', 'type') == 'wall'
      end
    end

    def self.state
      walls.map do |g|
        t = g.transformation
        sx = g.get_attribute('InteriorPro', 'start_x').to_f
        sy = g.get_attribute('InteriorPro', 'start_y').to_f
        ex = g.get_attribute('InteriorPro', 'end_x').to_f
        ey = g.get_attribute('InteriorPro', 'end_y').to_f
        s = Geom::Point3d.new(sx, sy, 0).transform(t)
        e = Geom::Point3d.new(ex, ey, 0).transform(t)
        { id: (g.get_attribute('InteriorPro', 'id') || '?').to_s,
          lvl: (g.get_attribute('InteriorPro', 'level') || 1).to_i,
          th: g.get_attribute('InteriorPro', 'thickness').to_f,
          sx: s.x.to_f, sy: s.y.to_f, ex: e.x.to_f, ey: e.y.to_f }
      end
    end

    def self.save(st)
      File.open(SNAP, 'w') do |f|
        st.each do |w|
          f.puts [w[:id], w[:lvl], w[:th], w[:sx], w[:sy], w[:ex], w[:ey]].join("\t")
        end
      end
    end

    def self.load_snap
      return nil unless File.exist?(SNAP)
      File.readlines(SNAP).map do |ln|
        a = ln.chomp.split("\t")
        next if a.length < 7
        { id: a[0], lvl: a[1].to_i, th: a[2].to_f,
          sx: a[3].to_f, sy: a[4].to_f, ex: a[5].to_f, ey: a[6].to_f }
      end.compact
    end

    def self.run
      now = state
      before = load_snap
      if before.nil?
        save(now)
        puts "[MoveWatch] SNAPSHOT TAKEN - #{now.length} wall(s). " \
             'Now move ONE wall, then run this line again.'
        return :snapped
      end

      old = {}
      before.each { |w| old[w[:id]] = w }
      moved = []
      now.each do |w|
        o = old[w[:id]]
        unless o
          moved << { w: w, d: nil, note: 'NEW - did not exist in the snapshot' }
          next
        end
        ds = Math.sqrt((w[:sx] - o[:sx])**2 + (w[:sy] - o[:sy])**2)
        de = Math.sqrt((w[:ex] - o[:ex])**2 + (w[:ey] - o[:ey])**2)
        d = [ds, de].max
        next if d < 0.001
        moved << { w: w, o: o, ds: ds, de: de, d: d }
      end
      gone = old.keys - now.map { |w| w[:id] }

      o = []
      o << '=' * 74
      o << "MOVE WATCH  #{Time.now}"
      o << '=' * 74
      o << "#{before.length} wall(s) before, #{now.length} now"
      o << ''

      if moved.empty? && gone.empty?
        o << 'NOTHING MOVED. Either the edit was undone, or it did not touch'
        o << 'any wall geometry. Take a fresh snapshot and try again.'
      else
        moved.sort_by! { |m| -(m[:d] || 0) }
        lead = moved.first
        o << 'THE ONE YOU MEANT TO MOVE (it moved the most):'
        o << format('  %s   level %d   moved %.3f"', lead[:w][:id][0, 12],
                    lead[:w][:lvl], lead[:d] || 0)
        o << ''
        rest = moved[1..-1] || []
        collateral = rest.reject { |m| m[:w][:lvl] == lead[:w][:lvl] }
        same = rest.select { |m| m[:w][:lvl] == lead[:w][:lvl] }

        o << ">>> COLLATERAL ON ANOTHER FLOOR: #{collateral.length}"
        o << '    (this is the bug. these should not have moved at all)'
        collateral.each do |m|
          o << format('    %s  level %d  start %.3f"  end %.3f"',
                      m[:w][:id][0, 12], m[:w][:lvl], m[:ds], m[:de])
          o << format('        (%.2f,%.2f)->(%.2f,%.2f)   became   (%.2f,%.2f)->(%.2f,%.2f)',
                      m[:o][:sx], m[:o][:sy], m[:o][:ex], m[:o][:ey],
                      m[:w][:sx], m[:w][:sy], m[:w][:ex], m[:w][:ey])
        end
        o << '    none - nothing on another floor moved.' if collateral.empty?
        o << ''
        o << "same-floor neighbours that followed (usually correct): #{same.length}"
        same.each do |m|
          o << format('    %s  level %d  moved %.3f"', m[:w][:id][0, 12], m[:w][:lvl], m[:d])
        end
        unless gone.empty?
          o << ''
          o << "walls that DISAPPEARED: #{gone.length}"
          gone.each { |g| o << "    #{g[0, 12]} (level #{old[g][:lvl]})" }
        end
      end

      File.open(OUT, 'w') { |f| f.puts(o.join("\n")) }
      save(now)   # the new state becomes the next baseline
      puts "[MoveWatch] compared. report: #{OUT}  (new snapshot taken)"
      :diffed
    rescue StandardError => e
      File.open(OUT, 'w') { |f| f.puts("CRASHED: #{e.class}: #{e.message}\n" + e.backtrace.first(8).join("\n")) }
      puts "[MoveWatch] crashed - details in #{OUT}"
      :error
    end
  end
end

InteriorPro::MoveWatch.run
