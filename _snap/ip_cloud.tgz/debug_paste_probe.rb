# Interior Pro - measurement only. Heals NOTHING, changes NOTHING.
#
# WHY THIS EXISTS
# WallTool.ensure_unique_ids! only ever runs from RoomManager.sync_rooms!,
# and sync_rooms! runs AFTER a wall edit. So the FIRST edit after a paste
# still works on duplicate ids, and by the time any report is run afterwards
# the duplicates have already been healed and the evidence is gone.
#
# RUN THIS IMMEDIATELY AFTER PASTING, BEFORE TOUCHING ANYTHING.
#
# It also records entityID (SketchUp hands them out in creation order, so the
# SMALLER number is the older wall) - which is what a correct "who keeps the
# name" rule should use. The current rule keeps whichever wall has an
# identity transformation, and on this model almost none do, so it silently
# falls through to "whichever came first in the scan" - meaning the ORIGINAL
# can get renamed and the COPY can inherit its name.
module InteriorPro
  module DebugPasteProbe
    def self.run
      out = []
      m = Sketchup.active_model
      walls = m.entities.grep(Sketchup::Group).select { |g|
        g.get_attribute('InteriorPro', 'type') == 'wall'
      }
      out << "walls at top level: #{walls.size}"
      out << ""

      by_id = Hash.new { |h, k| h[k] = [] }
      walls.each { |w| by_id[w.get_attribute('InteriorPro', 'id').to_s] << w }
      dup = by_id.select { |_k, v| v.size > 1 }

      out << "== DUPLICATE ids RIGHT NOW (before anything healed them) =="
      out << "  duplicate ids: #{dup.size}   <== THE ANSWER"
      out << ""
      dup.each do |id, ws|
        out << "  id #{id}"
        ident = ws.select { |w| w.transformation.identity? }
        out << "    walls: #{ws.size}   with an IDENTITY transformation: #{ident.size}"
        out << "    (the current keeper rule needs exactly one identity wall; " \
               "#{ident.size == 1 ? 'it has one' : 'it does NOT - so it falls back to whatever came first'})"
        ws.sort_by(&:entityID).each do |w|
          o = w.transformation.origin
          out << format('      entityID=%-8d lvl=%-2s identity=%-5s origin=(%.2f, %.2f, %.2f) start=(%s, %s)',
                        w.entityID,
                        (w.get_attribute('InteriorPro', 'level') || 1).to_s,
                        w.transformation.identity?.to_s,
                        o.x, o.y, o.z,
                        w.get_attribute('InteriorPro', 'start_x'),
                        w.get_attribute('InteriorPro', 'start_y'))
        end
        keeper = ws.find { |w| w.transformation.identity? } || ws.first
        oldest = ws.min_by(&:entityID)
        out << "    current rule would KEEP entityID=#{keeper.entityID} (level #{keeper.get_attribute('InteriorPro','level') || 1})"
        out << "    oldest wall is        entityID=#{oldest.entityID} (level #{oldest.get_attribute('InteriorPro','level') || 1})"
        out << (keeper == oldest ? '    -> same wall, the rule got it right here' :
                                   '    -> DIFFERENT: the rule renames the ORIGINAL and lets the COPY keep the name')
        out << ""
      end

      out << "== who still points at a wall BY id =="
      refs = Hash.new(0)
      m.entities.to_a.each do |e|
        next unless e.respond_to?(:get_attribute)
        h = e.get_attribute('InteriorPro', 'host_wall_id')
        refs[h.to_s] += 1 unless h.nil?
        b = e.get_attribute('InteriorPro', 'bounding_wall_ids')
        Array(b).each { |x| refs[x.to_s] += 1 } if b.is_a?(Array)
      end
      touched = dup.keys.select { |k| refs[k] > 0 }
      out << "  duplicate ids that a door / window / room still points at: #{touched.size}"
      touched.each { |k| out << "    #{k} : #{refs[k]} reference(s) - ensure_unique_ids! SKIPS these entirely" }
      out << ""
      out << "== VERDICT HINT =="
      out << "  duplicates > 0  -> the paste really does hand out two walls with one name,"
      out << "                     and the first 2D edit afterwards can hit the wrong one."
      out << "  duplicates = 0  -> something healed before this ran; tell me what you clicked."

      path = File.join(File.dirname(__FILE__), 'paste_probe_report.txt')
      File.open(path, 'w') { |f| f.puts out.join("\n") }
      UI.messagebox("Done. Report written:\n#{path}")
      nil
    end
  end
end
InteriorPro::DebugPasteProbe.run
