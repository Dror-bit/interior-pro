# encoding: utf-8
# debug_valiroof.rb - READ ONLY. Measures how somebody else's roof is built.
#
# Written 2026-08-18 to answer one question: does Instant Roof (Vali
# Architects) make every tile a real ComponentInstance of ONE definition, or
# does it make unique geometry, or long strips?
#
# The answer decides how we build ours. Nothing here changes the model.
#
# HOW TO RUN
#   1. Open the project that has the Instant Roof roof in it.
#   2. Click the roof ONCE so it is selected (a single click on the group).
#      If you cannot select it, run it anyway - it will scan the whole model.
#   3. Ruby Console:  load 'C:/Users/rordt/debug_valiroof.rb'
#   4. Report lands next to the plugin as valiroof_report.txt

module ValiProbe
  OUT = File.join(File.dirname(__FILE__), 'valiroof_report.txt')

  def self.run
    model = Sketchup.active_model
    lines = []
    lines << '=' * 72
    lines << 'VALI / INSTANT ROOF PROBE  (read only)'
    lines << "model: #{model.title}"
    lines << "path : #{model.path}"
    lines << '=' * 72
    lines << ''

    roots = model.selection.to_a.reject { |e| e.is_a?(Sketchup::Edge) || e.is_a?(Sketchup::Face) }
    if roots.empty?
      lines << 'Nothing selected - scanning EVERY top level group/component.'
      roots = model.entities.to_a.select do |e|
        e.is_a?(Sketchup::Group) || e.is_a?(Sketchup::ComponentInstance)
      end
    else
      lines << "Selected #{roots.length} object(s)."
    end
    lines << ''

    # ---------- model-wide picture first -------------------------------
    defs = model.definitions.reject(&:image?)
    lines << "MODEL TOTALS"
    lines << "  component definitions : #{defs.length}"
    lines << "  faces at top level    : #{model.entities.grep(Sketchup::Face).length}"
    lines << ''

    # ---------- the interesting part: definitions by instance count ----
    rows = defs.map do |d|
      { name: d.name,
        inst: d.count_used_instances,
        faces: d.entities.grep(Sketchup::Face).length,
        edges: d.entities.grep(Sketchup::Edge).length,
        subs: d.entities.grep(Sketchup::ComponentInstance).length +
              d.entities.grep(Sketchup::Group).length,
        bb: d.bounds }
    end
    rows.sort_by! { |r| -r[:inst] }

    lines << 'DEFINITIONS, MOST-REPEATED FIRST'
    lines << '  (a high instance count + a low face count = the component trick)'
    lines << ''
    lines << format('  %-34s %8s %7s %7s %6s  %s',
                    'definition', 'instances', 'faces', 'edges', 'nested', 'size w x d x h (in)')
    lines << '  ' + '-' * 96
    rows.first(40).each do |r|
      b = r[:bb]
      size = format('%.1f x %.1f x %.1f', b.width, b.depth, b.height)
      lines << format('  %-34s %8d %7d %7d %6d  %s',
                      r[:name][0, 34], r[:inst], r[:faces], r[:edges], r[:subs], size)
    end
    lines << "  ... #{rows.length - 40} more definitions" if rows.length > 40
    lines << ''

    uniq_faces = rows.sum { |r| r[:faces] }
    drawn_faces = rows.sum { |r| r[:faces] * [r[:inst], 1].max }
    lines << format('  UNIQUE faces stored in definitions : %d', uniq_faces)
    lines << format('  faces actually DRAWN on screen     : %d', drawn_faces)
    if uniq_faces > 0
      lines << format('  saving from re-use                 : %.1f x', drawn_faces.to_f / uniq_faces)
    end
    lines << ''

    # ---------- walk what he selected ----------------------------------
    roots.each_with_index do |root, i|
      lines << '-' * 72
      lines << "ROOT #{i}: #{root.class.name.split('::').last}  name=#{safe_name(root)}"
      b = root.bounds
      lines << format('  size %.1f x %.1f x %.1f in', b.width, b.depth, b.height)
      lines.concat(walk(root, 1, {}))
      lines << ''
    end

    # ---------- materials: textured or plain colour? -------------------
    lines << '-' * 72
    lines << 'MATERIALS (is the tile a texture, a colour, or both?)'
    model.materials.each do |m|
      tex = m.texture
      if tex
        lines << format('  %-32s texture %-28s %.1f x %.1f in',
                        m.display_name[0, 32], File.basename(tex.filename.to_s)[0, 28],
                        tex.width, tex.height)
      else
        c = m.color
        lines << format('  %-32s plain colour  rgb(%d,%d,%d)',
                        m.display_name[0, 32], c.red, c.green, c.blue)
      end
    end
    lines << ''
    lines << 'END'

    File.open(OUT, 'w') { |f| f.puts(lines.join("\n")) }
    puts "[ValiProbe] written: #{OUT}"
    OUT
  end

  def self.safe_name(e)
    n = e.respond_to?(:name) ? e.name.to_s : ''
    n = e.definition.name.to_s if n.empty? && e.respond_to?(:definition)
    n.empty? ? '(unnamed)' : n
  end

  # Recursive, but it only PRINTS a summary per level so a 5000-tile roof
  # does not produce a 5000-line file.
  def self.walk(inst, depth, seen, out = [])
    ents = if inst.respond_to?(:definition)
             inst.definition.entities
           elsif inst.respond_to?(:entities)
             inst.entities
           end
    return out if ents.nil? || depth > 5
    pad = '  ' * (depth + 1)
    faces = ents.grep(Sketchup::Face).length
    edges = ents.grep(Sketchup::Edge).length
    kids  = ents.grep(Sketchup::ComponentInstance) + ents.grep(Sketchup::Group)
    out << format('%slevel %d: %d faces, %d edges, %d children here',
                  pad, depth, faces, edges, kids.length)
    return out if kids.empty?

    # group the children by what they ARE
    tally = Hash.new(0)
    kids.each { |k| tally[safe_name(k)] += 1 }
    tally.sort_by { |_, v| -v }.first(12).each do |name, n|
      sample = kids.find { |k| safe_name(k) == name }
      sb = sample.bounds
      out << format('%s  x%-5d %-30s %.1f x %.1f x %.1f in', pad, n, name[0, 30],
                    sb.width, sb.depth, sb.height)
    end
    out << format('%s  ... %d more kinds', pad, tally.length - 12) if tally.length > 12

    # go one level deeper into ONE example of each kind only
    tally.keys.first(4).each do |name|
      sample = kids.find { |k| safe_name(k) == name }
      key = safe_name(sample)
      next if seen[key]
      seen[key] = true
      out << format('%s  into "%s":', pad, name[0, 30])
      walk(sample, depth + 1, seen, out)
    end
    out
  end
end

ValiProbe.run
