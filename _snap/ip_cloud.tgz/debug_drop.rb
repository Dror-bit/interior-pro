# encoding: utf-8
# debug_drop.rb - can the sheet window take several pictures at once?
#
# Two things the user asked for: tick a few files and press open, and drag a
# handful straight into the window. Both need the window to tell Ruby WHERE the
# files are. A browser normally refuses to say - it hands over the contents and
# hides the path. SketchUp's window is not quite a browser, so it might.
#
# Nothing is guessed here. Do both, and the answer is written to
# drop_report.txt in the plugin folder.
#
# Ruby Console:
#   load File.join(InteriorPro::PLUGIN_DIR, 'debug_drop.rb')

require 'json'

module InteriorPro
  module DebugDrop
    REPORT = File.join(PLUGIN_DIR, 'drop_report.txt') unless const_defined?(:REPORT)

    def self.run
      @lines = ["Interior Pro - drop report - #{Time.now}",
                "SketchUp #{Sketchup.version}", '']
      @dlg = UI::HtmlDialog.new(dialog_title: 'בדיקת גרירה',
                                preferences_key: 'InteriorPro_DropProbe',
                                width: 460, height: 420, resizable: true)

      @dlg.add_action_callback('probe') do |_, json|
        begin
          r = JSON.parse(json.to_s)
          say "-- #{r['how']} --------------------------------------------"
          say "files handed over: #{r['count']}"
          Array(r['files']).each_with_index do |f, i|
            say "  [#{i}] name: #{f['name']}"
            say "      size: #{f['size']}"
            say "      path property: #{f['path'].nil? ? 'NOT THERE' : f['path'].inspect}"
            say "      webkitRelativePath: #{f['rel'].to_s.empty? ? '(empty)' : f['rel']}"
            say "      exists on disk at that path: " \
                "#{f['path'] && File.file?(f['path'].to_s) ? 'YES' : 'no'}"
          end
          say "keys the window can see on a file: #{Array(r['keys']).join(', ')}"
          say ''
          write!
        rescue StandardError => e
          say "probe failed: #{e.message}"
          write!
        end
      end

      @dlg.add_action_callback('finish') do |_|
        write!
        begin; @dlg.close; rescue StandardError; end
      end

      @dlg.set_html(html)
      @dlg.show
      nil
    end

    def self.say(l); (@lines ||= []) << l.to_s; end

    def self.write!
      File.write(REPORT, @lines.join("\n"))
      puts "written: #{REPORT}"
      nil
    end

    def self.html
      <<~'HTML'
        <!DOCTYPE html><html><head><meta charset="utf-8"><style>
          body{font:14px Segoe UI,Arial;background:#2b2b2b;color:#eee;padding:14px;margin:0}
          #zone{border:2px dashed #777;border-radius:8px;padding:34px 14px;
                text-align:center;color:#bbb;margin:12px 0;background:#1e1e1e}
          #zone.hot{border-color:#1f6feb;color:#9ecbff;background:#16283f}
          button{width:100%;padding:10px;margin-top:8px;background:#4a4a4a;color:#fff;
                 border:1px solid #666;border-radius:4px;cursor:pointer;font-size:14px}
          button.go{background:#1f6feb;border-color:#1f6feb;font-weight:600}
          #log{margin-top:12px;font-size:12px;color:#9ecbff;min-height:40px;white-space:pre-line}
          input[type=file]{display:none}
        </style></head><body>
          <b>שני דברים, בכל סדר:</b>
          <div id="zone">גרור לכאן כמה תמונות</div>
          <button id="pick">או: בחר כמה קבצים ולחץ Open</button>
          <input type="file" id="f" multiple accept="image/*">
          <div id="log">מחכה...</div>
          <button id="done" class="go">סיימתי — כתוב את הדוח</button>
        <script>
        function look(list, how){
          var files=[], keys=[];
          for(var i=0;i<list.length && i<5;i++){
            var f=list[i];
            if(i===0){ for(var k in f) keys.push(k); }
            files.push({ name:f.name, size:f.size,
                         path:(f.path===undefined?null:f.path),
                         rel:(f.webkitRelativePath||'') });
          }
          sketchup.probe(JSON.stringify({how:how,count:list.length,files:files,keys:keys}));
          var got = files.length && files[0].path ? 'יש נתיב ✓' : 'אין נתיב';
          document.getElementById('log').textContent =
            how+': '+list.length+' קבצים · '+got;
        }
        var z=document.getElementById('zone');
        ['dragenter','dragover'].forEach(function(e){
          z.addEventListener(e,function(ev){ ev.preventDefault(); ev.stopPropagation();
            z.className='hot'; });
        });
        ['dragleave','drop'].forEach(function(e){
          z.addEventListener(e,function(ev){ ev.preventDefault(); ev.stopPropagation();
            z.className=''; });
        });
        z.addEventListener('drop',function(ev){
          var dt=ev.dataTransfer;
          look(dt.files||[], 'גרירה');
        });
        window.addEventListener('dragover',function(e){ e.preventDefault(); });
        window.addEventListener('drop',function(e){ e.preventDefault(); });
        document.getElementById('pick').onclick=function(){ document.getElementById('f').click(); };
        document.getElementById('f').onchange=function(){ look(this.files||[], 'בחירה מרובה'); };
        document.getElementById('done').onclick=function(){ sketchup.finish(); };
        </script></body></html>
      HTML
    end
  end
end

InteriorPro::DebugDrop.run
