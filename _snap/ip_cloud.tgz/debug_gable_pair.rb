# encoding: utf-8
# debug_gable_pair.rb - READ ONLY. Dumps everything needed to rebuild the
# user's exact house in the cloud stub: walls, gable marks, roof settings,
# the eave polygon, and what framed_plan makes of it.
#
# Ruby Console:
#   load 'C:/Users/rordt/AppData/Roaming/SketchUp/SketchUp 2024/SketchUp/Plugins/interior_pro/debug_gable_pair.rb'
# Report: gable_pair_report.txt next to the plugin. Nothing is changed.

module InteriorPro
  module GablePairProbe
    OUT = File.join(File.dirname(__FILE__), 'gable_pair_report.txt')

    def self.run
      rf = InteriorPro::RoofManager
      lm = InteriorPro::LevelManager
      out = []
      out << '=' * 72
      out << "GABLE PAIR PROBE  (read only)   #{Time.now}"
      out << '=' * 72

      # ---------------------------------------------------------- levels
      begin
        out << "top_level = #{rf.top_level.inspect}"
      rescue StandardError => e
        out << "top_level RAISED: #{e.message}"
      end

      # ----------------------------------------------------------- walls
      walls = lm.all_walls
      out << ''
      out << "ALL WALLS (#{walls.length})"
      out << format('  %-14s %-9s %-9s %-9s %-9s %6s %6s %6s %3s %-9s %s',
                    'id', 'sx', 'sy', 'ex', 'ey', 'th', 'h', 'base', 'lvl', 'cat', 'sag')
      out << '  ' + '-' * 104
      walls.each do |w|
        g = lambda { |k| w.get_attribute('InteriorPro', k) }
        out << format('  %-14s %-9s %-9s %-9s %-9s %6s %6s %6s %3s %-9s %s',
                      g.call('id').to_s[0, 14],
                      g.call('start_x').to_f.round(2), g.call('start_y').to_f.round(2),
                      g.call('end_x').to_f.round(2), g.call('end_y').to_f.round(2),
                      g.call('thickness').to_f.round(2), g.call('height').to_f.round(2),
                      g.call('base_z').to_f.round(2), (g.call('level') || 1).to_i,
                      (g.call('wall_category') || 'exterior').to_s[0, 9],
                      g.call('arc_sag').nil? ? '-' : g.call('arc_sag').to_f.round(3))
        t = w.transformation
        o = t.origin
        unless o.x.abs < 0.001 && o.y.abs < 0.001 && o.z.abs < 0.001
          out << "      ^ NON-IDENTITY transformation, origin = #{[o.x.round(3), o.y.round(3), o.z.round(3)].inspect}"
        end
      end

      # ---------------------------------------------------- gable marks
      out << ''
      begin
        marked = rf.gable_wall_ids
        out << "gable_wall_ids  = #{marked.inspect}"
      rescue StandardError => e
        out << "gable_wall_ids RAISED: #{e.message}"
      end
      begin
        pts = rf.gable_click_points
        out << "gable_click_pts = #{pts.map { |p| p[0].to_f > 1.0e8 ? 'none' : [p[0].to_f.round(2), p[1].to_f.round(2)] }.inspect}"
      rescue StandardError => e
        out << "gable_click_points RAISED: #{e.message}"
      end

      # ------------------------------------------------------- settings
      out << ''
      s = rf.settings
      out << 'MODEL ROOF SETTINGS'
      s.keys.sort_by(&:to_s).each { |k| out << format('  %-16s %s', k, s[k].inspect) }

      # ------------------------------------------------- existing roofs
      roofs = Sketchup.active_model.entities.grep(Sketchup::Group).select do |gp|
        gp.get_attribute('InteriorPro', 'type') == 'roof'
      end
      out << ''
      out << "ROOF GROUPS IN THE MODEL: #{roofs.length}"
      roofs.each_with_index do |gp, i|
        out << "  roof##{i}  level=#{gp.get_attribute('InteriorPro', 'level').inspect}  " \
               "style=#{gp.get_attribute('InteriorPro', 'roof_style').inspect}  " \
               "ridge_z=#{gp.get_attribute('InteriorPro', 'ridge_z').inspect}  " \
               "faces=#{gp.entities.grep(Sketchup::Face).length}"
        begin
          out << "        wall_ids   = #{rf.roof_wall_ids(gp).inspect}"
          out << "        gable_ids  = #{rf.roof_gable_ids(gp).inspect}"
        rescue StandardError => e
          out << "        marks RAISED: #{e.message}"
        end
        begin
          rs = rf.roof_settings(gp)
          out << "        settings   = #{rs.reject { |k, _| k == :roof_material }.inspect}"
        rescue StandardError => e
          out << "        settings RAISED: #{e.message}"
        end
      end

      # -------------------------------------------- the loop and the plan
      out << ''
      lvl = rf.top_level
      tw = rf.walls_of(lvl) rescue rf.top_walls
      out << "walls handed to the roof on level #{lvl}: #{tw.length}"
      ep = tw.length >= 3 ? rf.eave_polygon(tw, s[:overhang]) : nil
      if ep.nil?
        out << 'eave_polygon = nil  <-- no closed loop'
      else
        out << "eave polygon (#{ep[:pts].length} pts, overhang #{s[:overhang]}):"
        ep[:pts].each_with_index do |p, i|
          out << format('  %2d  (%9.2f, %9.2f)   wall=%s', i, p[0], p[1], ep[:wall_ids][i].inspect)
        end
        marked = (rf.gable_wall_ids rescue [])
        loop_ids = ep[:wall_ids].compact
        out << ''
        out << "marks that are ON the loop: #{(marked & loop_ids).inspect}"
        out << "marks that are OFF the loop (ignored): #{(marked - loop_ids).inspect}"
        gables = (0...ep[:pts].length).select { |i| ep[:wall_ids][i] && marked.include?(ep[:wall_ids][i]) }
        out << "gable poly edges from the marks: #{gables.inspect}"
        begin
          plan = rf.framed_plan(ep[:pts], ep[:wall_ids], marked, s[:style])
          if plan.nil?
            out << 'framed_plan = nil  <-- strip-gable fallback is what builds it'
          else
            out << 'framed_plan:'
            out << "  main   = #{plan[:main].map { |v| v.round(2) }.inspect}"
            out << "  g      = #{plan[:g].inspect}"
            out << "  edges  = #{plan[:edges].inspect}"
            out << "  score  = #{plan[:score].inspect}   nrects=#{plan[:nrects].inspect}"
            plan[:wings].each_with_index do |w, wi|
              out << "  wing#{wi} rect=#{w[:rect].map { |v| v.round(2) }.inspect}  " \
                     "mouth=#{w[:mouth].inspect}  gabled=#{w[:gabled].inspect}"
            end
          end
        rescue StandardError => e
          out << "framed_plan RAISED: #{e.class}: #{e.message}"
          out << e.backtrace.first(6).map { |l| '    ' + l }.join("\n")
        end
      end

      File.open(OUT, 'w') { |f| f.puts out.join("\n") }
      puts "[GablePairProbe] wrote #{OUT}  (#{out.length} lines)"
    rescue StandardError => e
      puts "[GablePairProbe] FAILED: #{e.class}: #{e.message}"
      puts e.backtrace.first(8)
    end
  end
end

InteriorPro::GablePairProbe.run
