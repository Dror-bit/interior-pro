# debug_corners_all.rb - READ ONLY. A full audit of every wall END.
#
# ROUND 2 (2026-08-17): measures CENTRELINE ends, not drawn ends.
# A wall anchored left and a wall anchored right put their thickness on
# opposite sides of the line the user drew, so their DRAWN ends sit up to a
# thickness apart even when the corner is perfect. find_neighbor_at knows
# this - its second pass compares centrelines. Round 1 compared drawn ends
# and so reported a perfect mixed-anchor corner as a 5" hole.
# Writes corners_report.txt next to this file. Changes NOTHING in the model.
#
# For each end of each wall it answers three questions:
#   1. Is there another wall's end meant to meet it, and how far off is it?
#   2. Is this end still a plain square cut (never mitered)?
#   3. Does it land in the MIDDLE of another wall (a T joint)?
#
# A plain square end is what shows up as a white wedge in the model: only the
# long faces get painted, so an unjoined end cap stays the default colour.
#
# Ruby Console:
#   load 'C:/Users/rordt/AppData/Roaming/SketchUp/SketchUp 2024/SketchUp/Plugins/interior_pro/debug_corners_all.rb'

module InteriorPro
  module DebugCornersAll
    OUT = File.join(File.dirname(__FILE__), 'corners_report.txt')

    TOUCH = 0.02   # inches - closer than this counts as "the same point"
    NEAR  = 24.0   # inches - a partner this close was almost certainly meant

    def self.at(g, k)
      g.get_attribute('InteriorPro', k)
    rescue StandardError
      nil
    end

    def self.wp(g, x, y)
      Geom::Point3d.new(x.to_f, y.to_f, 0).transform(g.transformation)
    rescue StandardError
      Geom::Point3d.new(x.to_f, y.to_f, 0)
    end

    def self.d2(a, b)
      Math.sqrt((a.x.to_f - b.x.to_f)**2 + (a.y.to_f - b.y.to_f)**2)
    end

    def self.r(v)
      v.to_f.round(3)
    end

    def self.ps(p)
      "(#{p.x.to_f.round(1)},#{p.y.to_f.round(1)})"
    end

    # Distance from point p to segment a-b, and how far along it lands (0..1).
    def self.seg_dist(p, a, b)
      ax = a.x.to_f; ay = a.y.to_f
      bx = b.x.to_f; by = b.y.to_f
      dx = bx - ax;  dy = by - ay
      len2 = dx * dx + dy * dy
      return [d2(p, a), 0.0] if len2 < 1e-9
      t = ((p.x.to_f - ax) * dx + (p.y.to_f - ay) * dy) / len2
      t = 0.0 if t < 0.0
      t = 1.0 if t > 1.0
      cx = ax + dx * t
      cy = ay + dy * t
      [Math.sqrt((p.x.to_f - cx)**2 + (p.y.to_f - cy)**2), t]
    end

    def self.collect
      wt = InteriorPro::WallTool.new
      Sketchup.active_model.entities.grep(Sketchup::Group).map do |g|
        next nil unless g.valid? && at(g, 'type') == 'wall'
        sx = at(g, 'start_x'); sy = at(g, 'start_y')
        ex = at(g, 'end_x');   ey = at(g, 'end_y')
        next nil if sx.nil? || ex.nil?
        flat = at(g, 'corners_xy')
        cw = flat.is_a?(Array) && flat.length == 8 ? flat.each_slice(2).map { |x, y| wp(g, x, y) } : nil
        sq = nil
        begin
          data = wt.wall_data(g)
          pc = data && wt.perpendicular_corners_xy(
            Geom::Point3d.new(sx.to_f, sy.to_f, 0),
            Geom::Point3d.new(ex.to_f, ey.to_f, 0),
            data[:thickness], data[:h_anchor]
          )
          sq = pc.map { |p| p.transform(g.transformation) } if pc
        rescue StandardError
          sq = nil
        end
        cls = nil
        cle = nil
        begin
          d2w = wt.wall_data(g)
          if d2w
            cls = wp(g, d2w[:cl_start][0], d2w[:cl_start][1])
            cle = wp(g, d2w[:cl_end][0],   d2w[:cl_end][1])
          end
        rescue StandardError
          cls = nil
        end
        {
          g: g,
          anc: at(g, 'anchor').to_s,
          cls: cls, cle: cle,
          lvl: (at(g, 'level') || 1).to_i,
          th: at(g, 'thickness').to_f,
          sag: at(g, 'arc_sag').to_f,
          cat: at(g, 'wall_category').to_s,
          s: wp(g, sx, sy), e: wp(g, ex, ey),
          cw: cw, sq: sq
        }
      end.compact
    end

    # The two footprint points that belong to one end. perpendicular_corners_xy
    # returns [s_pos, e_pos, e_neg, s_neg], and join_corners moves those same
    # slots, so the slots are stable whatever the miter did.
    def self.end_pts(list, which)
      return nil unless list
      which == :s ? [list[0], list[3]] : [list[1], list[2]]
    end

    def self.square_end?(w, which)
      a = end_pts(w[:cw], which)
      b = end_pts(w[:sq], which)
      return nil unless a && b
      [d2(a[0], b[0]), d2(a[1], b[1])].max < TOUCH
    end

    def self.run
      out = []
      out << "InteriorPro corner audit  #{Time.now}"
      walls = collect
      out << "#{walls.length} wall(s)"
      out << ''

      ends = []
      walls.each_with_index do |w, i|
        [[:s, w[:s], w[:cls]], [:e, w[:e], w[:cle]]].each do |which, p, c|
          ends << { i: i, w: w, which: which, p: p, c: c || p }
        end
      end

      rows = []
      ends.each do |en|
        w = en[:w]
        partners = []
        ends.each do |other|
          next if other[:i] == en[:i]
          next unless other[:w][:lvl] == w[:lvl]
          d = d2(en[:c], other[:c])          # CENTRELINE to centreline
          partners << [d, other, d2(en[:p], other[:p])] if d <= NEAR
        end
        partners.sort_by! { |d, _| d }

        tees = []
        walls.each_with_index do |ow, j|
          next if j == en[:i]
          next unless ow[:lvl] == w[:lvl]
          dist, t = seg_dist(en[:c], ow[:cls] || ow[:s], ow[:cle] || ow[:e])
          next if t < 0.02 || t > 0.98      # that is an end, not a middle
          tees << [dist, j, t] if dist <= NEAR
        end
        tees.sort_by! { |d, _, _| d }

        sq = square_end?(w, en[:which])
        best = partners.first
        state =
          if best.nil?
            tees.first && tees.first[0] <= w[:th] ? 'T-JOINT' : 'FREE END'
          elsif best[0] <= TOUCH
            sq ? 'TOUCHING BUT STILL SQUARE' : 'JOINED'
          else
            'NEAR MISS'
          end
        rows << { en: en, state: state, best: best, partners: partners, tees: tees, sq: sq }
      end

      order = { 'NEAR MISS' => 0, 'TOUCHING BUT STILL SQUARE' => 1, 'T-JOINT' => 2,
                'FREE END' => 3, 'JOINED' => 4 }
      counts = Hash.new(0)
      rows.each { |x| counts[x[:state]] += 1 }
      out << '== SUMMARY =='
      order.keys.each { |k| out << format('  %-26s %d', k, counts[k]) }
      out << ''
      out << '   All distances below are CENTRELINE to centreline.'
      out << ''
      out << '   NEAR MISS                 = two ends that should be one point.'
      out << '                               THIS is what leaves a white wedge.'
      out << '   TOUCHING BUT STILL SQUARE = they meet, but no miter was cut.'
      out << '   T-JOINT                   = this end lands mid-way along another wall.'
      out << '   FREE END                  = nothing near it at all (may be on purpose).'
      out << ''

      out << '== EVERY END, WORST FIRST =='
      rows.sort_by { |x| [order[x[:state]] || 9, -(x[:best] ? x[:best][0] : 0)] }.each do |x|
        en = x[:en]
        w = en[:w]
        line = format('  w%-3d %s  lvl=%d th=%-5s anc=%-13s %-26s at %s',
                      en[:i], en[:which] == :s ? 'START' : 'END  ', w[:lvl], r(w[:th]),
                      w[:anc], x[:state], ps(en[:c]))
        line += format('  square=%s', x[:sq].nil? ? '?' : x[:sq])
        out << line
        if x[:best]
          b = x[:best]
          out << format('        nearest end: w%d %s, centrelines off by %s" (drawn ends %s")',
                        b[1][:i], b[1][:which] == :s ? 'START' : 'END', r(b[0]), r(b[2]))
        end
        x[:tees].first(1).each do |d, j, t|
          out << format('        lands on w%d at %s%% along it, %s" away', j, (t * 100).round, r(d))
        end
      end
      out << ''

      out << '== THE LIST TO FIX (near misses, biggest first) =='
      nm = rows.select { |x| x[:state] == 'NEAR MISS' }
                .sort_by { |x| -x[:best][0] }
      if nm.empty?
        out << '  none'
      else
        nm.each do |x|
          en = x[:en]
          b = x[:best]
          out << format('  w%-3d %s  <->  w%-3d %s   centrelines off by %s"   lvl=%d',
                        en[:i], en[:which] == :s ? 'START' : 'END  ',
                        b[1][:i], b[1][:which] == :s ? 'START' : 'END  ',
                        r(b[0]), en[:w][:lvl])
        end
      end

      File.open(OUT, 'w') { |fh| fh.puts(out.join("\n")) }
      puts "[corners] wrote #{OUT}  (#{out.length} lines)"
      OUT
    rescue StandardError => e
      begin
        File.open(OUT, 'w') { |fh| fh.puts("FAILED: #{e.class}: #{e.message}\n" + e.backtrace.first(8).join("\n")) }
      rescue StandardError
        nil
      end
      puts "[corners] FAILED: #{e.class}: #{e.message}"
      puts e.backtrace.first(6)
      nil
    end
  end
end

InteriorPro::DebugCornersAll.run
