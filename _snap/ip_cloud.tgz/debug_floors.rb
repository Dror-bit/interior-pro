# debug_floors.rb - why is the floor still crooked? (2026-08-14)
#
# The walls are straight and their stored numbers agree with where they sit
# (normalize_report.txt: worst gap 0.000000"). The floors are not. So the
# floor is either an OLD one built while the numbers were stale, or the floor
# code reads something other than those numbers.
#
# This measures, it changes nothing. For every top-level object it reports how
# far its edges sit from the red/green axes, so a crooked floor and a straight
# wall cannot be confused for one another.
#
# Ruby Console:
#   load 'C:/Users/rordt/AppData/Roaming/SketchUp/SketchUp 2024/SketchUp/Plugins/interior_pro/debug_floors.rb'

module InteriorPro
  module DebugFloors
    def self.report_path
      File.join(File.dirname(__FILE__), 'floor_report.txt')
    end

    def self.off_axis(deg)
      o = deg % 90.0
      o -= 90.0 if o > 45.0
      o
    end

    def self.run
      model = Sketchup.active_model
      out = []
      out << '== what is still crooked =='
      out << "measured #{Time.now}"
      out << ''

      subjects = model.active_entities.select do |e|
        (e.is_a?(Sketchup::Group) || e.is_a?(Sketchup::ComponentInstance)) && e.valid?
      end

      out << format('%-22s %-10s %-10s %-9s %s',
                    'what', 'type', 'created', 'worst off', 'note')
      out << '-' * 92

      subjects.each_with_index do |g, i|
        t = g.transformation
        ents = g.respond_to?(:definition) ? g.definition.entities : g.entities
        tp = (g.get_attribute('InteriorPro', 'type') || '-').to_s
        made = (g.get_attribute('InteriorPro', 'created_at') || '-').to_s[0, 10]

        # The longest edges say which way the object really points. Short
        # edges are noise - a mitre nib can point anywhere.
        worst = 0.0
        longest = 0.0
        ents.grep(Sketchup::Edge).each do |e|
          a = e.start.position.transform(t)
          b = e.end.position.transform(t)
          dx = b.x - a.x
          dy = b.y - a.y
          len = Math.sqrt(dx * dx + dy * dy)
          next if len < 12.0                       # ignore anything under a foot
          next if (b.z - a.z).abs > 0.01 && len < 1.0
          deg = Math.atan2(dy, dx) * 180.0 / Math::PI
          off = off_axis(deg).abs
          if len > longest
            longest = len
          end
          worst = off if off > worst
        end

        name = g.respond_to?(:name) && g.name && !g.name.empty? ? g.name : "##{i}"
        note = if longest < 12.0
                 'no long edges to judge by'
               elsif worst < 0.0005
                 'on the axis'
               else
                 format('%.3f" adrift over %.0f"', longest * Math.tan(worst * Math::PI / 180.0), longest)
               end
        out << format('%-22s %-10s %-10s %-9s %s',
                      name[0, 21], tp[0, 9], made, format('%.4f', worst), note)
      end

      # What does the floor code actually read? Ask it, do not assume.
      out << ''
      out << 'what the floor builder would read RIGHT NOW:'
      walls = model.active_entities.grep(Sketchup::Group).select do |g|
        g.valid? && g.get_attribute('InteriorPro', 'type') == 'wall'
      end
      walls.each_with_index do |w, i|
        sx = w.get_attribute('InteriorPro', 'start_x')
        sy = w.get_attribute('InteriorPro', 'start_y')
        ex = w.get_attribute('InteriorPro', 'end_x')
        ey = w.get_attribute('InteriorPro', 'end_y')
        next unless sx && sy && ex && ey
        deg = Math.atan2(ey.to_f - sy.to_f, ex.to_f - sx.to_f) * 180.0 / Math::PI
        id = (w.get_attribute('InteriorPro', 'id') || "##{i}").to_s[0, 13]
        flat = w.get_attribute('InteriorPro', 'corners_xy')
        cdeg = if flat.is_a?(Array) && flat.length == 8
                 Math.atan2(flat[3].to_f - flat[1].to_f,
                            flat[2].to_f - flat[0].to_f) * 180.0 / Math::PI
               end
        out << format('  %-14s line %+9.4f (off %+.4f)%s',
                      id, deg, off_axis(deg),
                      cdeg ? format('   corners %+9.4f (off %+.4f)', cdeg, off_axis(cdeg)) : '   corners MISSING')
      end

      out << ''
      out << 'if the wall LINE is straight but its CORNERS are not, the wall'
      out << 'footprint itself is stale and the floor is right to follow it.'

      File.write(report_path, out.join("\n"))
      UI.messagebox('done - floor_report.txt written')
    rescue => e
      File.write(report_path, "CRASHED: #{e.class}: #{e.message}\n" +
                              e.backtrace.first(6).join("\n"))
      UI.messagebox('crashed - see floor_report.txt')
    end
  end
end

InteriorPro::DebugFloors.run
